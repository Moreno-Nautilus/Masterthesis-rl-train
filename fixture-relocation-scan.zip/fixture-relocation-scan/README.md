# fixture-relocation-scan

Locates the KUKA/PDZ ArUco pickup fixture live via wrist-mounted RealSense cameras and writes
`fixture_pose_correction.json` for Fabrica-pdz's
`planning/patch_motion_for_fixture_correction.py` to consume. See
`~/Fabrica-pdz/docs/live_fixture_relocation_implementation_plan.md`, Deliverable 3, for the
full design.

The scan viewpoints + the collision-free joint trajectories between them come from the
`fixture_scan/` viewpoint planner (`fixture_scan/pipeline.py::run_full_plan`), reached
either as a pre-staged `scan_program.json`
(`scan_fixture.py --scan-program`, from the host `run_viewpoint_planner` two-step) or
planned in-process (`scan_fixture.py --plan-viewpoints` — same pipeline, one container
command). The planner publishes `table` + `mock_box` + the estimated fixture box into the
namespaced MoveIt scene itself, so `mode:=hardware` plans against the same collision world
as `mode:=mock`. There is no ad-hoc orbit path.

Optionally (`scan_fixture.py --capture-depth`) it also dumps one raw depth frame per scan
viewpoint to `<arm>_depth_capture/`; the host-side `tools/build_scan_cloud.py` reconstructs
those into `hold`/`move`/`both_pointcloud.ply` for **visual inspection only** — nothing
downstream reads the clouds. Design + status:
`~/Fabrica-pdz/docs/fixture_scan_depth_capture_plan.md`.

Standalone package: no imports of Masterthesis-vision's `src/` perception/calibration
internals, except one deliberate exception (`cartesian_impedance_dual_arm.py`'s motion helpers
+ the `ArmTarget`/`JointTarget`/`SE3` types they use) for real-robot-tested arm motion.

## Environment

Runs inside the existing `vision` Docker container (needs its ROS2 Humble + RealSense stack).
`~/.bashrc` inside that container only sources ROS2 + its venv for **interactive** shells
(`[ -z "$PS1" ] && return` guards it) — for a non-interactive invocation (a script, `docker exec`
without `-it`), source both explicitly first:

```bash
docker exec -it vision bash -lc "
  source /opt/ros/humble/setup.bash && source /opt/thesis-venv/bin/activate &&
  cd ~/fixture-relocation-scan &&
  python3 -m fixture_relocation_scan.scan_fixture --both --report-only
"
```

Own `requirements.txt` on top of that venv (`opencv-python`/`scipy`/`open3d` pinned
independently of Masterthesis-vision's own requirements, `rclpy` inherited via
`--system-site-packages`):

```bash
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Set `MASTERTHESIS_VISION_DIR`/`CAMERA_EXTRINSICS_YAML` to override where `scan_fixture.py`
looks for `~/Masterthesis-vision` and its extrinsics YAML if not at the default paths.

## Safety

`scan_fixture.py` is the only file here that can move a real robot (via
`CartesianImpedanceDualArmClient.move_to_cartesian`/`move_to_joint_compliant`). Do not run it
against a live rig without a person present and the robot confirmed safe to move. Everything
else (`aruco_board_pose.py`, `look_at_pose.py`, `half_circle_waypoints.py`) is pure
math/perception, independently testable — see `tests/`.

## Testing without hardware

```bash
python3 -m pytest tests/test_aruco_board_pose_synthetic.py   # needs cv2 w/ ArUco only
python3 tests/test_look_at_pose.py
python3 tests/test_half_circle_waypoints.py
# depth capture + offline point-cloud reconstruction (no ROS; conda fabrica-kuka-pdz8):
python3 tests/test_depth_decode.py             # depth_decode.py: 16UC1/32FC1 decode, stamps
python3 tests/test_scan_cloud_backproject.py   # build_scan_cloud.py geometry: backproject, ROI, voxel, PLY
python3 tests/test_build_scan_cloud_smoke.py   # build_scan_cloud.py end-to-end on a synthetic capture dir
```

`fixture_tracker.py` and `scan_fixture.py` need `rclpy` and are not exercised by these tests —
their wiring against real topics still needs a supervised hardware session (see the design
doc's Verification section). The depth-decode logic is split into the ROS-free
`depth_decode.py` so it *is* covered above.
