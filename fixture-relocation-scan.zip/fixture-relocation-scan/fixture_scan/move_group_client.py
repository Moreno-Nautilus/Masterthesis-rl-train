"""Thin MoveIt client for the viewpoint planner: seeded IK, FK, state-validity, CHOMP.

Talks to the NAMESPACED `move_group` brought up by
`lbr_dual_arm_pdz_bringup/launch/move_group_ns.launch.py` -- services
`/<robot>/compute_ik`, `/<robot>/compute_fk`, `/<robot>/check_state_validity`, and the
`/<robot>/move_action` action (used only for the CHOMP tier of trajectory generation).

Owns its own node + a MultiThreadedExecutor spun on a daemon thread, so
`compute_ik_batch()` can fire N `/compute_ik` calls concurrently (reentrant). If
`move_group` serialises the service internally the batch just runs ~N x slower -- still
~1-2 s for the whole candidate set, acceptable (impl-plan U6).

Every call takes / returns plain numpy; the idle (non-scanning) arm is pinned into the
collision world by passing its 7-vector as `other_arm_q` so IK / validity see the parked
arm as a static obstacle (impl-plan D1).
"""

import threading

import numpy as np
import rclpy
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from scipy.spatial.transform import Rotation

from moveit_msgs.action import ExecuteTrajectory, MoveGroup
from moveit_msgs.msg import (
    Constraints,
    JointConstraint,
    MotionPlanRequest,
    PlanningOptions,
    RobotState,
    RobotTrajectory,
)
from moveit_msgs.srv import GetPositionFK, GetPositionIK, GetStateValidity
from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

from fixture_scan import config
from fixture_scan import robot_defs

_MOVEIT_SUCCESS = 1  # moveit_msgs/MoveItErrorCodes.SUCCESS


def _future_result(node_executor_lock, future, timeout_s):
    """Block until an rclpy future spun by a background executor completes."""
    done = threading.Event()
    future.add_done_callback(lambda _f: done.set())
    if not done.wait(timeout=timeout_s):
        return None
    return future.result()


class MoveGroupClient:
    def __init__(self, robot_name=None, *, wait_s=15.0, spin=True):
        self.robot_name = robot_name or config.ROBOT_NAME
        if not rclpy.ok():
            rclpy.init(args=None)
        self._node = Node("fixture_scan_move_group_client")
        self._log = self._node.get_logger()
        self._cbg = ReentrantCallbackGroup()

        ns = self.robot_name
        self._ik = self._node.create_client(
            GetPositionIK, f"/{ns}/compute_ik", callback_group=self._cbg)
        self._fk = self._node.create_client(
            GetPositionFK, f"/{ns}/compute_fk", callback_group=self._cbg)
        self._sv = self._node.create_client(
            GetStateValidity, f"/{ns}/check_state_validity", callback_group=self._cbg)
        self._move = None  # lazily created -- only the CHOMP tier needs the action
        self._exec = None  # lazily created -- only execute_path() needs it

        self._executor = MultiThreadedExecutor(num_threads=max(4, config.N_IK_SOLUTIONS + 1))
        self._executor.add_node(self._node)
        self._spin_thread = None
        if spin:
            self._spin_thread = threading.Thread(
                target=self._executor.spin, name="fixture_scan_mg_spin", daemon=True)
            self._spin_thread.start()

        for cli, name in ((self._ik, "compute_ik"), (self._fk, "compute_fk"),
                          (self._sv, "check_state_validity")):
            if not cli.wait_for_service(timeout_sec=wait_s):
                raise RuntimeError(
                    f"/{ns}/{name} not available after {wait_s:.0f}s -- is the namespaced "
                    "move_group up? (ros2 launch lbr_dual_arm_pdz_bringup "
                    "move_group_ns.launch.py mode:=mock|hardware)")

    # -- lifecycle ---------------------------------------------------------------------
    @property
    def node(self):
        """The rclpy Node (spun by this client's background executor) -- so helpers like
        `scene_publisher` can create their own service clients on it."""
        return self._node

    def shutdown(self):
        try:
            self._executor.shutdown()
        except Exception:
            pass
        self._node.destroy_node()

    # -- shared robot-state assembly -------------------------------------------------
    def _robot_state(self, role, q_arm, other_arm_q=None) -> RobotState:
        names = list(robot_defs.joint_names(role))
        pos = [float(x) for x in np.asarray(q_arm, dtype=float)]
        if other_arm_q is not None:
            other = robot_defs.OTHER_ROLE[role]
            names += list(robot_defs.joint_names(other))
            pos += [float(x) for x in np.asarray(other_arm_q, dtype=float)]
        rs = RobotState()
        rs.joint_state = JointState(name=names, position=pos)
        rs.is_diff = True   # any unlisted joint keeps move_group's monitored value
        return rs

    # -- IK -------------------------------------------------------------------------
    def _ik_request(self, role, T_base_target, seed_q, other_arm_q, tip_link, group):
        group_name, _base, default_tip, _jn = robot_defs.ARM[role]
        req = GetPositionIK.Request()
        ik = req.ik_request
        ik.group_name = group or group_name
        ik.robot_state = self._robot_state(role, seed_q, other_arm_q)
        ik.ik_link_name = tip_link or default_tip
        ik.pose_stamped.header.frame_id = robot_defs.PLANNING_FRAME
        p = np.asarray(T_base_target, dtype=float)
        ik.pose_stamped.pose.position.x = float(p[0, 3])
        ik.pose_stamped.pose.position.y = float(p[1, 3])
        ik.pose_stamped.pose.position.z = float(p[2, 3])
        qx, qy, qz, qw = Rotation.from_matrix(p[:3, :3]).as_quat()
        ik.pose_stamped.pose.orientation.x = float(qx)
        ik.pose_stamped.pose.orientation.y = float(qy)
        ik.pose_stamped.pose.orientation.z = float(qz)
        ik.pose_stamped.pose.orientation.w = float(qw)
        ik.timeout.sec = int(config.IK_TIMEOUT_S)
        ik.timeout.nanosec = int((config.IK_TIMEOUT_S % 1.0) * 1e9)
        ik.avoid_collisions = True
        return req

    def compute_ik(self, role, T_base_target, seed_q, *, other_arm_q=None,
                   tip_link=None, group=None, timeout_s=None):
        """One /compute_ik. Returns a (7,) solution or None (no solution / timeout)."""
        req = self._ik_request(role, T_base_target, seed_q, other_arm_q, tip_link, group)
        fut = self._ik.call_async(req)
        res = _future_result(None, fut, timeout_s or config.IK_GATHER_TIMEOUT_S)
        return self._ik_result_to_q(role, res)

    def compute_ik_batch(self, role, T_base_target, seed_qs, *, other_arm_q=None,
                         tip_link=None, group=None):
        """Fire one /compute_ik per seed in `seed_qs` CONCURRENTLY; gather. Returns a
        list of (7,) solutions (Nones dropped). Order follows `seed_qs`."""
        reqs = [self._ik_request(role, T_base_target, s, other_arm_q, tip_link, group)
                for s in seed_qs]
        futs = [self._ik.call_async(r) for r in reqs]
        out = []
        for f in futs:
            res = _future_result(None, f, config.IK_GATHER_TIMEOUT_S)
            q = self._ik_result_to_q(role, res)
            if q is not None:
                out.append(q)
        return out

    def _ik_result_to_q(self, role, res):
        if res is None or res.error_code.val != _MOVEIT_SUCCESS:
            return None
        want = robot_defs.joint_names(role)
        sol = dict(zip(res.solution.joint_state.name, res.solution.joint_state.position))
        try:
            return np.array([sol[j] for j in want], dtype=float)
        except KeyError:
            return None

    # -- state validity ------------------------------------------------------------
    def check_state_validity(self, role, q_arm, *, other_arm_q=None, group=None) -> bool:
        group_name = group or robot_defs.ARM[role][0]
        req = GetStateValidity.Request()
        req.robot_state = self._robot_state(role, q_arm, other_arm_q)
        req.group_name = group_name
        fut = self._sv.call_async(req)
        res = _future_result(None, fut, config.IK_GATHER_TIMEOUT_S)
        if res is None:
            raise RuntimeError(f"[{role}] check_state_validity timed out")
        return bool(res.valid)

    def path_is_valid(self, role, path, *, other_arm_q=None, group=None) -> bool:
        """Every (7,) waypoint in `path` (N,7) passes check_state_validity."""
        for q in np.asarray(path, dtype=float):
            if not self.check_state_validity(role, q, other_arm_q=other_arm_q, group=group):
                return False
        return True

    # -- FK ----------------------------------------------------------------------
    def compute_fk(self, role, q_arm, *, link=None, other_arm_q=None):
        """4x4 pose of `link` (default: the role's TCP tip) in the planning frame
        (base_link) for joint config `q_arm`. Returns None on failure."""
        tip = link or robot_defs.ARM[role][2]
        req = GetPositionFK.Request()
        req.header.frame_id = robot_defs.PLANNING_FRAME
        req.fk_link_names = [tip]
        req.robot_state = self._robot_state(role, q_arm, other_arm_q)
        fut = self._fk.call_async(req)
        res = _future_result(None, fut, config.IK_GATHER_TIMEOUT_S)
        if res is None or res.error_code.val != _MOVEIT_SUCCESS or not res.pose_stamped:
            return None
        pose = res.pose_stamped[0].pose
        T = np.eye(4)
        T[:3, :3] = Rotation.from_quat(
            [pose.orientation.x, pose.orientation.y,
             pose.orientation.z, pose.orientation.w]).as_matrix()
        T[:3, 3] = [pose.position.x, pose.position.y, pose.position.z]
        return T

    # -- CHOMP (tier 2) ---------------------------------------------------------
    def _ensure_move_action(self, wait_s=15.0):
        if self._move is not None:
            return
        from rclpy.action import ActionClient
        self._move = ActionClient(
            self._node, MoveGroup, f"/{self.robot_name}/move_action",
            callback_group=self._cbg)
        if not self._move.wait_for_server(timeout_sec=wait_s):
            raise RuntimeError(
                f"/{self.robot_name}/move_action not available after {wait_s:.0f}s "
                "-- move_group up? (needed only for the CHOMP trajectory tier)")

    def plan_joint_goal_chomp(self, role, q_goal, *, start_q, other_arm_q=None):
        """CHOMP plan (plan_only) from `start_q` to the joint config `q_goal`, idle arm
        pinned at `other_arm_q`. MoveIt/CHOMP seeds internally from the straight-line
        joint interpolation between start and goal. Returns an (N,7) path or raises."""
        self._ensure_move_action()
        group_name, _base, _tip, jn = robot_defs.ARM[role]

        tol = config.CHOMP_GOAL_JOINT_TOL_RAD
        gc = Constraints()
        for name, val in zip(jn, np.asarray(q_goal, dtype=float)):
            jcon = JointConstraint()
            jcon.joint_name = name
            jcon.position = float(val)
            jcon.tolerance_above = tol
            jcon.tolerance_below = tol
            jcon.weight = 1.0
            gc.joint_constraints.append(jcon)

        req = MotionPlanRequest()
        req.group_name = group_name
        req.pipeline_id = "chomp"
        req.goal_constraints.append(gc)
        req.num_planning_attempts = config.CHOMP_PLANNING_ATTEMPTS
        req.allowed_planning_time = config.CHOMP_PLANNING_TIME_S
        req.max_velocity_scaling_factor = 0.1
        req.max_acceleration_scaling_factor = 0.1
        req.start_state = self._robot_state(role, start_q, other_arm_q)
        req.start_state.is_diff = True
        req.workspace_parameters.header.frame_id = robot_defs.PLANNING_FRAME
        req.workspace_parameters.min_corner.x = -2.0
        req.workspace_parameters.min_corner.y = -2.0
        req.workspace_parameters.min_corner.z = -2.0
        req.workspace_parameters.max_corner.x = 2.0
        req.workspace_parameters.max_corner.y = 2.0
        req.workspace_parameters.max_corner.z = 2.0

        goal = MoveGroup.Goal()
        goal.request = req
        goal.planning_options = PlanningOptions()
        goal.planning_options.plan_only = True
        goal.planning_options.planning_scene_diff.is_diff = True
        goal.planning_options.planning_scene_diff.robot_state.is_diff = True

        send_fut = self._move.send_goal_async(goal)
        gh = _future_result(None, send_fut, 20.0)
        if gh is None or not gh.accepted:
            raise RuntimeError(f"[{role}] CHOMP planning goal rejected")
        res = _future_result(None, gh.get_result_async(),
                             config.CHOMP_PLANNING_TIME_S * config.CHOMP_PLANNING_ATTEMPTS + 15.0)
        if res is None:
            raise RuntimeError(f"[{role}] CHOMP planning timed out")
        result = res.result
        if result.error_code.val != _MOVEIT_SUCCESS:
            raise RuntimeError(
                f"[{role}] CHOMP planning failed (MoveItErrorCode {result.error_code.val})")
        jt = result.planned_trajectory.joint_trajectory
        if not jt.points:
            raise RuntimeError(f"[{role}] CHOMP returned an empty trajectory")
        idx = [list(jt.joint_names).index(j) for j in jn]
        return np.array([[pt.positions[i] for i in idx] for pt in jt.points], dtype=float)

    # -- execution (optional: actually move the arm / animate in RViz) -------------
    def _ensure_exec_action(self, wait_s=15.0):
        if self._exec is not None:
            return
        from rclpy.action import ActionClient
        self._exec = ActionClient(
            self._node, ExecuteTrajectory, f"/{self.robot_name}/execute_trajectory",
            callback_group=self._cbg)
        if not self._exec.wait_for_server(timeout_sec=wait_s):
            raise RuntimeError(
                f"/{self.robot_name}/execute_trajectory not available after {wait_s:.0f}s "
                "-- move_group up with trajectory execution enabled and a controller "
                "connected (mock.launch.py / hardware.launch.py)?")

    def execute_path(self, role, path, *, time_step_s=0.1, wait_s=None) -> bool:
        """Send a joint path (N,7) to move_group's /<robot>/execute_trajectory so the arm
        ACTUALLY MOVES -- drives whatever controller move_group is configured with (mock
        JTC or the real cabinets) and RViz animates the real robot state, not just a
        preview. Fixed `time_step_s` per waypoint; returns True on SUCCESS.

        The idle arm is not included (it holds position). The path's first waypoint should
        be the current state (the lead-in starts at q_current)."""
        path = np.asarray(path, dtype=float)
        if path.ndim != 2 or path.shape[1] != 7 or len(path) < 2:
            raise ValueError(f"execute_path needs an (N>=2, 7) path, got {path.shape}")
        self._ensure_exec_action()
        _g, _b, _t, jn = robot_defs.ARM[role]

        jt = JointTrajectory()
        jt.header.frame_id = robot_defs.PLANNING_FRAME
        jt.joint_names = list(jn)
        for k, q in enumerate(path):
            pt = JointTrajectoryPoint()
            pt.positions = [float(x) for x in q]
            t = (k + 1) * time_step_s
            pt.time_from_start.sec = int(t)
            pt.time_from_start.nanosec = int((t % 1.0) * 1e9)
            jt.points.append(pt)

        goal = ExecuteTrajectory.Goal()
        goal.trajectory = RobotTrajectory(joint_trajectory=jt)

        send_fut = self._exec.send_goal_async(goal)
        gh = _future_result(None, send_fut, 20.0)
        if gh is None or not gh.accepted:
            raise RuntimeError(f"[{role}] execute_trajectory goal rejected")
        budget = wait_s if wait_s is not None else len(path) * time_step_s + 30.0
        res = _future_result(None, gh.get_result_async(), budget)
        if res is None:
            raise RuntimeError(f"[{role}] execute_trajectory timed out after {budget:.0f}s")
        ok = res.result.error_code.val == _MOVEIT_SUCCESS
        if not ok:
            self._log.warn(
                f"[{role}] execute_trajectory finished with MoveItErrorCode "
                f"{res.result.error_code.val}")
        return ok
