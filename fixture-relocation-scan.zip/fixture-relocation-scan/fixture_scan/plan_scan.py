#!/usr/bin/env python3
"""Shared "fixture inputs -> scan program" core.

`plan_scan_program()` is exactly what `run_viewpoint_planner.main()` does between
arg-parsing and its `--rviz` / trajectory-error / `write_program` / `--execute` tail:
read `q_current`, pin the idle arm from `motion.pkl`, build a `MoveGroupClient`, resolve
intrinsics (live `camera_info` -> YAML fallback), FK the current camera orientation, run
`pipeline.run_full_plan`, and turn a successful result into a `scan_program` dict.

Two callers share it, so the live hardware scan runs the SAME planning as the tested
mock/sim pipeline:
  - host: `fixture_scan.run_viewpoint_planner` (writes `scan_program.json`, optional
    `--rviz` / `--execute`),
  - container: `fixture_relocation_scan.scan_fixture --plan-viewpoints` (in-process, feeds
    the result straight into the per-viewpoint executor).

No argparse, no RViz, no file I/O here.
"""

import time

import numpy as np

from fixture_scan import config, robot_defs
from fixture_scan import inputs as fs_inputs
from fixture_scan.pipeline import run_full_plan


def _read_q_current(node, robot_name, joint_names, wait_s=10.0):
    from sensor_msgs.msg import JointState
    import rclpy
    want = set(joint_names)
    latest = {}

    def _cb(msg):
        for n, p in zip(msg.name, msg.position):
            if n in want:
                latest[n] = float(p)

    sub = node.create_subscription(JointState, f"/{robot_name}/joint_states", _cb, 10)
    deadline = time.monotonic() + wait_s
    while rclpy.ok() and not want.issubset(latest) and time.monotonic() < deadline:
        rclpy.spin_once(node, timeout_sec=0.1)
    node.destroy_subscription(sub)
    if not want.issubset(latest):
        raise RuntimeError(
            f"/{robot_name}/joint_states missing {sorted(want - set(latest))} after {wait_s}s")
    return np.array([latest[j] for j in joint_names])


def _current_cam_orientation(mg_client, role, q_current, T_flange_cam):
    """R_base_cam at q_current -- FK the flange (lbr_*_link_ee), compose the mount R."""
    arm = robot_defs.ROLE_TO_ARM[role]
    T_base_ee = mg_client.compute_fk(role, q_current, link=f"{arm}_link_ee")
    if T_base_ee is None:
        return None
    return T_base_ee[:3, :3] @ T_flange_cam[:3, :3]


def _resolve_intrinsics(node, cam_id, role, source, intrinsics_yaml, log):
    """(intrinsics_obj_or_None, source_str). Mirrors run_viewpoint_planner's CLI logic:
    `auto` -> live camera_info if it is publishing, else the YAML; `camera_info` ->
    require the live topic; `yaml` -> always the file (obj None -> the pipeline loads it)."""
    if source not in ("auto", "camera_info"):
        return None, "yaml"
    if node is None:
        if source == "camera_info":
            raise RuntimeError("intrinsics_source='camera_info' needs an rclpy node for "
                               "the live CameraInfo read, but node=None")
        log(f"[{role}] no node for a live {cam_id} camera_info read; using {intrinsics_yaml}")
        return None, "yaml"
    intr = fs_inputs.load_intrinsics_live(node, cam_id)
    if intr is not None:
        log(f"[{role}] intrinsics from live {cam_id} camera_info "
            f"({intr.width}x{intr.height}, fx={intr.fx:.1f} cx={intr.cx:.1f})")
        return intr, "camera_info"
    if source == "camera_info":
        raise RuntimeError(
            f"intrinsics_source='camera_info': no CameraInfo on {cam_id}'s topic "
            f"({fs_inputs._camera_info_topic(cam_id)}) -- is the camera up?")
    log(f"[{role}] no live {cam_id} camera_info; falling back to {intrinsics_yaml}")
    return None, "yaml"


def plan_scan_program(role, *, robot_name, nominal_pose, motion_pkl,
                      intrinsics_yaml, extrinsics_yaml, plan=None,
                      intrinsics_source="auto", node=None, mg=None,
                      q_current=None, log=None):
    """Run the full viewpoint-planning pipeline and return `(program_dict_or_None, result)`.

    `program_dict` is None iff `result["trajectory_error"]` is set -- the caller decides
    whether that is fatal (container: raise; host: print + rc=1, with the RViz markers
    still reachable off `result`). `result` is `pipeline.run_full_plan`'s dict.

    `mg`: pass an existing `MoveGroupClient` to keep ownership (the host reuses it for
    `--execute`); omit and one is built + `shutdown()` here. `node`: an rclpy node for the
    live `q_current` / `CameraInfo` reads -- required unless `q_current` is supplied and
    `intrinsics_source == 'yaml'`.
    """
    from fixture_scan.move_group_client import MoveGroupClient
    from fixture_scan import scan_program as sp
    from fixture_relocation_scan.plan_inputs import first_joint_waypoint

    log = log or (lambda _m: None)
    cam_id = fs_inputs.ARM_TO_CAM_ID[role]

    if q_current is None:
        if node is None:
            raise RuntimeError("plan_scan_program: pass q_current or an rclpy node to read it")
        q_current = _read_q_current(node, robot_name, robot_defs.joint_names(role))
    q_current = np.asarray(q_current, dtype=float)

    other_role = robot_defs.OTHER_ROLE[role]
    other_arm_q = first_joint_waypoint(motion_pkl, other_role)
    log(f"[{role}] q_current (deg): {np.degrees(q_current).round(1).tolist()}")
    log(f"[{role}] idle arm {other_role} pinned at motion.pkl waypoint (deg): "
        f"{np.degrees(other_arm_q).round(1).tolist()}")

    owns_mg = mg is None
    if owns_mg:
        mg = MoveGroupClient(robot_name=robot_name)
    try:
        T_flange_cam = fs_inputs.load_flange_to_camera(extrinsics_yaml, cam_id)
        R_cam_current = _current_cam_orientation(mg, role, q_current, T_flange_cam)
        intrinsics_obj, intr_source = _resolve_intrinsics(
            node, cam_id, role, intrinsics_source, intrinsics_yaml, log)

        result = run_full_plan(
            role, mg, nominal_pose_path=nominal_pose,
            intrinsics_yaml=intrinsics_yaml, extrinsics_yaml=extrinsics_yaml,
            q_current=q_current, other_arm_q=other_arm_q, cam_id=cam_id,
            R_cam_current=R_cam_current, intrinsics=intrinsics_obj)

        program = None
        if not result.get("trajectory_error"):
            program = sp.build_program(
                role, result["ordered"], result["segments"], q_current=q_current,
                other_arm_q=other_arm_q, fixture_pose_path=nominal_pose, cam_id=cam_id,
                intrinsics_path=intrinsics_yaml, extrinsics_path=extrinsics_yaml,
                plan=plan, intrinsics_source=intr_source)
        return program, result
    finally:
        if owns_mg:
            mg.shutdown()
