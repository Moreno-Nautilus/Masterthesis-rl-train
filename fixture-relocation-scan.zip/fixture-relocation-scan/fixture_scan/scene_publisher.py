"""Publish the estimated fixture as a static box CollisionObject into the NAMESPACED
MoveIt planning scene, so `/check_state_validity` + CHOMP keep the scanning arm (and its
generated trajectories) clear of the fixture and the extra camera mounted on top of it.

The `table` and the always-present `mock_box` come from
`lbr_dual_arm_bringup/config/mock_scene_objects.yaml`, published by
`publish_mock_scene_objects.py` (wired into
`lbr_dual_arm_pdz_bringup/launch/move_group_ns.launch.py` for `mode:=mock`). This module
adds ONLY the fixture box, whose pose is a runtime input to the planner and so cannot
live in that static YAML.

The box is a `config.FIXTURE_BOX_SIZE_M` (0.30 x 0.30 x 0.10 m) axis-aligned block, its
footprint centred on the initial fixture-centre estimate and its BOTTOM face resting on
the table surface (`config.TABLE_TOP_Z_M`), published in `robot_defs.PLANNING_FRAME`
(base_link) via move_group's `/<robot>/apply_planning_scene` service.

FUTURE WORK: published once from the INITIAL estimate and never updated -- a refined
fixture pose mid-run does not move it. Track the live estimate if the scan loop starts
correcting the fixture pose online.

rclpy / moveit_msgs imports are function-local so the module stays import-safe with no
ROS (matches `visualization.py`).
"""

import math
import threading

import numpy as np
import yaml

from fixture_scan import config, robot_defs


def _await(future, timeout_s):
    """Block until an rclpy future spun by a background executor completes (the
    MoveGroupClient node is spun on its own daemon thread). Returns None on timeout."""
    done = threading.Event()
    future.add_done_callback(lambda _f: done.set())
    return future.result() if done.wait(timeout=timeout_s) else None


def build_fixture_collision_object(fixture_center, *, cfg=config, stamp=None):
    """`moveit_msgs/CollisionObject` for the fixture box, in the planning frame."""
    from geometry_msgs.msg import Pose
    from moveit_msgs.msg import CollisionObject
    from shape_msgs.msg import SolidPrimitive
    from std_msgs.msg import Header

    sx, sy, sz = (float(v) for v in cfg.FIXTURE_BOX_SIZE_M)
    c = np.asarray(fixture_center, dtype=float).reshape(3)

    prim = SolidPrimitive()
    prim.type = SolidPrimitive.BOX
    prim.dimensions = [sx, sy, sz]

    pose = Pose()
    pose.position.x = float(c[0])
    pose.position.y = float(c[1])
    pose.position.z = float(cfg.TABLE_TOP_Z_M + sz / 2.0)   # bottom face on the table
    pose.orientation.w = 1.0

    obj = CollisionObject()
    obj.header = Header(frame_id=robot_defs.PLANNING_FRAME)
    if stamp is not None:
        obj.header.stamp = stamp
    obj.id = cfg.FIXTURE_BOX_ID
    obj.primitives = [prim]
    obj.primitive_poses = [pose]
    obj.operation = CollisionObject.ADD
    return obj


def publish_fixture_box(mg_client, fixture_center, *, cfg=config, timeout_s=5.0) -> bool:
    """Add / replace the fixture box in the namespaced planning scene via
    `/<robot>/apply_planning_scene`. Returns True on success.

    Never raises -- a scene it cannot reach is logged as a warning and planning proceeds
    (the explicit FK TCP-z floor in `trajectory_planning` still guards the fingertip)."""
    from moveit_msgs.msg import PlanningScene, PlanningSceneWorld
    from moveit_msgs.srv import ApplyPlanningScene

    node = mg_client.node
    log = node.get_logger()
    service = f"/{mg_client.robot_name}/apply_planning_scene"
    cli = node.create_client(ApplyPlanningScene, service)
    try:
        if not cli.wait_for_service(timeout_sec=timeout_s):
            log.warn(
                f"{service} unavailable after {timeout_s:.0f}s -- fixture box "
                f"{cfg.FIXTURE_BOX_ID!r} NOT added; CHOMP / state-validity will not see "
                "the fixture (the FK TCP-z floor still applies)")
            return False
        obj = build_fixture_collision_object(
            fixture_center, cfg=cfg, stamp=node.get_clock().now().to_msg())
        scene = PlanningScene(
            is_diff=True, world=PlanningSceneWorld(collision_objects=[obj]))
        res = _await(cli.call_async(ApplyPlanningScene.Request(scene=scene)), timeout_s)
        ok = bool(res and res.success)
        p = obj.primitive_poses[0].position
        (log.info if ok else log.warn)(
            f"fixture box {cfg.FIXTURE_BOX_ID!r} {tuple(cfg.FIXTURE_BOX_SIZE_M)} m @ "
            f"({p.x:.3f}, {p.y:.3f}, {p.z:.3f}) {robot_defs.PLANNING_FRAME}: "
            f"apply_planning_scene {'OK' if ok else 'reported failure / timed out'}")
        return ok
    finally:
        node.destroy_client(cli)


# -- static scene (`table` + `mock_box`) -----------------------------------------------
def _rpy_rad_to_quaternion_xyzw(roll, pitch, yaw):
    """RPY (rad) -> (x, y, z, w). Re-implemented from
    lbr_dual_arm_bringup/scripts/publish_mock_scene_objects.py so `fixture_scan` needs no
    ~/franka_ros2_ws import."""
    cr, sr = math.cos(roll * 0.5), math.sin(roll * 0.5)
    cp, sp = math.cos(pitch * 0.5), math.sin(pitch * 0.5)
    cy, sy = math.cos(yaw * 0.5), math.sin(yaw * 0.5)
    return (
        sr * cp * cy - cr * sp * sy,
        cr * sp * cy + sr * cp * sy,
        cr * cp * sy - sr * sp * cy,
        cr * cp * cy + sr * sp * sy,
    )


def _make_box_collision_object(spec, frame_id, stamp=None):
    """`moveit_msgs/CollisionObject` for one YAML box spec (`id`, `size_m`, `position_m`,
    optional `rpy_rad`). Mirrors `publish_mock_scene_objects._make_box_collision_object`."""
    from geometry_msgs.msg import Pose
    from moveit_msgs.msg import CollisionObject
    from shape_msgs.msg import SolidPrimitive
    from std_msgs.msg import Header

    size = spec["size_m"]
    position = spec["position_m"]
    roll, pitch, yaw = spec.get("rpy_rad", [0.0, 0.0, 0.0])

    prim = SolidPrimitive()
    prim.type = SolidPrimitive.BOX
    prim.dimensions = [float(size[0]), float(size[1]), float(size[2])]

    pose = Pose()
    pose.position.x, pose.position.y, pose.position.z = (
        float(position[0]), float(position[1]), float(position[2]))
    qx, qy, qz, qw = _rpy_rad_to_quaternion_xyzw(float(roll), float(pitch), float(yaw))
    pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w = (
        qx, qy, qz, qw)

    obj = CollisionObject()
    obj.header = Header(frame_id=frame_id)
    if stamp is not None:
        obj.header.stamp = stamp
    obj.id = spec["id"]
    obj.primitives = [prim]
    obj.primitive_poses = [pose]
    obj.operation = CollisionObject.ADD
    return obj


def publish_static_scene(mg_client, *, yaml_path=None, timeout_s=5.0) -> bool:
    """Add the static `table` + `mock_box` boxes (config.STATIC_SCENE_OBJECTS_YAML) to the
    namespaced planning scene via `/<robot>/apply_planning_scene`, so `mode:=hardware` (no
    `publish_mock_scene_objects.py`) gets the same collision world as `mode:=mock`. On
    `mode:=mock` this re-asserts the identical boxes -- `ADD` by id is idempotent.

    Never raises -- a scene it cannot reach is logged as a warning and planning proceeds
    (the FK TCP-z floor in `trajectory_planning` still guards the fingertip)."""
    from moveit_msgs.msg import PlanningScene, PlanningSceneWorld
    from moveit_msgs.srv import ApplyPlanningScene

    path = yaml_path or config.STATIC_SCENE_OBJECTS_YAML
    node = mg_client.node
    log = node.get_logger()
    try:
        with open(path, "r") as fp:
            spec = yaml.safe_load(fp)
        frame_id = spec.get("frame_id", robot_defs.PLANNING_FRAME)
        object_specs = spec["objects"]
    except (OSError, KeyError, yaml.YAMLError) as exc:
        log.warn(f"static scene YAML {path!r} unreadable ({exc}) -- table/mock_box NOT "
                 "added; CHOMP / state-validity will not see them")
        return False
    if frame_id != robot_defs.PLANNING_FRAME:
        log.warn(f"static scene YAML frame_id {frame_id!r} != planning frame "
                 f"{robot_defs.PLANNING_FRAME!r}; publishing objects in {frame_id!r} as-is")

    service = f"/{mg_client.robot_name}/apply_planning_scene"
    cli = node.create_client(ApplyPlanningScene, service)
    try:
        if not cli.wait_for_service(timeout_sec=timeout_s):
            log.warn(f"{service} unavailable after {timeout_s:.0f}s -- static scene "
                     f"{[s['id'] for s in object_specs]} NOT added (FK TCP-z floor still "
                     "applies)")
            return False
        stamp = node.get_clock().now().to_msg()
        objs = [_make_box_collision_object(s, frame_id, stamp) for s in object_specs]
        scene = PlanningScene(
            is_diff=True, world=PlanningSceneWorld(collision_objects=objs))
        res = _await(cli.call_async(ApplyPlanningScene.Request(scene=scene)), timeout_s)
        ok = bool(res and res.success)
        (log.info if ok else log.warn)(
            f"static scene {[o.id for o in objs]} in {frame_id}: "
            f"apply_planning_scene {'OK' if ok else 'reported failure / timed out'}")
        return ok
    finally:
        node.destroy_client(cli)
