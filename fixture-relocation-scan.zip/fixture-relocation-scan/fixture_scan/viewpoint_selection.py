"""§7 select 5-10 diverse viewpoints -- greedy farthest-point, not top-S.

First pick = argmax S_i. Then repeatedly pick  argmax_i [ lambda S_i + (1-lambda) Delta_i ]
where Delta_i is this candidate's distance to the NEAREST already-selected viewpoint:

    Delta_i = min_j [ alpha * theta_ij_norm + (1-alpha) * radial_diff_ij_norm ]
    theta_ij   = acos(dot(v_i, v_j))          (viewing-direction angle from the fixture)
    radial     = |r_i - r_j|

All terms live in [0,1] so the lambda / alpha mix is scale-free: theta / pi, radial / the
sampled radius span, and S_i itself (already a weighted sum of the [0,1] terms D, M, A, R,
weights summing to 1). S is used as-is, NOT min-max stretched over the feasible set --
stretching turns a modest real score gap into a maximal one and makes the greedy pick
collapse onto the single highest-scoring region. alpha ~ 0.8 -> angular coverage
dominates diversity. Stops at N_VIEWPOINTS_TARGET (clamped to [MIN, MAX] and the feasible
count). No brute-force combinatorics.
"""

import numpy as np

from fixture_scan import config


def select_diverse(feasible, fixture_center, cfg=config, log=print):
    n = len(feasible)
    if n == 0:
        return []
    target = int(np.clip(cfg.N_VIEWPOINTS_TARGET, cfg.N_VIEWPOINTS_MIN, cfg.N_VIEWPOINTS_MAX))
    if n <= cfg.N_VIEWPOINTS_MIN:
        if n < cfg.N_VIEWPOINTS_MIN:
            log(f"WARNING: only {n} feasible viewpoint(s) (< {cfg.N_VIEWPOINTS_MIN}); "
                "returning all -- the scan will be sparse")
        return list(feasible)

    v = np.array([c.viewing_direction / np.linalg.norm(c.viewing_direction)
                  for c in feasible])
    r = np.array([c.radius_m for c in feasible])
    S = np.array([c.total_score if np.isfinite(c.total_score) else 0.0 for c in feasible])
    r_span = max(cfg.RADIUS_MAX_M - cfg.RADIUS_MIN_M, 1e-6)

    theta = np.arccos(np.clip(v @ v.T, -1.0, 1.0)) / np.pi           # (n,n) in [0,1]
    radial = np.abs(r[:, None] - r[None, :]) / r_span                # (n,n) in [0,1]
    dist = cfg.DIVERSITY_ALPHA * theta + (1.0 - cfg.DIVERSITY_ALPHA) * radial

    selected = [int(np.argmax(S))]
    lam = cfg.DIVERSITY_LAMBDA
    while len(selected) < min(target, n):
        nearest = dist[:, selected].min(axis=1)      # Delta_i
        obj = lam * S + (1.0 - lam) * nearest
        obj[selected] = -np.inf
        selected.append(int(np.argmax(obj)))

    picks = [feasible[i] for i in selected]
    spread = np.degrees(np.arccos(np.clip(
        np.min([np.dot(a.viewing_direction, b.viewing_direction) / (
            np.linalg.norm(a.viewing_direction) * np.linalg.norm(b.viewing_direction))
            for i, a in enumerate(picks) for b in picks[i + 1:]] or [1.0]), -1, 1)))
    log(f"selected {len(picks)} viewpoints; max pairwise viewing-direction spread "
        f"{spread:.0f} deg")
    return picks
