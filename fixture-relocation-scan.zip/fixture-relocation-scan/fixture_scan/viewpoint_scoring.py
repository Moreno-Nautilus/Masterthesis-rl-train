"""§5 viewpoint quality score  S_i = w_d D + w_m M + w_a A + w_r R  (all terms in [0,1]).

M (marker quality) and A (FOV margin) are already normalised in [0,1] by
marker_visibility. D (closer camera-fixture distance is better) and R (orientation
closeness to the current camera orientation) are min-max normalised across the surviving
candidate set here. D is normalised over the actual sampled radius span so it is never
"excessively sensitive to small differences in distance" (spec §5).
"""

import numpy as np

from fixture_scan import config


def _minmax(values, invert=False):
    v = np.asarray(values, dtype=float)
    finite = v[np.isfinite(v)]
    if finite.size == 0:
        return np.full(v.shape, 0.5)
    lo, hi = float(finite.min()), float(finite.max())
    if hi - lo < 1e-9:
        return np.full(v.shape, 0.5)
    n = (v - lo) / (hi - lo)
    n[~np.isfinite(n)] = 0.0
    return 1.0 - n if invert else n


def score_candidates(candidates, cfg=config):
    """Assign `distance_score` (D), `orientation_score` (R) and `total_score` (S) on each
    live candidate in place. Rejected candidates are left untouched. Returns the list of
    live candidates sorted by descending S."""
    live = [c for c in candidates if c.alive]
    if not live:
        return []

    D = _minmax([c.radius_m for c in live], invert=True)      # closer -> higher
    rot = [c.rotation_from_current_deg for c in live]
    R = _minmax(rot, invert=True) if np.any(np.isfinite(rot)) else np.full(len(live), 0.5)

    w = cfg.SCORE_WEIGHTS
    for c, d, r in zip(live, D, R):
        c.distance_score = float(d)
        c.orientation_score = float(r)
        c.total_score = float(
            w["w_d"] * c.distance_score + w["w_m"] * c.marker_quality
            + w["w_a"] * c.fov_margin + w["w_r"] * c.orientation_score)

    live.sort(key=lambda c: c.total_score, reverse=True)
    return live
