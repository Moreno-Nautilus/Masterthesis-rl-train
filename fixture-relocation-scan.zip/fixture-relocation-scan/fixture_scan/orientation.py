"""§2 orientation optimisation -- per sampled position, over ALL markers.

For each marker: put the camera optical axis exactly on the camera->marker ray (so the
<=30 deg ray-angle constraint holds by construction), then search the 1-DOF roll about
that axis for the orientation closest (geodesic) to the current/initial camera
orientation. Full SO(3) is spanned by (ray direction from the fixed camera position) x
(roll) -- the position is already fixed by §1, so this is the whole reachable orientation
set for a straight-on view. Evaluate marker visibility (marker_visibility.evaluate_marker)
for each and keep the best (marker, orientation): highest M, ties broken by least rotation.

Simplification vs the spec's "find camera orientations for which the marker lies within
the FOV": rather than searching orientations for FOV containment we place the axis on the
ray (marker centred) and let evaluate_marker reject if the marker still spills out of the
image at that pose. Adequate for a single small ArUco tag centred in an 848x480 frame.
"""

import numpy as np

from fixture_scan import config
from fixture_scan.geometry import (
    look_rotation,
    make_T,
    normalize,
    rotation_geodesic_rad,
    roll_about_axis,
)
from fixture_scan.marker_visibility import evaluate_marker


def _best_roll(R0, axis, R_ref, n_steps):
    """Roll about `axis` (applied as R0 @ Rz_local) minimising geodesic(R_ref, R)."""
    if R_ref is None:
        return R0, float("nan")
    best_R, best_ang = R0, np.inf
    for roll in np.linspace(0.0, 2.0 * np.pi, n_steps, endpoint=False):
        R = R0 @ roll_about_axis([0.0, 0.0, 1.0], roll)   # +Z local == optical axis
        ang = rotation_geodesic_rad(R_ref, R)
        if ang < best_ang:
            best_R, best_ang = R, ang
    return best_R, float(np.degrees(best_ang))


def optimize_orientation(camera_position, markers, intr, R_cam_current=None, cfg=config):
    """Returns (marker_id, R_base_cam, metrics_dict) for the best marker at this position,
    or None if no marker is visible from here. `metrics_dict` carries M, A and the raw
    marker_visibility metrics plus `rotation_from_current_deg`."""
    cam_pos = np.asarray(camera_position, dtype=float).reshape(3)
    best = None
    for m in markers:
        view_dir = normalize(m.center_base - cam_pos)
        R0 = look_rotation(view_dir, up_hint=(0.0, 0.0, 1.0))
        R, rot_deg = _best_roll(R0, view_dir, R_cam_current, cfg.ORIENTATION_ROLL_STEPS)
        T_base_cam = make_T(R, cam_pos)
        ev = evaluate_marker(T_base_cam, m, intr, cfg)
        if not ev["accepted"]:
            continue
        metrics = dict(ev)
        metrics["rotation_from_current_deg"] = rot_deg
        key = (ev["M"], -(0.0 if np.isnan(rot_deg) else rot_deg))
        if best is None or key > best[0]:
            best = (key, m.id, R, metrics)

    if best is None:
        return None
    _key, marker_id, R, metrics = best
    return marker_id, R, metrics
