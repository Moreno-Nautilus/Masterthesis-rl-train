"""Loaders for the planner's static inputs on this rig (impl-plan §4).

- fixture pose + per-marker corner geometry in the MoveIt planning frame
  (`robot_defs.PLANNING_FRAME` == base_link), from
  `logs/.../fixture/nominal_world_pose.json` -- the JSON stores `board_origin` per arm
  base frame (`lbr_{one,two}_link_0`); this loader shifts it into base_link (a pure
  Y-translation, see robot_defs).
- camera intrinsics (rectified colour stream, d = 0): live from each camera's own
  `camera_info` topic (`load_intrinsics_live`, preferred for a real run), or from
  `~/fixture-relocation-scan/config/camera_intrinsics_realsense.yaml` (`load_intrinsics`,
  offline / mock)
- camera->flange extrinsic (`T_flange_cam`, optical frame) from
  `~/Masterthesis-vision/config/camera_extrinsics_realsense.yaml`

numpy + pyyaml only, no ROS. `ARM_TO_CAM_ID` / `DEFAULT_EXTRINSICS_YAML` are re-used from
`fixture_relocation_scan.scan_config` (that module is stdlib+numpy too).
"""

import json
import time
from dataclasses import dataclass

import numpy as np
import yaml

from fixture_scan import robot_defs
from fixture_scan.geometry import make_T, quat_wxyz_to_R, transform_points

# role -> wrist camera id (realsense2_camera namespacing; hold = left = lbr_one).
try:
    from fixture_relocation_scan.scan_config import ARM_TO_CAM_ID, DEFAULT_EXTRINSICS_YAML
except ImportError:  # keep inputs.py importable stand-alone
    ARM_TO_CAM_ID = {"hold": "realsense_1", "move": "realsense_2"}
    DEFAULT_EXTRINSICS_YAML = None

_BASE_KEY = {"hold": "lbr_one_link_0", "move": "lbr_two_link_0"}


@dataclass
class Marker:
    id: int
    size_m: float
    corners_base: np.ndarray   # (4, 3) marker corners in the planning frame (base_link)
    center_base: np.ndarray    # (3,)
    normal_base: np.ndarray    # (3,) unit surface normal (board +Z in base_link)


@dataclass
class FixtureInputs:
    role: str
    base_frame: str               # == robot_defs.PLANNING_FRAME (base_link)
    T_base_board: np.ndarray       # (4, 4) board frame in the planning frame (base_link)
    fixture_center_base: np.ndarray  # (3,) centre of the sampling sphere = marker centroid
    markers: list                  # [Marker, ...]


def load_fixture(nominal_pose_path, role) -> FixtureInputs:
    """Fixture pose + marker-corner geometry in the planning frame (base_link).

    The nominal JSON stores `board_origin` in each arm's own base frame
    (`lbr_{one,two}_link_0`); everything here is shifted into base_link by the fixed
    `base_link <- arm link_0` offset (pure translation, robot_defs). Marker corners come
    from `opencv.board_obj_points_m` (the exact 4 corners per marker, in the board frame)
    transformed by the shifted `T_base_board` -- equivalent to the impl-plan's "offset
    each marker origin by size_m in the shared marker plane", but no chaining.
    """
    if role not in _BASE_KEY:
        raise ValueError(f"role must be hold|move, got {role!r}")
    with open(nominal_pose_path, "r") as fp:
        nominal = json.load(fp)

    off = robot_defs.arm_base_origin_in_planning(role)   # base_link <- arm link_0
    bo = nominal["board_origin"][_BASE_KEY[role]]
    R_base_board = quat_wxyz_to_R(bo["quaternion_wxyz"])
    T_base_board = make_T(R_base_board, np.array(bo["position_m"], dtype=float) + off)

    op = nominal["opencv"]
    board_ids = list(op["board_ids"])
    obj = np.array(op["board_obj_points_m"], dtype=float)   # (N, 4, 3) board frame
    corners_base = transform_points(T_base_board, obj)       # (N, 4, 3) base_link
    normal_base = R_base_board @ np.array([0.0, 0.0, 1.0])

    size_by_id = {m["id"]: float(m["size_m"]) for m in nominal.get("markers", [])}
    markers = []
    for j, mid in enumerate(board_ids):
        c = corners_base[j]
        markers.append(Marker(
            id=int(mid),
            size_m=size_by_id.get(int(mid), float(op["marker_length_m"])),
            corners_base=c,
            center_base=c.mean(axis=0),
            normal_base=normal_base / np.linalg.norm(normal_base),
        ))

    center = np.mean([m.center_base for m in markers], axis=0)
    return FixtureInputs(
        role=role, base_frame=robot_defs.PLANNING_FRAME, T_base_board=T_base_board,
        fixture_center_base=center, markers=markers,
    )


@dataclass
class Intrinsics:
    width: int
    height: int
    fx: float
    fy: float
    cx: float
    cy: float
    K: np.ndarray   # (3, 3)
    d: np.ndarray   # (5,) -- zero for the rectified stream

    def project(self, p_cam: np.ndarray):
        """Pinhole-project an (..., 3) array of points in the optical frame (+Z fwd,
        +X right, +Y down) to pixel (..., 2). Points with z <= 0 come back as NaN."""
        p = np.asarray(p_cam, dtype=float)
        z = p[..., 2]
        with np.errstate(divide="ignore", invalid="ignore"):
            u = self.fx * p[..., 0] / z + self.cx
            v = self.fy * p[..., 1] / z + self.cy
        uv = np.stack([u, v], axis=-1)
        uv[z <= 1e-6] = np.nan
        return uv


def load_intrinsics(intrinsics_yaml_path, cam_id) -> Intrinsics:
    """Offline / mock path: pinhole intrinsics from
    `config/camera_intrinsics_realsense.yaml`. For a live run prefer
    `load_intrinsics_live` -- read each camera's own `camera_info` instead of the file."""
    with open(intrinsics_yaml_path, "r") as fp:
        entry = yaml.safe_load(fp)[cam_id]
    K = np.array(entry["K"], dtype=float).reshape(3, 3)
    return Intrinsics(
        width=int(entry["width"]), height=int(entry["height"]),
        fx=float(entry["fx"]), fy=float(entry["fy"]),
        cx=float(entry["cx"]), cy=float(entry["cy"]),
        K=K, d=np.array(entry.get("d", [0.0] * 5), dtype=float),
    )


def _camera_info_topic(cam_id) -> str:
    """`cam_id`'s CameraInfo topic -- reuse the sibling tracker's live-confirmed map,
    fall back to realsense2_camera's default namespacing."""
    try:
        from fixture_relocation_scan.fixture_tracker import CAMERA_TOPICS
        return CAMERA_TOPICS[cam_id][1]
    except Exception:
        return f"/{cam_id}/camera/color/camera_info"


def intrinsics_from_camera_info(msg) -> Intrinsics:
    """Build `Intrinsics` from a `sensor_msgs/CameraInfo` (rectified colour stream ->
    `k` == `p`'s left 3x3, `d` all-zero)."""
    K = np.array(msg.k, dtype=float).reshape(3, 3)
    d = np.array(list(msg.d), dtype=float)
    if d.size < 5:
        d = np.pad(d, (0, 5 - d.size))
    return Intrinsics(
        width=int(msg.width), height=int(msg.height),
        fx=float(K[0, 0]), fy=float(K[1, 1]), cx=float(K[0, 2]), cy=float(K[1, 2]),
        K=K, d=d,
    )


def load_intrinsics_live(node, cam_id, *, timeout_s=5.0):
    """Live path: grab one `CameraInfo` from `cam_id`'s own topic and build an
    `Intrinsics`. Returns None if nothing arrives within `timeout_s` -- the caller decides
    whether to fall back to the YAML or fail. rclpy / sensor_msgs imports are
    function-local so this module stays import-safe with no ROS."""
    import rclpy
    from rclpy.qos import HistoryPolicy, QoSProfile, ReliabilityPolicy
    from sensor_msgs.msg import CameraInfo

    topic = _camera_info_topic(cam_id)
    got = {}
    qos = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT,
                     history=HistoryPolicy.KEEP_LAST, depth=1)
    sub = node.create_subscription(
        CameraInfo, topic, lambda m: got.setdefault("msg", m), qos)
    deadline = time.monotonic() + timeout_s
    try:
        while rclpy.ok() and "msg" not in got and time.monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=0.1)
    finally:
        node.destroy_subscription(sub)
    if "msg" not in got:
        return None
    return intrinsics_from_camera_info(got["msg"])


def load_flange_to_camera(extrinsics_yaml_path, cam_id) -> np.ndarray:
    """T_flange_cam (4x4): p_flange = R @ p_cam + t, R/t from
    camera_extrinsics_realsense.yaml (row-major R). Same layout the rest of the package
    (fixture_tracker / plan_and_display) reads."""
    with open(extrinsics_yaml_path, "r") as fp:
        entry = yaml.safe_load(fp)[cam_id]
    return make_T(np.array(entry["R"], dtype=float).reshape(3, 3),
                  np.array(entry["t"], dtype=float).reshape(3))
