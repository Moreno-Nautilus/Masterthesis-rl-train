"""§6 IK feasibility + weighted branch selection.

For each candidate (walked in S-ranked order so the seed chain follows viewpoint quality):
fire `N_IK_SOLUTIONS` `/compute_ik` calls CONCURRENTLY with seeds = [q_seed, then random
joint-limit draws from the seeded RNG]; dedupe near-identical results; joint-limit +
`/check_state_validity` each (idle arm pinned at `other_arm_q` -> the parked arm is a
static obstacle, impl-plan D1); keep the candidate if >=1 solution is collision-free;
select  q* = argmin ||q - q_seed||_W  (W = config.W_COST, D5). First seed is `q_current`;
thereafter the previous selected config.

IK targets the pdz gripper TCP (`T_base_tcp`, tip link lbr_*_pdz_gripper_tcp, group
arm_one/arm_two) -- the same link the tiered trajectory planner constrains.
"""

import numpy as np

from fixture_scan import config, robot_defs


def _dedupe(solutions, tol):
    kept = []
    for q in solutions:
        if all(np.max(np.abs(q - k)) > tol for k in kept):
            kept.append(q)
    return kept


def _seeds(q_seed, rng, n, limits):
    seeds = [np.asarray(q_seed, dtype=float)]
    for _ in range(max(0, n - 1)):
        seeds.append(rng.uniform(-limits, limits))
    return seeds


def filter_by_ik(ranked_candidates, role, mg_client, *, q_current, other_arm_q,
                 cfg=config, log=print):
    """Mutates candidates in place (sets `ik_solutions`, `selected_joint_configuration`,
    `ik_seed_dist_W`, `collision_free`, or `reject("ik", ...)`). Returns the feasible
    subset in the same (S-ranked) order."""
    group, _base, tip, _jn = robot_defs.ARM[role]
    rng = np.random.default_rng(cfg.RNG_SEED + 1)
    limits = np.asarray(cfg.JOINT_LIMITS_RAD, dtype=float)
    q_seed = np.asarray(q_current, dtype=float)
    feasible = []
    distinct_counts = []

    for c in ranked_candidates:
        if not c.alive:
            continue
        seeds = _seeds(q_seed, rng, cfg.N_IK_SOLUTIONS, limits)
        raw = mg_client.compute_ik_batch(
            role, c.T_base_tcp, seeds, other_arm_q=other_arm_q, tip_link=tip, group=group)
        raw = [q for q in raw if np.all(np.abs(q) <= limits + 1e-6)]
        distinct = _dedupe(raw, cfg.IK_DEDUP_TOL_RAD)[:cfg.N_IK_SOLUTIONS]
        distinct_counts.append(len(distinct))
        if not distinct:
            c.reject("ik", "no IK solution (joint-limit-valid) for the TCP pose")
            continue

        collision_free = []
        for q in distinct:
            try:
                ok = mg_client.check_state_validity(
                    role, q, other_arm_q=other_arm_q, group=group)
            except RuntimeError as exc:
                log(f"[{role}] cand {c.index}: validity check failed ({exc})")
                ok = False
            if ok:
                collision_free.append(q)
        if not collision_free:
            c.reject("ik", f"all {len(distinct)} IK branch(es) in collision")
            continue

        dists = [cfg.weighted_joint_norm(q - q_seed) for q in collision_free]
        best = int(np.argmin(dists))
        c.ik_solutions = collision_free
        c.selected_joint_configuration = collision_free[best]
        c.ik_seed_dist_W = float(dists[best])
        c.collision_free = True
        feasible.append(c)
        q_seed = c.selected_joint_configuration   # chain the seed to the last selection

    if distinct_counts:
        arr = np.array(distinct_counts)
        log(f"[{role}] IK: {len(feasible)}/{len(distinct_counts)} candidates feasible; "
            f"distinct IK branches/candidate mean {arr.mean():.2f} (min {arr.min()}, "
            f"max {arr.max()}) -- impl-plan U5")
    return feasible
