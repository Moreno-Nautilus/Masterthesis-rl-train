"""Robot frame / group / joint definitions -- the single source of truth.

Moved here (2026-09-06, viewpoint-planner port) from `arm_planner.py`; that module now
re-imports `ARM` / `T_EE_TCP` from here so the base-frame / TCP-link / joint-name / EE->TCP
offset definitions live in exactly one place. `tools/plan_and_display.py` still imports
`_ARM` / `_T_EE_TCP` from `arm_planner` (unchanged spelling) and keeps working.

Pure stdlib + numpy -- importable with no ROS.
"""

import numpy as np

# scan arm role -> (planning group, base frame, TCP tip link, ordered joint names).
# arm_one / arm_two tip at the pdz gripper TCP (grasp-centre, midpoint of the 30 mm finger
# pads) -- NOT arm_one_flange / lbr_one_link_ee. Planning the TCP keeps the goal + any
# height floor in fingertip terms (SRDF: chain lbr_{one,two}_link_0 -> lbr_{one,two}_tip).
ARM = {
    "hold": ("arm_one", "lbr_one_link_0", "lbr_one_pdz_gripper_tcp",
             [f"lbr_one_A{i}" for i in range(1, 8)]),
    "move": ("arm_two", "lbr_two_link_0", "lbr_two_pdz_gripper_tcp",
             [f"lbr_two_A{i}" for i in range(1, 8)]),
}

# role -> flange planning group (chain lbr_{one,two}_link_0 -> lbr_{one,two}_link_ee), for
# a flange-pose /compute_ik that mirrors the old arm_ik path.
FLANGE_GROUP = {"hold": "arm_one_flange", "move": "arm_two_flange"}

ROLE_TO_ARM = {"hold": "lbr_one", "move": "lbr_two"}
OTHER_ROLE = {"hold": "move", "move": "hold"}

# lbr_*_link_ee -> lbr_*_pdz_gripper_tcp, fixed, from the URDF gripper_mount + tcp joints:
# Rz(-90 deg) then +0.1355 m along Z. A FLANGE pose maps to the constrained TCP pose as
# T_base_tcp = T_base_flange @ T_EE_TCP.
T_EE_TCP = np.array([
    [0.0, 1.0, 0.0, 0.0],
    [-1.0, 0.0, 0.0, 0.0],
    [0.0, 0.0, 1.0, 0.1355],
    [0.0, 0.0, 0.0, 1.0],
])
T_TCP_EE = np.linalg.inv(T_EE_TCP)

# --- planning frame ---------------------------------------------------------------------
# The whole viewpoint planner works in the MoveIt planning frame of the dual-arm model:
# the URDF root `base_link` (lbr_dual_arm.xacro). IK / FK / CHOMP targets, the sampled
# viewpoint geometry, the debug viz and the fixture collision box are all expressed here,
# matching lbr_dual_arm_bringup/config/mock_scene_objects.yaml and
# lbr_dual_arm_moveit_config's moveit.rviz Fixed Frame. `base_link` -> each arm's link_0
# is a PURE Y-TRANSLATION (no rotation, no z offset) -- lbr_dual_arm.xacro's
# lbr_one_base_joint xyz="0 -0.42 0", lbr_two_base_joint xyz="0 0.42 0" -- so a point's z
# coordinate is identical in base_link and in either arm base frame.
PLANNING_FRAME = "base_link"

_ARM_BASE_ORIGIN_IN_PLANNING = {
    "hold": np.array([0.0, -0.42, 0.0]),
    "move": np.array([0.0, 0.42, 0.0]),
}


def arm_base_origin_in_planning(role: str) -> np.ndarray:
    """Position (3,) of `role`'s arm link_0 origin in the planning frame (base_link)."""
    return _ARM_BASE_ORIGIN_IN_PLANNING[role].copy()


def T_planning_from_arm_base(role: str) -> np.ndarray:
    """4x4 mapping a pose expressed in `role`'s arm link_0 frame into the planning frame
    (base_link). Pure translation -- see PLANNING_FRAME."""
    T = np.eye(4)
    T[:3, 3] = _ARM_BASE_ORIGIN_IN_PLANNING[role]
    return T


def joint_names(role: str):
    return list(ARM[role][3])


def base_frame(role: str) -> str:
    """`role`'s ARM link_0 frame name -- NOT the planner's working frame. Planner geometry
    and all move_group requests use PLANNING_FRAME (base_link); this is only for callers
    that genuinely need the per-arm frame name."""
    return ARM[role][1]


def tcp_link(role: str) -> str:
    return ARM[role][2]
