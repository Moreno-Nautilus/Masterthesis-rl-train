"""All thresholds / weights / seeds for the viewpoint planner -- the single place to retune.

Spec basis: `fixture_scanning_viewpoint_planner.md` §12 (parameters to expose) and the
2026-09-06 planning-session decisions recorded in
`~/Fabrica-pdz/docs/fixture_scanning_viewpoint_planner_implementation_plan.md` (D1-D6, §4).

Dependency-light on purpose (stdlib + numpy): every module in `fixture_scan/` imports this,
and the geometry front-end (Phase 1) must stay importable with no ROS.

`config_sha()` hashes this file's source so `scan_program.json:meta.config_sha` records
exactly which constants a program was generated under.
"""

import hashlib
import os

import numpy as np

# --- reproducibility -------------------------------------------------------------------
RNG_SEED = 42

# --- §1 candidate position sampling ---------------------------------------------------
N_SAMPLES = 200
# Spec §12 nominal is [0.10, 0.40] m, but THESE are CAMERA-position radii and the wrist
# camera sits ~0.09 m in front of the pdz gripper TCP along the tool axis (which points at
# the fixture): a camera that close drives the TCP/fingertip into the table. That offset
# is handled where it belongs -- the Phase-1 `workspace_filter.tcp_above_floor` gate
# converts each sampled camera pose through `tcp_conversion` to the constrained TCP before
# testing MIN_TCP_Z_M. An earlier pass instead widened this band to [0.30, 0.65] /
# elevation [35, 82] to clear a *raised* (0.28 m) floor; that floor is reverted (see
# MIN_TCP_Z_M below) but the band is LEFT wide pending a geometry-funnel re-run -- narrow
# toward [0.24, 0.50] / elevation [~15, 82] only if the survivor set / marker score M
# stays poor. The 0.75 m base-distance filter is the other hard gate. See
# docs/fixture_scanning_viewpoint_planner_session_2026-09-06_handoff.md.
RADIUS_MIN_M = 0.30
RADIUS_MAX_M = 0.65
# "upper hemisphere only" -- elevation from the fixture plane (0 = grazing, 90 = straight
# above). 82 (not 90) keeps off the handoff-§4 dead-centre singular pose. The 35 deg floor
# rides with the wide radius band above -- revisit the two together in the funnel re-run.
MIN_ELEVATION_DEG = 35.0
MAX_ELEVATION_DEG = 82.0

# --- §2 orientation optimisation ----------------------------------------------------
# Camera optical axis must sit within this of the camera->marker ray.
MAX_MARKER_RAY_ANGLE_DEG = 30.0
# Roll-about-optical-axis search resolution for the "min rotation from current cam
# orientation" objective (closed enough; 200 candidates x this is cheap).
ORIENTATION_ROLL_STEPS = 72

# --- §3 marker visibility (hard filters + M / A scores) -----------------------------
# Projected ArUco marker EDGE length in px. Below MIN -> hard reject; at/above GOOD ->
# full marker-size credit. Tuned to this rig's achievable standoff: a 27 mm marker at
# fx~436 projects to ~24 px at 0.5 m, ~18 px at 0.65 m (realsense colour 848x480).
MARKER_MIN_PROJECTED_PX = 8.0
MARKER_GOOD_PROJECTED_PX = 28.0
# Marker viewing / incidence angle (between the camera->marker ray and the marker's
# surface normal). Above MAX -> hard reject; at/below GOOD -> full incidence credit.
MARKER_MAX_VIEW_ANGLE_DEG = 60.0
MARKER_GOOD_VIEW_ANGLE_DEG = 12.0
# Camera->marker distance band that reads "sensible". Outside [MIN, MAX] the distance
# term of M decays; it is NOT on its own a hard reject (the radius sampling already
# bounds it, and workspace/IK are the hard gates).
MARKER_DIST_GOOD_MIN_M = 0.12
MARKER_DIST_GOOD_MAX_M = 0.35
# FOV margin: min distance of any projected marker corner to the image border, in px.
# Below MIN (or any corner outside the image) -> hard reject; at/above GOOD -> full A.
FOV_MARGIN_MIN_PX = 8.0
FOV_MARGIN_GOOD_PX = 45.0

# --- §4 hard workspace filter ------------------------------------------------------
MAX_TCP_BASE_DIST_M = 0.75

# --- §5 viewpoint quality score S_i = w_d D + w_m M + w_a A + w_r R -----------------
SCORE_WEIGHTS = {"w_d": 0.25, "w_m": 0.35, "w_a": 0.20, "w_r": 0.20}

# --- §6 IK feasibility -----------------------------------------------------------------
N_IK_SOLUTIONS = 5
IK_TIMEOUT_S = 0.05          # per /compute_ik call; kinematics_solver_timeout is 0.005
IK_GATHER_TIMEOUT_S = 8.0    # wall-clock budget for a candidate's whole seed batch
IK_DEDUP_TOL_RAD = np.radians(3.0)   # solutions closer than this (max-abs joint) merge
# LBR iiwa7 revolute limits [rad], symmetric, from
# lbr_description/urdf/iiwa7/joint_limits.yaml via the moveit urdf.xacro (A1..A7).
JOINT_LIMITS_RAD = np.array([2.97, 2.09, 2.97, 2.09, 2.97, 2.09, 3.05])

# --- §7 diverse viewpoint selection -------------------------------------------------
N_VIEWPOINTS_MIN = 5
N_VIEWPOINTS_MAX = 10
N_VIEWPOINTS_TARGET = 8
DIVERSITY_LAMBDA = 0.5   # weight on S_i vs diversity Delta_i in the greedy pick
DIVERSITY_ALPHA = 0.8    # weight on angular vs radial diversity inside Delta_i

# --- per-joint weighting W for the joint-space norm  ||dq||_W = sqrt(sum W_COST_i dq_i^2)
# REVERTED to UNIFORM (2026-09-06): the D5 "mobility multipliers" made A1 (base yaw) cost
# 0.10 -- effectively free -- so the IK branch pick and 2-opt ordering swung the base
# joint through huge arcs between viewpoints (the robot "spun ~360 deg around its base").
# D5 vector kept here for a one-line re-enable if a future run shows uniform weighting
# over-penalises the wrist:
#   JOINT_MOBILITY = np.array([10.0, 5.0, 1.0, 1.0, 1.0, 3.0, 5.0])   # A1..A7, D5
JOINT_MOBILITY = np.ones(7)
W_COST = 1.0 / JOINT_MOBILITY   # uniform -> ||dq||_W == plain Euclidean joint distance

# --- §8 execution ordering -----------------------------------------------------------
ORDERING_TWO_OPT_MAX_PASSES = 20

# --- §9 tiered trajectory generation ------------------------------------------------
# Tier 1: straight-line joint interp resampled so no joint steps more than this between
# consecutive waypoints; then a denser collision check at COLLISION_CHECK_STEP_RAD.
STRAIGHT_LINE_MAX_JOINT_STEP_RAD = np.radians(2.0)
COLLISION_CHECK_STEP_RAD = np.radians(1.0)
# pdz fingertip-clearance floors, both on the TCP (grasp centre), checked via FK on every
# path waypoint -- the TRUE physical fingertip-vs-table limits. The Phase-1
# `workspace_filter.tcp_above_floor` gate already converts each sampled CAMERA pose
# through `tcp_conversion` to the constrained TCP before testing MIN_TCP_Z_M, so the
# camera-is-~0.09-m-ahead-of-the-TCP offset is accounted for there -- these must NOT also
# carry it (an earlier pass raised them to 0.28 / 0.265, double-counting the offset and
# needlessly rejecting usable viewpoints; reverted 2026-09-06). CHOMP / state-validity
# floor-awareness now comes from the `table` CollisionObject in the planning scene
# (move_group_ns.launch.py mode:=mock) alongside the fixture box from scene_publisher.py;
# this FK check stays as the belt-and-braces guard. Endpoints / selected viewpoints get
# MIN_TCP_Z_M; interior path waypoints (transient joint-lerp / CHOMP dips through free
# space) get MIN_TCP_Z_INTERIOR_M.
MIN_TCP_Z_M = 0.19
MIN_TCP_Z_INTERIOR_M = 0.175
MAX_RESELECT = 3     # whole-program reselect iterations before failing with a report
# Tier 2: CHOMP via move_group /move_action, pipeline id "chomp", straight-line seed.
CHOMP_PLANNING_TIME_S = 5.0
CHOMP_PLANNING_ATTEMPTS = 6
CHOMP_GOAL_JOINT_TOL_RAD = 0.01   # loose enough that CHOMP's own smoothing can settle
# Overrides pushed into the request (also see chomp_planning.yaml added to the moveit
# config in Phase 0). Kept here so a client-side retune needs no move_group restart for
# the params MoveIt reads per-request.
CHOMP_PARAMS = {
    "ridge_factor": 0.01,
    "collision_clearance": 0.10,
    "collision_threshold": 0.07,
}

# --- static fixture collision box (scene_publisher.py) -----------------------------
# The scanning arm's own view of the fixture (plus the extra camera bolted on top of it),
# published ONCE into the namespaced planning scene from the INITIAL fixture-centre
# estimate so /check_state_validity + CHOMP keep the arm and its trajectories clear of it.
# The `table` and the always-present `mock_box` come from
# lbr_dual_arm_bringup/config/mock_scene_objects.yaml (published by
# publish_mock_scene_objects.py, wired into move_group_ns.launch.py for mode:=mock); this
# box is separate because its pose is a runtime input to the planner, not a static YAML
# literal. FUTURE WORK: not updated mid-run -- a refined fixture pose does not move it.
FIXTURE_BOX_ID = "fixture_scan_fixture"
FIXTURE_BOX_SIZE_M = (0.30, 0.30, 0.10)   # x, y footprint; 0.10 m tall
# base_link z of the table's upper surface. MUST match mock_scene_objects.yaml's `table`
# (top face at -0.025; the two KUKA bases sit on a ~2.5 cm riser above the table). The
# fixture box's BOTTOM face rests on this plane.
TABLE_TOP_Z_M = -0.025

# --- static scene boxes (scene_publisher.publish_static_scene) ---------------------
# `table` + `mock_box` -- the always-present obstacles. On mode:=mock these are also
# published by publish_mock_scene_objects.py (move_group_ns.launch.py); the planner
# re-asserts them (idempotent ADD by id) so mode:=hardware, where that node does NOT run,
# gets the same collision world. Vendored copy of the bringup YAML ships in this package so
# the container (no ~/franka_ros2_ws) has it; override with FIXTURE_SCAN_STATIC_SCENE_YAML.
STATIC_SCENE_OBJECTS_YAML = os.environ.get(
    "FIXTURE_SCAN_STATIC_SCENE_YAML",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "mock_scene_objects.yaml"),
)

# --- MoveIt handles ----------------------------------------------------------------
ROBOT_NAME = os.environ.get("FIXTURE_SCAN_ROBOT_NAME", "lbr_dual_arm")

# --- default input artifact paths (overridable on the CLI) -------------------------
DEFAULT_PLAN = "plumbers_block_new_3"
DEFAULT_NOMINAL_POSE = os.path.expanduser(
    f"~/Fabrica-pdz/logs/kuka_pdz8_cm_aruco/{DEFAULT_PLAN}/fixture/nominal_world_pose.json"
)
DEFAULT_MOTION_PKL = os.path.expanduser(
    f"~/Fabrica-pdz/logs/kuka_pdz8_cm_aruco/{DEFAULT_PLAN}/motion.pkl"
)
DEFAULT_INTRINSICS_YAML = os.path.expanduser(
    "~/fixture-relocation-scan/config/camera_intrinsics_realsense.yaml"
)
DEFAULT_EXTRINSICS_YAML = os.environ.get(
    "CAMERA_EXTRINSICS_YAML",
    os.path.expanduser("~/Masterthesis-vision/config/camera_extrinsics_realsense.yaml"),
)

_THIS_FILE = os.path.abspath(__file__)


def config_sha() -> str:
    """SHA-1 (first 12 hex) of this file's source -- recorded in scan_program meta so a
    program is traceable to the exact constants it was generated under."""
    with open(_THIS_FILE, "rb") as fp:
        return hashlib.sha1(fp.read()).hexdigest()[:12]


def weighted_joint_norm(dq) -> float:
    """||dq||_W  with W = W_COST (currently uniform -> plain Euclidean). `dq` a (7,)
    array-like of joint deltas [rad]."""
    dq = np.asarray(dq, dtype=float)
    return float(np.sqrt(np.sum(W_COST * dq * dq)))
