"""§8 optimise execution order (independent of sampling order).

Transition cost  C(i,j) = ||q_i - q_j||_W  (W = config.W_COST, D5). Nearest-neighbour
init from whichever selected viewpoint is closest to `q_current`, then 2-opt local search
on the open path (the q_current start is fixed, it is not a visited node). No brute force.
"""

import numpy as np

from fixture_scan import config


def _path_cost(order, C, start_costs):
    total = start_costs[order[0]]
    for a, b in zip(order[:-1], order[1:]):
        total += C[a, b]
    return total


def order_viewpoints(selected, q_current, cfg=config, log=print):
    n = len(selected)
    if n <= 2:
        return list(selected)

    Q = np.array([c.selected_joint_configuration for c in selected], dtype=float)
    q0 = np.asarray(q_current, dtype=float)
    C = np.array([[cfg.weighted_joint_norm(Q[i] - Q[j]) for j in range(n)]
                  for i in range(n)])
    start_costs = np.array([cfg.weighted_joint_norm(Q[i] - q0) for i in range(n)])

    # nearest-neighbour from the viewpoint closest to q_current
    unvisited = set(range(n))
    order = [int(np.argmin(start_costs))]
    unvisited.discard(order[0])
    while unvisited:
        last = order[-1]
        nxt = min(unvisited, key=lambda j: C[last, j])
        order.append(nxt)
        unvisited.discard(nxt)

    # 2-opt (open path; index 0's predecessor is the fixed q_current start)
    best = order
    best_cost = _path_cost(best, C, start_costs)
    for _ in range(cfg.ORDERING_TWO_OPT_MAX_PASSES):
        improved = False
        for i in range(n - 1):
            for k in range(i + 1, n):
                cand = best[:i] + best[i:k + 1][::-1] + best[k + 1:]
                cost = _path_cost(cand, C, start_costs)
                if cost + 1e-9 < best_cost:
                    best, best_cost, improved = cand, cost, True
        if not improved:
            break

    nn_cost = _path_cost(order, C, start_costs)
    log(f"ordering: NN cost {nn_cost:.3f} -> 2-opt {best_cost:.3f} "
        f"(||dq||_W, {n} viewpoints)")
    return [selected[i] for i in best]
