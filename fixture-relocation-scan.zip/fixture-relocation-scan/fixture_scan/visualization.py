"""§13 RViz debug output.

`publish_debug_markers()` -> a `visualization_msgs/MarkerArray` on
`/<robot>/fixture_scan/debug_markers`:
  * all ~200 sampled positions           (grey, small)
  * visibility-rejected                   (red)
  * workspace-rejected                    (orange)
  * IK-feasible                           (blue)
  * final selected viewpoints             (green, larger) + an index label + a
    viewing-direction arrow + the selected marker id
`publish_display_trajectory()` -> the concatenated segment paths as a
`moveit_msgs/DisplayTrajectory` on `/<robot>/display_planned_path`.

Import-safe with no ROS at module load (rclpy / msg imports are inside the functions).
"""

import numpy as np


def _rgba(r, g, b, a=1.0):
    from std_msgs.msg import ColorRGBA
    return ColorRGBA(r=float(r), g=float(g), b=float(b), a=float(a))


def _sphere_points(ns, mid, frame, points, color, scale):
    from geometry_msgs.msg import Point
    from visualization_msgs.msg import Marker
    m = Marker()
    m.header.frame_id = frame
    m.ns = ns
    m.id = mid
    m.type = Marker.SPHERE_LIST
    m.action = Marker.ADD
    m.scale.x = m.scale.y = m.scale.z = scale
    m.color = color
    m.points = [Point(x=float(p[0]), y=float(p[1]), z=float(p[2])) for p in points]
    m.pose.orientation.w = 1.0
    return m


def build_marker_array(frontend, ordered=None, feasible=None):
    """frontend == pipeline.run_geometry_frontend output."""
    from visualization_msgs.msg import Marker, MarkerArray
    from geometry_msgs.msg import Point

    frame = frontend["fixture"].base_frame
    cands = frontend["candidates"]
    arr = MarkerArray()

    arr.markers.append(_sphere_points(
        "sampled", 0, frame, [c.camera_position for c in cands], _rgba(.6, .6, .6, .5), .008))
    arr.markers.append(_sphere_points(
        "rej_visibility", 1, frame,
        [c.camera_position for c in cands if c.rejected_stage == "visibility"],
        _rgba(.85, .1, .1, .8), .012))
    arr.markers.append(_sphere_points(
        "rej_workspace", 2, frame,
        [c.camera_position for c in cands if c.rejected_stage == "workspace"],
        _rgba(.95, .55, .1, .8), .012))
    if feasible:
        arr.markers.append(_sphere_points(
            "ik_feasible", 3, frame, [c.camera_position for c in feasible],
            _rgba(.15, .35, .9, .9), .016))

    for i, c in enumerate(ordered or []):
        arr.markers.append(_sphere_points(
            "selected", 10 + i, frame, [c.camera_position], _rgba(.1, .8, .2, 1.), .028))
        arrow = Marker()
        arrow.header.frame_id = frame
        arrow.ns, arrow.id, arrow.type, arrow.action = "view_dir", 40 + i, Marker.ARROW, Marker.ADD
        tip = c.camera_position + 0.08 * (c.T_base_cam[:3, 2] if c.T_base_cam is not None
                                          else -c.viewing_direction)
        arrow.points = [Point(x=float(c.camera_position[0]), y=float(c.camera_position[1]),
                              z=float(c.camera_position[2])),
                        Point(x=float(tip[0]), y=float(tip[1]), z=float(tip[2]))]
        arrow.scale.x, arrow.scale.y, arrow.scale.z = 0.004, 0.010, 0.0
        arrow.color = _rgba(.1, .8, .2, 1.)
        arrow.pose.orientation.w = 1.0
        arr.markers.append(arrow)

        txt = Marker()
        txt.header.frame_id = frame
        txt.ns, txt.id, txt.type, txt.action = "order", 70 + i, Marker.TEXT_VIEW_FACING, Marker.ADD
        txt.pose.position.x, txt.pose.position.y = float(c.camera_position[0]), float(c.camera_position[1])
        txt.pose.position.z = float(c.camera_position[2] + 0.03)
        txt.pose.orientation.w = 1.0
        txt.scale.z = 0.022
        txt.color = _rgba(1., 1., 1., 1.)
        txt.text = f"{i}:m{c.selected_marker_id}"
        arr.markers.append(txt)
    return arr


def _latched_qos():
    from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile
    return QoSProfile(depth=1, history=HistoryPolicy.KEEP_LAST,
                      durability=DurabilityPolicy.TRANSIENT_LOCAL)


def publish_debug_markers(node, frontend, ordered=None, feasible=None, robot_name="lbr_dual_arm"):
    import time
    from visualization_msgs.msg import MarkerArray
    topic = f"/{robot_name}/fixture_scan/debug_markers"
    pub = node.create_publisher(MarkerArray, topic, _latched_qos())
    arr = build_marker_array(frontend, ordered=ordered, feasible=feasible)
    for _ in range(3):
        pub.publish(arr)
        time.sleep(0.2)
    node.get_logger().info(
        f"published {len(arr.markers)} debug marker groups on {topic} (latched). "
        f"In RViz: Add -> By topic -> {topic} -> MarkerArray")


def publish_display_trajectory(node, role, segments, q_now, robot_name="lbr_dual_arm"):
    from builtin_interfaces.msg import Duration as DurationMsg
    from moveit_msgs.msg import DisplayTrajectory, RobotState, RobotTrajectory
    from sensor_msgs.msg import JointState
    from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
    from fixture_scan import robot_defs

    joint_names = robot_defs.joint_names(role)
    jt = JointTrajectory()
    jt.header.frame_id = robot_defs.PLANNING_FRAME   # joint-space anyway; kept consistent
    jt.joint_names = list(joint_names)
    t = 0.0
    for seg in segments:
        for q in seg.path[1:]:
            t += 0.1
            pt = JointTrajectoryPoint()
            pt.positions = [float(x) for x in q]
            pt.time_from_start = DurationMsg(sec=int(t), nanosec=int((t % 1.0) * 1e9))
            jt.points.append(pt)

    rt = RobotTrajectory()
    rt.joint_trajectory = jt
    start = RobotState()
    start.joint_state = JointState(name=list(q_now.keys()),
                                   position=[float(v) for v in q_now.values()])
    start.is_diff = True
    disp = DisplayTrajectory()
    disp.model_id = robot_name
    disp.trajectory_start = start
    disp.trajectory.append(rt)
    pub = node.create_publisher(
        DisplayTrajectory, f"/{robot_name}/display_planned_path", _latched_qos())
    import time
    for _ in range(3):
        pub.publish(disp)
        time.sleep(0.2)
    node.get_logger().info(f"published DisplayTrajectory ({len(jt.points)} points)")
