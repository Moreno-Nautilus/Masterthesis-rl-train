"""§2 camera pose -> flange pose -> constrained TCP pose.

`T_flange_cam` (camera_extrinsics_realsense.yaml) maps points cam->flange
(p_flange = R p_cam + t), so  T_base_flange = T_base_cam @ inv(T_flange_cam).
`robot_defs.T_EE_TCP` then maps the flange (== lbr_*_link_ee) to the pdz gripper TCP the
trajectory planner constrains:  T_base_tcp = T_base_flange @ T_EE_TCP.
"""

import numpy as np

from fixture_scan import robot_defs
from fixture_scan.geometry import invert_T


def camera_pose_to_flange_tcp(T_base_cam, T_flange_cam):
    """Returns (T_base_flange, T_base_tcp), both 4x4."""
    T_base_cam = np.asarray(T_base_cam, dtype=float)
    T_base_flange = T_base_cam @ invert_T(np.asarray(T_flange_cam, dtype=float))
    T_base_tcp = T_base_flange @ robot_defs.T_EE_TCP
    return T_base_flange, T_base_tcp
