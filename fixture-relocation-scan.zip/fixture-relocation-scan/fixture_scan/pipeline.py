"""End-to-end planner orchestration.

`run_geometry_frontend()` = Phase 1 (no robot): sampling -> per-position orientation +
marker visibility -> camera->TCP -> workspace filter -> scoring. Returns every candidate
(each carrying its own `rejected_stage` / `reject_reason`) plus the ranked survivors and a
funnel-count summary.

`run_full_plan()` = Phases 1-3: the geometry front-end, then ik_filter -> viewpoint
selection -> ordering -> tiered trajectory generation, producing an ordered list of
executable viewpoints. Needs a `MoveGroupClient`.
"""

import numpy as np

from fixture_scan import config
from fixture_scan import inputs as _inputs
from fixture_scan.geometry import make_T
from fixture_scan.orientation import optimize_orientation
from fixture_scan.tcp_conversion import camera_pose_to_flange_tcp
from fixture_scan.sampling import sample_candidates
from fixture_scan.viewpoint_scoring import score_candidates
from fixture_scan.workspace_filter import (
    tcp_above_floor,
    tcp_base_distance,
    tcp_z,
    within_workspace,
)


def run_geometry_frontend(role, nominal_pose_path, intrinsics_yaml, extrinsics_yaml,
                          *, cam_id=None, R_cam_current=None, intrinsics=None, cfg=config):
    """Returns dict with:
      fixture:     inputs.FixtureInputs
      candidates:  list[ViewpointCandidate]  (all ~N_SAMPLES, rejects included)
      survivors:   list[ViewpointCandidate]  (workspace-passed, sorted by S desc)
      stats:       {sampled, visibility_ok, workspace_ok, ...}

    `intrinsics` (an `inputs.Intrinsics`, e.g. from `load_intrinsics_live`) overrides the
    `intrinsics_yaml` file load when given.
    """
    cam_id = cam_id or _inputs.ARM_TO_CAM_ID[role]
    fixture = _inputs.load_fixture(nominal_pose_path, role)
    intr = intrinsics if intrinsics is not None else _inputs.load_intrinsics(intrinsics_yaml, cam_id)
    T_flange_cam = _inputs.load_flange_to_camera(extrinsics_yaml, cam_id)

    candidates = sample_candidates(fixture.fixture_center_base, cfg)

    for c in candidates:
        got = optimize_orientation(c.camera_position, fixture.markers, intr,
                                   R_cam_current=R_cam_current, cfg=cfg)
        if got is None:
            c.reject("visibility", "no marker visible from this position")
            continue
        marker_id, R_base_cam, metrics = got
        c.selected_marker_id = marker_id
        c.camera_orientation = R_base_cam
        c.T_base_cam = make_T(R_base_cam, c.camera_position)
        c.marker_quality = metrics["M"]
        c.fov_margin = metrics["A"]
        c.marker_px_size = metrics["px_size"]
        c.marker_distance_m = metrics["distance_m"]
        c.marker_incidence_deg = metrics["incidence_deg"]
        c.marker_ray_angle_deg = metrics["ray_angle_deg"]
        c.fov_margin_px = metrics["fov_margin_px"]
        c.rotation_from_current_deg = metrics["rotation_from_current_deg"]

        c.T_base_flange, c.T_base_tcp = camera_pose_to_flange_tcp(c.T_base_cam, T_flange_cam)

        if not within_workspace(c.T_base_tcp, role, cfg):
            c.reject("workspace",
                     f"TCP {tcp_base_distance(c.T_base_tcp, role):.3f} m from base "
                     f"> {cfg.MAX_TCP_BASE_DIST_M:.2f} m")
            continue
        if not tcp_above_floor(c.T_base_tcp, cfg):
            c.reject("tcp_floor",
                     f"TCP z {tcp_z(c.T_base_tcp):.3f} m < {cfg.MIN_TCP_Z_M:.3f} m floor")
            continue

    survivors = score_candidates(candidates, cfg)

    stats = {
        "sampled": len(candidates),
        "visibility_ok": sum(1 for c in candidates
                             if c.rejected_stage not in ("visibility",)),
        "workspace_ok": len(survivors),
        "rejected_visibility": sum(1 for c in candidates
                                   if c.rejected_stage == "visibility"),
        "rejected_workspace": sum(1 for c in candidates
                                  if c.rejected_stage == "workspace"),
        "rejected_tcp_floor": sum(1 for c in candidates
                                  if c.rejected_stage == "tcp_floor"),
    }
    return {"fixture": fixture, "intrinsics": intr, "T_flange_cam": T_flange_cam,
            "candidates": candidates, "survivors": survivors, "stats": stats}


def run_full_plan(role, mg_client, *, nominal_pose_path, intrinsics_yaml, extrinsics_yaml,
                  q_current, other_arm_q, cam_id=None, R_cam_current=None, intrinsics=None,
                  cfg=config):
    """Phases 1-3. Returns dict adding to run_geometry_frontend's output:
      feasible:  list[ViewpointCandidate] with selected_joint_configuration set
      selected:  list[ViewpointCandidate] (5-10 diverse)
      ordered:   list[ViewpointCandidate] in execution order
      segments:  list[TrajectorySegment] (lead-in + between-viewpoint paths)

    `intrinsics` (an `inputs.Intrinsics`, e.g. `load_intrinsics_live`) overrides the
    `intrinsics_yaml` load.
    """
    from fixture_scan.ik_filter import filter_by_ik
    from fixture_scan.viewpoint_selection import select_diverse
    from fixture_scan.viewpoint_ordering import order_viewpoints
    from fixture_scan.trajectory_planning import plan_segments
    from fixture_scan.scene_publisher import publish_fixture_box, publish_static_scene

    fe = run_geometry_frontend(role, nominal_pose_path, intrinsics_yaml, extrinsics_yaml,
                               cam_id=cam_id, R_cam_current=R_cam_current,
                               intrinsics=intrinsics, cfg=cfg)

    # Populate the namespaced planning scene BEFORE any IK / state-validity / CHOMP call so
    # they keep the arm + its trajectories clear of the obstacles. Neither is fatal -- the
    # explicit FK TCP-z floor still guards the fingertip if they fail.
    #  1. static `table` + `mock_box` -- on mode:=mock publish_mock_scene_objects.py also
    #     publishes these; on mode:=hardware (no such node) this is the only source.
    #  2. the estimated fixture box -- runtime pose, never in the static YAML.
    publish_static_scene(mg_client)
    publish_fixture_box(mg_client, fe["fixture"].fixture_center_base, cfg=cfg)

    feasible = filter_by_ik(fe["survivors"], role, mg_client, q_current=q_current,
                            other_arm_q=other_arm_q, cfg=cfg)
    selected = select_diverse(feasible, fe["fixture"].fixture_center_base, cfg=cfg)
    ordered = order_viewpoints(selected, q_current, cfg=cfg)
    fe.update(feasible=feasible, selected=selected, ordered=ordered, segments=[],
              segment_report=None, trajectory_error=None)

    # Trajectory generation can legitimately fail (no collision-free program within
    # MAX_RESELECT). Don't raise out of the pipeline -- return the partial result so the
    # caller can still publish the geometry / selection to RViz for debugging.
    try:
        segments, seg_report = plan_segments(
            ordered, role, mg_client, q_current=q_current, other_arm_q=other_arm_q,
            cfg=cfg, fixture_center=fe["fixture"].fixture_center_base)
        fe.update(segments=segments, segment_report=seg_report)
    except RuntimeError as exc:
        fe["trajectory_error"] = str(exc)
    return fe
