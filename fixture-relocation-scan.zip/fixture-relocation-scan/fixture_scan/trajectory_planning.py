"""§9 tiered collision-free trajectory generation.

For the lead-in (`q_current` -> viewpoint[0]) and every consecutive selected pair
(q_i, q_j):

  tier 1  straight-line joint interp  q(t) = (1-t) q_i + t q_j, resampled so no joint
          steps more than STRAIGHT_LINE_MAX_JOINT_STEP_RAD; densely
          `/check_state_validity` at COLLISION_CHECK_STEP_RAD + a per-waypoint
          min_tcp_z floor (FK) -> if clean, ACCEPT (traj_tier "straight_line").
  tier 2  CHOMP `/move_action` (pipeline "chomp", straight-line seed) -> re-check
          -> ACCEPT (traj_tier "chomp").
  tier 3  drop the offending viewpoint and re-order the remainder; bounded to
          MAX_RESELECT whole-program iterations, then fail with a per-segment report.

W (D5) rides in tier 1 via the straight-line metric and in CHOMP via
chomp_planning.yaml's smoothness weights (config.CHOMP_PARAMS).
"""

from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

from fixture_scan import config, robot_defs


@dataclass
class TrajectorySegment:
    from_index: int          # -1 == lead-in from q_current
    to_index: int            # viewpoint index in the ORDERED list
    path: np.ndarray         # (M, 7)
    tier: str                # "straight_line" | "chomp"
    checked_step_rad: float
    notes: str = ""

    @property
    def n_waypoints(self) -> int:
        return int(self.path.shape[0])


@dataclass
class SegmentReport:
    reselect_iterations: int = 0
    dropped_viewpoint_indices: List[int] = field(default_factory=list)
    failures: List[str] = field(default_factory=list)


def resample_joint_line(q_a, q_b, max_step_rad):
    q_a = np.asarray(q_a, dtype=float)
    q_b = np.asarray(q_b, dtype=float)
    n = max(1, int(np.ceil(np.max(np.abs(q_b - q_a)) / max_step_rad)))
    ts = np.linspace(0.0, 1.0, n + 1)[:, None]
    return (1.0 - ts) * q_a[None, :] + ts * q_b[None, :]


def concat_segment_paths(segments) -> np.ndarray:
    """One (M,7) joint path from an ordered list of `TrajectorySegment` -- each segment's
    first waypoint is dropped where it repeats the previous segment's last (the lead-in
    starts at q_current, so the result starts there too). Empty list -> (0,7)."""
    segs = [np.asarray(s.path, dtype=float) for s in segments if s is not None and len(s.path)]
    if not segs:
        return np.zeros((0, 7))
    out = [segs[0]]
    for seg in segs[1:]:
        start = 1 if np.allclose(seg[0], out[-1][-1], atol=1e-9) else 0
        out.append(seg[start:])
    return np.vstack(out)


def _densify(path, step_rad):
    out = [path[0]]
    for a, b in zip(path[:-1], path[1:]):
        seg = resample_joint_line(a, b, step_rad)
        out.extend(seg[1:])
    return np.array(out)


class _FkFloor:
    """Per-waypoint TCP-z floor check via compute_fk. Segment ENDPOINTS use the
    conservative MIN_TCP_Z_M; INTERIOR waypoints (transient joint-lerp / CHOMP dips
    through free space) use the true fingertip free-space floor MIN_TCP_Z_INTERIOR_M.
    Disables itself (once, loudly) if FK is unavailable so the planner still runs."""

    def __init__(self, mg_client, role, other_arm_q, cfg, log):
        self._mg, self._role, self._other = mg_client, role, other_arm_q
        self._cfg, self._log, self._enabled = cfg, log, True

    def ok(self, path, *, start_is_measured=False):
        """`start_is_measured` (lead-in segment): waypoint 0 is the arm's current pose,
        not something we planned -- warn if it is low but never hard-fail on it."""
        if not self._enabled:
            return True, ""
        n = len(path)
        for i, q in enumerate(path):
            T = self._mg.compute_fk(self._role, q, other_arm_q=self._other)
            if T is None:
                self._enabled = False
                self._log(f"[{self._role}] compute_fk unavailable -- TCP-z floor "
                          "unchecked for the rest of this run")
                return True, ""
            is_endpoint = i in (0, n - 1)
            floor = self._cfg.MIN_TCP_Z_M if is_endpoint else self._cfg.MIN_TCP_Z_INTERIOR_M
            if T[2, 3] < floor:
                if i == 0 and start_is_measured:
                    self._log(f"[{self._role}] lead-in start (measured q_current) TCP "
                              f"z={T[2, 3]:.3f} m is below {floor:.3f} -- proceeding")
                    continue
                where = "endpoint" if is_endpoint else f"interior wp {i}/{n - 1}"
                return False, f"{where} TCP z={T[2, 3]:.3f} m < {floor:.3f}"
        return True, ""


def _try_segment(mg, role, q_a, q_b, other_arm_q, fk_floor, cfg, log, *, is_lead_in=False):
    group = robot_defs.ARM[role][0]
    coarse = resample_joint_line(q_a, q_b, cfg.STRAIGHT_LINE_MAX_JOINT_STEP_RAD)

    # tier 1
    dense = _densify(coarse, cfg.COLLISION_CHECK_STEP_RAD)
    if mg.path_is_valid(role, dense, other_arm_q=other_arm_q, group=group):
        ok, why = fk_floor.ok(coarse, start_is_measured=is_lead_in)
        if ok:
            return TrajectorySegment(-2, -2, coarse, "straight_line",
                                     cfg.COLLISION_CHECK_STEP_RAD), ""
        log(f"[{role}] straight-line clear of collision but {why}")

    # tier 2
    try:
        chomp_path = mg.plan_joint_goal_chomp(role, q_b, start_q=q_a, other_arm_q=other_arm_q)
    except RuntimeError as exc:
        return None, f"straight-line rejected; CHOMP failed ({exc})"
    dense = _densify(chomp_path, cfg.COLLISION_CHECK_STEP_RAD)
    if not mg.path_is_valid(role, dense, other_arm_q=other_arm_q, group=group):
        return None, "CHOMP output still collides on dense re-check"
    ok, why = fk_floor.ok(chomp_path, start_is_measured=is_lead_in)
    if not ok:
        return None, f"CHOMP output violates the TCP-z floor ({why})"
    return TrajectorySegment(-2, -2, chomp_path, "chomp", cfg.COLLISION_CHECK_STEP_RAD), ""


def plan_segments(ordered, role, mg_client, *, q_current, other_arm_q, cfg=config,
                  fixture_center=None, log=print):
    """Returns (segments, report). Raises RuntimeError only when it cannot produce a full
    program within MAX_RESELECT reselect iterations (with a per-segment failure report).
    `ordered` is mutated to the surviving viewpoint order."""
    from fixture_scan.viewpoint_ordering import order_viewpoints

    report = SegmentReport()
    fk_floor = _FkFloor(mg_client, role, other_arm_q, cfg, log)
    work = list(ordered)
    log(f"[{role}] TCP-z floor checked on FK link {robot_defs.tcp_link(role)!r} "
        f"(endpoints >= {cfg.MIN_TCP_Z_M:.3f} m, interior >= {cfg.MIN_TCP_Z_INTERIOR_M:.3f} m)")
    if work:
        fk0 = mg_client.compute_fk(role, work[0].selected_joint_configuration,
                                   other_arm_q=other_arm_q)
        if fk0 is not None:
            log(f"[{role}] sanity: viewpoint {work[0].index} planned TCP z="
                f"{work[0].T_base_tcp[2, 3]:.3f} m, FK({robot_defs.tcp_link(role)}) z="
                f"{fk0[2, 3]:.3f} m  (should match to a few mm)")

    while True:
        configs = [np.asarray(q_current, dtype=float)] + \
                  [c.selected_joint_configuration for c in work]
        segments, failed_k, fail_msg = [], None, ""
        for k in range(len(configs) - 1):
            seg, msg = _try_segment(mg_client, role, configs[k], configs[k + 1],
                                    other_arm_q, fk_floor, cfg, log, is_lead_in=(k == 0))
            if seg is None:
                failed_k, fail_msg = k, msg
                break
            seg.from_index = k - 1          # -1 == lead-in
            seg.to_index = k
            segments.append(seg)
            log(f"[{role}] segment {k - 1}->{k}: {seg.tier} ({seg.n_waypoints} wp)")

        if failed_k is None:
            ordered[:] = work
            _log_joint_travel(segments, role, log)
            return segments, report

        # tier 3: drop the offending viewpoint (the `to` node of the failed pair) and
        # re-order the remainder.
        drop_pos = failed_k                     # configs index; 0 == q_current (never a vp)
        vp_pos = max(drop_pos - 1, 0)           # -> index into `work`
        report.reselect_iterations += 1
        report.failures.append(f"segment {failed_k - 1}->{failed_k}: {fail_msg}")
        if report.reselect_iterations > cfg.MAX_RESELECT or len(work) - 1 < cfg.N_VIEWPOINTS_MIN:
            raise RuntimeError(
                f"[{role}] trajectory generation failed after "
                f"{report.reselect_iterations - 1} reselect iteration(s):\n  "
                + "\n  ".join(report.failures))
        dropped = work.pop(vp_pos)
        report.dropped_viewpoint_indices.append(dropped.index)
        dropped.reject("trajectory", f"no collision-free segment ({fail_msg})")
        log(f"[{role}] reselect {report.reselect_iterations}: dropped viewpoint "
            f"cand#{dropped.index}; re-ordering {len(work)} remaining")
        work = order_viewpoints(work, q_current, cfg=cfg, log=log)


def _log_joint_travel(segments, role, log):
    if not segments:
        return
    total = np.zeros(7)
    for s in segments:
        total += np.sum(np.abs(np.diff(s.path, axis=0)), axis=0)
    names = [f"A{i}" for i in range(1, 8)]
    deg = np.degrees(total).round(1)
    log(f"[{role}] per-joint travel over the program (deg): "
        + ", ".join(f"{n}={d}" for n, d in zip(names, deg))
        + "  -- D5 expects A1/A7 large, A3-A5 quiet")
