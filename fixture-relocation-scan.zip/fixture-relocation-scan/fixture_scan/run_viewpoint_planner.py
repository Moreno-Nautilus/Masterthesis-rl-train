#!/usr/bin/env python3
"""CLI: fixture inputs -> `scan_program.json`.

Runs host-side in the `fabrica-kuka-pdz8` conda env against the NAMESPACED `move_group`
(`ros2 launch lbr_dual_arm_pdz_bringup move_group_ns.launch.py mode:=mock|hardware`).

    # geometry only (no move_group needed) -- dump + eyeball the funnel:
    python3 -m fixture_scan.run_viewpoint_planner --arm hold --geometry-only

    # full plan -> scan_program.json (needs move_group + the CHOMP pipeline):
    python3 -m fixture_scan.run_viewpoint_planner --arm hold --out scan_program.json --rviz

    # ... and immediately run it through move_group so the arm moves (mock: RViz animates;
    # hardware: REAL MOTION):
    python3 -m fixture_scan.run_viewpoint_planner --arm hold --rviz --execute

The planning core is `fixture_scan.plan_scan.plan_scan_program` -- shared verbatim with the
container's `scan_fixture.py --plan-viewpoints`. This CLI only owns argparse, the funnel
prints, `--rviz`, writing `scan_program.json`, and `--execute`.

Reads the scanning arm's live `/<robot>/joint_states` for `q_current` (the idle arm must
already be parked -- see `scan_fixture.park_other_arm` / impl-plan D1/§7). The idle-arm
config is taken from `motion.pkl`'s first waypoint for that role and pinned into the
collision world for every IK / validity / CHOMP call.
"""

import argparse
import sys

from fixture_scan import config, robot_defs
from fixture_scan import inputs as fs_inputs
from fixture_scan.pipeline import run_geometry_frontend
from fixture_scan.plan_scan import _read_q_current, plan_scan_program


def _dump_funnel(fe, top=10):
    s = fe["stats"]
    print(f"\n=== geometry funnel ({fe['fixture'].role}) ===")
    print(f"  sampled              {s['sampled']}")
    print(f"  rejected visibility  {s['rejected_visibility']}")
    print(f"  rejected workspace   {s['rejected_workspace']}")
    print(f"  rejected tcp_floor   {s.get('rejected_tcp_floor', 0)}")
    print(f"  survivors (scored)   {len(fe['survivors'])}")
    print(f"  top {top} by S:")
    for c in fe["survivors"][:top]:
        d = c.debug_dict()
        print(f"    #{c.index:3d}  S={d['S']:.3f}  M={d['M']:.2f} A={d['A']:.2f} "
              f"D={d['D']:.2f} R={d['R']:.2f}  r={d['radius_m']:.3f}m  m{d['marker_id']}  "
              f"inc={d['marker_incidence_deg']:.0f}deg px={d['marker_px_size']:.0f}")


def main(argv=None):
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--arm", choices=["hold", "move"], required=True)
    ap.add_argument("--nominal-pose", default=config.DEFAULT_NOMINAL_POSE)
    ap.add_argument("--motion-pkl", default=config.DEFAULT_MOTION_PKL)
    ap.add_argument("--intrinsics-yaml", default=config.DEFAULT_INTRINSICS_YAML)
    ap.add_argument("--intrinsics-source", choices=["auto", "camera_info", "yaml"],
                    default="auto",
                    help="auto (default): the wrist camera's live color/camera_info if it "
                         "is publishing, else --intrinsics-yaml. camera_info: require the "
                         "live topic (error if absent). yaml: always the file. "
                         "--geometry-only always uses the file.")
    ap.add_argument("--extrinsics-yaml", default=config.DEFAULT_EXTRINSICS_YAML)
    ap.add_argument("--out", default="scan_program.json")
    ap.add_argument("--robot-name", default=config.ROBOT_NAME)
    ap.add_argument("--plan", default=config.DEFAULT_PLAN)
    ap.add_argument("--geometry-only", action="store_true",
                    help="Phase 1 only: dump the funnel, no move_group, no scan_program")
    ap.add_argument("--rviz", action="store_true",
                    help="publish §13 debug MarkerArray + DisplayTrajectory")
    ap.add_argument("--execute", action="store_true",
                    help="after planning, actually RUN the full scan trajectory through "
                         "move_group's /execute_trajectory so the arm moves (mock: RViz "
                         "animates it; hardware: REAL MOTION -- have a hand on the e-stop)")
    ap.add_argument("--execute-time-step", type=float, default=0.1,
                    help="seconds per waypoint when --execute streams the path (default 0.1)")
    args = ap.parse_args(argv)

    role = args.arm
    cam_id = fs_inputs.ARM_TO_CAM_ID[role]

    if args.geometry_only:
        fe = run_geometry_frontend(role, args.nominal_pose, args.intrinsics_yaml,
                                   args.extrinsics_yaml, cam_id=cam_id)
        _dump_funnel(fe)
        return 0

    import rclpy
    from fixture_scan.move_group_client import MoveGroupClient
    from fixture_scan import scan_program as sp

    if not rclpy.ok():
        rclpy.init()
    node = rclpy.create_node("run_viewpoint_planner")

    # Build our own MoveGroupClient so we can reuse it for --execute after planning.
    mg = MoveGroupClient(robot_name=args.robot_name)
    program, result = plan_scan_program(
        role, robot_name=args.robot_name, nominal_pose=args.nominal_pose,
        motion_pkl=args.motion_pkl, intrinsics_yaml=args.intrinsics_yaml,
        extrinsics_yaml=args.extrinsics_yaml, plan=args.plan,
        intrinsics_source=args.intrinsics_source, node=node, mg=mg,
        log=lambda m: node.get_logger().info(m))

    _dump_funnel(result)
    print(f"\n  IK-feasible          {len(result['feasible'])}")
    print(f"  selected (diverse)   {len(result['selected'])}")
    print(f"  ordered              {[c.index for c in result['ordered']]}")
    print(f"  segment tiers        {[s.tier for s in result['segments']]}")

    # Publish debug viz FIRST (before we might exit on a trajectory failure) so RViz shows
    # the funnel + selected viewpoints regardless. --rviz publishes topics only; RViz
    # itself must already be running:
    #   ros2 launch lbr_dual_arm_moveit_config moveit_rviz.launch.py
    # then Add -> MarkerArray on /<robot>/fixture_scan/debug_markers.
    if args.rviz:
        from fixture_scan import visualization as viz
        q_now = {}
        both = robot_defs.joint_names("hold") + robot_defs.joint_names("move")
        try:
            q_now = dict(zip(both, _read_q_current(node, args.robot_name, both)))
        except RuntimeError:
            pass
        viz.publish_debug_markers(node, result, ordered=result["ordered"],
                                  feasible=result["feasible"], robot_name=args.robot_name)
        if q_now and result["segments"]:
            viz.publish_display_trajectory(node, role, result["segments"], q_now,
                                           robot_name=args.robot_name)

    rc = 0
    if result.get("trajectory_error"):
        print(f"\nTRAJECTORY GENERATION FAILED -- no scan_program written:\n"
              f"{result['trajectory_error']}")
        if args.rviz:
            print("\n(debug markers were still published -- inspect the selected "
                  "viewpoints / funnel in RViz)")
        rc = 1
    else:
        sp.write_program(args.out, program)
        print(f"\nwrote {args.out}  ({program['meta']['n_viewpoints']} viewpoints, "
              f"config_sha {program['meta']['config_sha']})")

    if args.execute and not result.get("trajectory_error") and result["segments"]:
        from fixture_scan.trajectory_planning import concat_segment_paths
        full = concat_segment_paths(result["segments"])
        print(f"\nexecuting the full scan trajectory ({len(full)} waypoints, "
              f"~{len(full) * args.execute_time_step:.0f}s) via /execute_trajectory ...")
        try:
            ok = mg.execute_path(role, full, time_step_s=args.execute_time_step)
            print("execution SUCCEEDED" if ok else "execution reported a non-success code")
        except (RuntimeError, ValueError) as exc:
            print(f"execution FAILED: {exc}")
            rc = rc or 1
    elif args.execute:
        print("\n--execute: nothing to run (no trajectory was produced)")

    if args.rviz or args.execute:
        # keep the node alive briefly so latched publishers deliver to a late RViz
        for _ in range(20):
            rclpy.spin_once(node, timeout_sec=0.1)

    mg.shutdown()
    node.destroy_node()
    rclpy.shutdown()
    return rc


if __name__ == "__main__":
    sys.exit(main())
