"""§2-3 marker visibility: pinhole projection, marker-quality M, FOV-margin A, hard rejects.

Runs BEFORE any IK (spec §3 / §11). Given a camera pose in the arm base frame and a
marker's 4 physical corners (also base frame), projects through the rectified pinhole
model (d = 0) and computes:

  * marker projected size (min projected edge length, px)     -> hard reject + M term
  * camera-to-marker distance (m)                             -> M term
  * marker viewing / incidence angle (deg, vs surface normal) -> hard reject + M term
  * camera optical-axis vs camera->marker ray angle (deg)     -> hard reject (spec 30 deg)
  * FOV margin (min projected-corner distance to image border, px) -> hard reject + A

"Bad marker visibility is a hard rejection, not something a high distance score can
compensate for" (spec §3): the four hard gates fire first; M / A only rank the survivors.
"""

import numpy as np

from fixture_scan import config
from fixture_scan.geometry import invert_T, normalize, transform_points


def _clip01(x):
    return float(np.clip(x, 0.0, 1.0))


def _lin_score(value, bad, good):
    """0 at `bad`, 1 at `good`, linear between, clipped. Handles good<bad (smaller better)."""
    if good == bad:
        return 1.0 if value == good else 0.0
    return _clip01((value - bad) / (good - bad))


def evaluate_marker(T_base_cam, marker, intr, cfg=config):
    """Returns a dict:
      accepted: bool
      reason:   str (why rejected, "" if accepted)
      M, A:     floats in [0,1]  (0 when rejected)
      px_size, distance_m, incidence_deg, ray_angle_deg, fov_margin_px: raw metrics
    `marker` is an inputs.Marker; `intr` an inputs.Intrinsics.
    """
    out = dict(accepted=False, reason="", M=0.0, A=0.0, px_size=0.0, distance_m=0.0,
               incidence_deg=180.0, ray_angle_deg=180.0, fov_margin_px=-1.0)

    T_cam_base = invert_T(np.asarray(T_base_cam, dtype=float))
    corners_cam = transform_points(T_cam_base, marker.corners_base)   # (4,3)
    center_cam = corners_cam.mean(axis=0)

    if np.any(corners_cam[:, 2] <= 1e-4):
        out["reason"] = "marker behind / in the camera plane"
        return out

    dist = float(np.linalg.norm(center_cam))
    out["distance_m"] = dist

    # optical axis (camera +Z in base) vs camera->marker ray
    cam_pos = np.asarray(T_base_cam, dtype=float)[:3, 3]
    ray = normalize(marker.center_base - cam_pos)
    optical_axis = normalize(np.asarray(T_base_cam, dtype=float)[:3, 2])
    ray_angle = float(np.degrees(np.arccos(np.clip(np.dot(ray, optical_axis), -1.0, 1.0))))
    out["ray_angle_deg"] = ray_angle

    # incidence: angle between the viewing ray and the marker surface normal
    incidence = float(np.degrees(np.arccos(
        np.clip(abs(np.dot(ray, normalize(marker.normal_base))), 0.0, 1.0))))
    out["incidence_deg"] = incidence

    px = intr.project(corners_cam)   # (4,2)
    if not np.all(np.isfinite(px)):
        out["reason"] = "marker corner failed to project"
        return out

    edges = np.linalg.norm(np.roll(px, -1, axis=0) - px, axis=1)
    px_size = float(edges.min())
    out["px_size"] = px_size

    margin_px = float(np.min([
        px[:, 0].min(), px[:, 1].min(),
        intr.width - px[:, 0].max(), intr.height - px[:, 1].max(),
    ]))
    out["fov_margin_px"] = margin_px

    # --- hard gates (spec §2-3) --------------------------------------------------
    if ray_angle > cfg.MAX_MARKER_RAY_ANGLE_DEG:
        out["reason"] = f"optical-axis/ray angle {ray_angle:.1f} deg > {cfg.MAX_MARKER_RAY_ANGLE_DEG:.0f}"
        return out
    if margin_px < cfg.FOV_MARGIN_MIN_PX:
        out["reason"] = (f"FOV margin {margin_px:.1f} px < {cfg.FOV_MARGIN_MIN_PX:.0f}"
                         if margin_px >= 0 else "marker outside the image")
        return out
    if px_size < cfg.MARKER_MIN_PROJECTED_PX:
        out["reason"] = f"projected size {px_size:.1f} px < {cfg.MARKER_MIN_PROJECTED_PX:.0f}"
        return out
    if incidence > cfg.MARKER_MAX_VIEW_ANGLE_DEG:
        out["reason"] = f"incidence {incidence:.1f} deg > {cfg.MARKER_MAX_VIEW_ANGLE_DEG:.0f}"
        return out

    # --- normalised scores for the survivors ----------------------------------
    size_score = _lin_score(px_size, cfg.MARKER_MIN_PROJECTED_PX, cfg.MARKER_GOOD_PROJECTED_PX)
    inc_score = _lin_score(incidence, cfg.MARKER_MAX_VIEW_ANGLE_DEG, cfg.MARKER_GOOD_VIEW_ANGLE_DEG)
    if dist < cfg.MARKER_DIST_GOOD_MIN_M:
        dist_score = _lin_score(dist, cfg.RADIUS_MIN_M, cfg.MARKER_DIST_GOOD_MIN_M)
    elif dist > cfg.MARKER_DIST_GOOD_MAX_M:
        dist_score = _lin_score(dist, cfg.RADIUS_MAX_M, cfg.MARKER_DIST_GOOD_MAX_M)
    else:
        dist_score = 1.0

    out["M"] = _clip01((0.6 * size_score + 0.4 * inc_score) * (0.5 + 0.5 * dist_score))
    out["A"] = _lin_score(margin_px, cfg.FOV_MARGIN_MIN_PX, cfg.FOV_MARGIN_GOOD_PX)
    out["accepted"] = True
    return out
