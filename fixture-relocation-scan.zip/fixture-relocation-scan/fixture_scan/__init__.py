"""Fixture-scanning viewpoint planner.

Host-side (fabrica-kuka-pdz8 conda env) replacement for the ad-hoc half-circle orbit:
hemisphere sampling -> marker-visibility filtering -> IK feasibility -> diverse viewpoint
selection -> execution-order optimisation -> tiered collision-free trajectory generation ->
`scan_program.json`.

See ~/Fabrica-pdz/docs/fixture_scanning_viewpoint_planner_implementation_plan.md for the
adaptation of the 13-section design spec to this rig, and this package's modules for the
per-phase implementation. Pure kinematics + pinhole projection -- no cv2 / open3d, no marker
*detection* (that stays in the vision container).
"""
