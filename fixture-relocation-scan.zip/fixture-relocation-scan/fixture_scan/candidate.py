"""The `ViewpointCandidate` record threaded through every planner stage (spec §10)."""

from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np


@dataclass
class ViewpointCandidate:
    index: int
    camera_position: np.ndarray            # (3,) arm base frame
    radius_m: float
    viewing_direction: np.ndarray          # (3,) unit, fixture centre -> camera

    # -- filled by orientation.py / marker_visibility.py --------------------------
    camera_orientation: Optional[np.ndarray] = None   # (3,3) R_base_cam
    selected_marker_id: Optional[int] = None
    T_base_cam: Optional[np.ndarray] = None           # (4,4)
    T_base_flange: Optional[np.ndarray] = None        # (4,4)
    T_base_tcp: Optional[np.ndarray] = None           # (4,4)

    # -- normalised score terms (spec §5) --------------------------------------
    marker_quality: float = 0.0     # M in [0,1]
    fov_margin: float = 0.0         # A in [0,1]
    distance_score: float = 0.0     # D in [0,1] (assigned in viewpoint_scoring)
    orientation_score: float = 0.0  # R in [0,1] (assigned in viewpoint_scoring)
    total_score: float = 0.0        # S_i

    # -- raw diagnostics (spec §13) -------------------------------------------
    marker_px_size: float = 0.0
    marker_distance_m: float = 0.0
    marker_incidence_deg: float = 0.0
    marker_ray_angle_deg: float = 0.0
    fov_margin_px: float = 0.0
    rotation_from_current_deg: float = float("nan")

    # -- IK (spec §6) ------------------------------------------------------
    ik_solutions: List[np.ndarray] = field(default_factory=list)
    selected_joint_configuration: Optional[np.ndarray] = None
    ik_seed_dist_W: Optional[float] = None
    collision_free: bool = False

    # -- reject bookkeeping ("easy to understand why a candidate was rejected") ---
    rejected_stage: Optional[str] = None   # sampling|visibility|workspace|ik|trajectory
    reject_reason: Optional[str] = None

    @property
    def alive(self) -> bool:
        return self.rejected_stage is None

    def reject(self, stage: str, reason: str) -> "ViewpointCandidate":
        if self.rejected_stage is None:   # keep the first (earliest) rejection
            self.rejected_stage = stage
            self.reject_reason = reason
        return self

    def debug_dict(self) -> dict:
        return {
            "S": round(self.total_score, 4),
            "M": round(self.marker_quality, 4),
            "A": round(self.fov_margin, 4),
            "D": round(self.distance_score, 4),
            "R": round(self.orientation_score, 4),
            "radius_m": round(self.radius_m, 4),
            "viewing_dir": [round(float(x), 4) for x in self.viewing_direction],
            "marker_id": self.selected_marker_id,
            "marker_px_size": round(self.marker_px_size, 2),
            "marker_distance_m": round(self.marker_distance_m, 4),
            "marker_incidence_deg": round(self.marker_incidence_deg, 2),
            "marker_ray_angle_deg": round(self.marker_ray_angle_deg, 2),
            "fov_margin_px": round(self.fov_margin_px, 2),
            "rotation_from_current_deg": round(self.rotation_from_current_deg, 2),
            "ik_seed_dist_W": (None if self.ik_seed_dist_W is None
                               else round(self.ik_seed_dist_W, 4)),
            "n_ik_solutions": len(self.ik_solutions),
            "collision_free": self.collision_free,
            "rejected_stage": self.rejected_stage,
            "reject_reason": self.reject_reason,
        }
