"""§1 candidate position sampling.

~N_SAMPLES camera positions  p_i = c_F + r_i * d_i  with d_i on the upper hemisphere
(equal-area Fibonacci lattice over the elevation band [MIN_ELEVATION_DEG, MAX_ELEVATION_DEG])
and r_i drawn from [RADIUS_MIN_M, RADIUS_MAX_M]. Fully deterministic from RNG_SEED --
directions from the lattice, radii from a seeded Generator (spec: "sampling distance as
well as direction is intentional"). No lat/long clustering.
"""

import numpy as np

from fixture_scan import config
from fixture_scan.candidate import ViewpointCandidate

_GOLDEN_ANGLE = np.pi * (3.0 - np.sqrt(5.0))   # ~2.39996 rad


def fibonacci_hemisphere(n, min_elevation_deg, max_elevation_deg):
    """`n` unit vectors, equal-area over the elevation band (elevation measured from the
    fixture plane; +Z is straight above the fixture centre)."""
    i = np.arange(n)
    z_lo = np.sin(np.radians(min_elevation_deg))
    z_hi = np.sin(np.radians(max_elevation_deg))
    z = z_lo + (z_hi - z_lo) * (i + 0.5) / n     # uniform in z -> equal area in the band
    r_xy = np.sqrt(np.clip(1.0 - z * z, 0.0, 1.0))
    phi = i * _GOLDEN_ANGLE
    return np.stack([r_xy * np.cos(phi), r_xy * np.sin(phi), z], axis=1)


def sample_candidates(fixture_center, cfg=config):
    """List[ViewpointCandidate] of length ~cfg.N_SAMPLES, positions in the same frame as
    `fixture_center` (the scanning arm's base frame)."""
    c_F = np.asarray(fixture_center, dtype=float).reshape(3)
    dirs = fibonacci_hemisphere(cfg.N_SAMPLES, cfg.MIN_ELEVATION_DEG, cfg.MAX_ELEVATION_DEG)
    rng = np.random.default_rng(cfg.RNG_SEED)
    radii = rng.uniform(cfg.RADIUS_MIN_M, cfg.RADIUS_MAX_M, size=len(dirs))

    out = []
    for idx, (d, r) in enumerate(zip(dirs, radii)):
        d = d / np.linalg.norm(d)
        out.append(ViewpointCandidate(
            index=idx,
            camera_position=c_F + r * d,
            radius_m=float(r),
            viewing_direction=d,
        ))
    return out
