"""Assemble + (de)serialise `scan_program.json` -- the file handoff between the host-side
viewpoint planner and the container's `scan_fixture.py` (impl-plan D3, §5 schema).

    {
      "meta":       {arm_role, fixture_pose_path, config_sha, rng_seed, generated,
                     q_current[7], other_arm_q[7], cam_id, intrinsics_path,
                     intrinsics_source, extrinsics_path, plan, planning_frame,
                     n_viewpoints, segment_tiers[]},
      "viewpoints": [ {index, tcp_pose_base[4][4], joint_config[7],
                       trajectory[[7],...], marker_id, debug{...}}, ... ]
    }

`trajectory` for viewpoint k is the collision-free joint path that MOVES THE ARM TO that
viewpoint -- viewpoint 0's trajectory is the lead-in from `q_current`. `tcp_pose_base` is
a diagnostic record only (scan_fixture.py replays the joint `trajectory`, not the pose);
it is expressed in `meta.planning_frame` (== robot_defs.PLANNING_FRAME, base_link).
"""

import datetime
import json
from dataclasses import dataclass
from typing import List

import numpy as np

from fixture_scan import config, robot_defs


def _iso_now():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def build_program(role, ordered, segments, *, q_current, other_arm_q, fixture_pose_path,
                  cam_id, intrinsics_path, extrinsics_path, plan=None,
                  intrinsics_source="yaml", cfg=config):
    """dict ready for json.dump. `ordered` / `segments` come from
    pipeline.run_full_plan (`segments[k]` is the path to `ordered[k]`)."""
    seg_by_to = {s.to_index: s for s in segments}
    viewpoints = []
    for k, c in enumerate(ordered):
        seg = seg_by_to.get(k)
        traj = (np.asarray(seg.path, dtype=float).tolist() if seg is not None
                else [list(map(float, c.selected_joint_configuration))])
        dbg = c.debug_dict()
        dbg["traj_tier"] = seg.tier if seg is not None else "none"
        viewpoints.append({
            "index": k,
            "candidate_index": c.index,
            "tcp_pose_base": np.asarray(c.T_base_tcp, dtype=float).tolist(),
            "joint_config": [float(x) for x in c.selected_joint_configuration],
            "trajectory": traj,
            "marker_id": c.selected_marker_id,
            "debug": dbg,
        })

    return {
        "meta": {
            "arm_role": role,
            "fixture_pose_path": str(fixture_pose_path),
            "config_sha": cfg.config_sha(),
            "rng_seed": cfg.RNG_SEED,
            "generated": _iso_now(),
            "q_current": [float(x) for x in np.asarray(q_current, dtype=float)],
            "other_arm_q": [float(x) for x in np.asarray(other_arm_q, dtype=float)],
            "cam_id": cam_id,
            "intrinsics_path": str(intrinsics_path),
            "intrinsics_source": intrinsics_source,   # "camera_info" (live) | "yaml"
            "extrinsics_path": str(extrinsics_path),
            "plan": plan,
            "planning_frame": robot_defs.PLANNING_FRAME,
            "n_viewpoints": len(viewpoints),
            "segment_tiers": [s.tier for s in segments],
        },
        "viewpoints": viewpoints,
    }


def write_program(path, program):
    with open(path, "w") as fp:
        json.dump(program, fp, indent=2)
    return path


# -- reader (container side) -------------------------------------------------------
@dataclass
class ProgramViewpoint:
    index: int
    T_base_tcp: np.ndarray        # (4,4)
    joint_config: np.ndarray      # (7,)
    trajectory: np.ndarray        # (M,7) -- path that moves the arm TO this viewpoint
    marker_id: int
    traj_tier: str
    debug: dict


@dataclass
class ScanProgram:
    meta: dict
    viewpoints: List[ProgramViewpoint]

    @property
    def role(self):
        return self.meta["arm_role"]

    @property
    def q_current(self):
        return np.asarray(self.meta["q_current"], dtype=float)

    @property
    def other_arm_q(self):
        return np.asarray(self.meta["other_arm_q"], dtype=float)


def program_from_dict(raw) -> ScanProgram:
    """Turn a `build_program` dict into a `ScanProgram` -- shared by `load_program` (file)
    and the in-process `--plan-viewpoints` path (no temp file)."""
    vps = [ProgramViewpoint(
        index=v["index"],
        T_base_tcp=np.array(v["tcp_pose_base"], dtype=float),
        joint_config=np.array(v["joint_config"], dtype=float),
        trajectory=np.array(v["trajectory"], dtype=float).reshape(-1, 7),
        marker_id=v.get("marker_id"),
        traj_tier=v.get("debug", {}).get("traj_tier", "unknown"),
        debug=v.get("debug", {}),
    ) for v in raw["viewpoints"]]
    return ScanProgram(meta=raw["meta"], viewpoints=vps)


def load_program(path) -> ScanProgram:
    with open(path, "r") as fp:
        raw = json.load(fp)
    return program_from_dict(raw)
