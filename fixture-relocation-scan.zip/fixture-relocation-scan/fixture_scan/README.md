# fixture_scan — fixture-scanning viewpoint planner

Host-side (`fabrica-kuka-pdz8` conda env) replacement for the ad-hoc half-circle orbit in
`fixture_relocation_scan/`. Turns a fixture pose into an ordered set of collision-free
scan viewpoints written to `scan_program.json`.

Design: `~/Fabrica-pdz/docs/fixture_scanning_viewpoint_planner_implementation_plan.md`
(adaptation of the 13-section spec `~/Desktop/fixture_scanning_viewpoint_planner.md`).

## Pipeline

```
sampling            §1  ~200 upper-hemisphere camera positions (Fibonacci, radius sampled)
  -> orientation    §2  per position, full-SO(3) orientation: axis on the marker ray,
                        roll minimised vs the current camera orientation
  -> marker_visibility §3  pinhole projection; M (size/incidence/distance), A (FOV margin);
                           hard rejects (ray>30°, off-image, too small, incidence too high)
  -> tcp_conversion      camera pose -> flange -> constrained pdz TCP pose
  -> workspace_filter §4  ||p_TCP - p_base|| <= 0.75 m  (hard)
  -> viewpoint_scoring §5  S_i = w_d D + w_m M + w_a A + w_r R   (normalised)
  -> ik_filter        §6  N concurrent /compute_ik (seeded), dedupe, /check_state_validity,
                          weighted branch pick  q* = argmin ||q - q_seed||_W
  -> viewpoint_selection §7  greedy farthest-point  argmax [λ S + (1-λ) Δ]
  -> viewpoint_ordering  §8  pairwise ||q_i-q_j||_W, NN from q_current, 2-opt
  -> trajectory_planning §9  tier 1 straight-line + dense collision check
                             tier 2 CHOMP from the straight-line seed
                             tier 3 drop the offending viewpoint, re-order (bounded)
  -> scan_program           serialise scan_program.json
```

`config.py` holds every threshold / weight / seed (spec §12). `robot_defs.py` is the
single source for arm groups / frames / the EE→TCP offset (`arm_planner.py` re-imports
from it). All planner geometry is in `robot_defs.PLANNING_FRAME` (`base_link`, move_group's
planning frame); the nominal JSON's per-arm `board_origin` is shifted into it on load
(pure ±0.42 m Y-translation, so z is unchanged).

**Rig-tuned constants** (see `docs/fixture_scanning_viewpoint_planner_session_2026-09-06_handoff.md`
§6–§7): camera radius `[0.30, 0.65]` m and elevation `[35°, 82°]` — left wide pending a
data-driven funnel re-tune (the sampler places *camera* positions; the camera is ~0.09 m
ahead of the TCP along the tool axis); TCP-z floor `0.19` m endpoints / `0.175` m interior
(the true fingertip limit — the Phase-1 `tcp_above_floor` gate already converts each
camera pose to the constrained TCP, so no offset inflation here); `table` + `mock_box` +
the estimated fixture box are all published into the namespaced scene by the planner
itself (`scene_publisher.publish_static_scene` / `publish_fixture_box`, called from
`pipeline.run_full_plan`), so `mode:=hardware` gets the same collision world as
`mode:=mock`; joint weighting is **uniform** (D5's free-A1 multipliers spun the base).

## Run

```bash
conda activate fabrica-kuka-pdz8
cd ~/fixture-relocation-scan

# geometry funnel only -- no move_group:
python3 -m fixture_scan.run_viewpoint_planner --arm hold --geometry-only

# full plan -> scan_program.json (needs the namespaced move_group + CHOMP pipeline):
ros2 launch lbr_dual_arm_bringup mock.launch.py
ros2 launch lbr_dual_arm_pdz_bringup move_group_ns.launch.py mode:=mock
python3 -m fixture_scan.run_viewpoint_planner --arm hold --out scan_program_hold.json --rviz
#   the planner publishes table + mock_box + the estimated fixture box into the
#   namespaced scene itself (works on mode:=hardware too).
#   intrinsics: --intrinsics-source auto (default) uses the wrist camera's live
#   color/camera_info, else config/camera_intrinsics_realsense.yaml (mock has no camera
#   -> the YAML is used). Force with --intrinsics-source camera_info | yaml.
#   add --execute to also RUN the trajectory through move_group (mock: RViz animates;
#   hardware: REAL MOTION).

# animate it (no move_group):
python3 tools/plan_and_display.py --scan-program scan_program_hold.json

# run it on the rig (container) -- either stage the file:
#   scan_fixture.py --arm hold --scan-program scan_program_hold.json
# or plan in-process (no staging; same pipeline, run after the idle-arm park):
#   scan_fixture.py --arm hold --plan-viewpoints
```

## Tests (no ROS, run as scripts)

```bash
python3 tests/test_fixture_scan_geometry.py            # sampling / projection / funnel
python3 tests/test_fixture_scan_selection_ordering.py  # diverse selection / 2-opt / resample
python3 tests/test_fixture_scan_scan_program.py        # scan_program.json round-trip
```

`ik_filter` / `trajectory_planning` / `move_group_client` need a live or mock
`move_group` and are not covered by the offline tests.
