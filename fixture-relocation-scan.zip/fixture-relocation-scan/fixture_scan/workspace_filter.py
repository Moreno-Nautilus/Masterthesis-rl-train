"""§4 hard workspace filter:  ||p_TCP - p_base|| <= MAX_TCP_BASE_DIST_M, plus the pdz
fingertip-clearance floor on the TCP z.

Geometry is now in the planning frame (base_link), whose origin is NOT the scanning arm's
base -- so the base-distance check subtracts `role`'s arm link_0 origin
(`robot_defs.arm_base_origin_in_planning`) before taking the norm. The z coordinate is
unchanged between base_link and either arm base frame (pure Y-translation), so `tcp_z` /
`tcp_above_floor` are untouched. The z-floor check rejects viewpoints whose constrained
TCP sits below MIN_TCP_Z_M -- the same guard `arm_planner` always applied; without it,
low-elevation samples survive to trajectory planning and only fail there. Mandatory hard
constraints, not soft scores -- actual reachability is decided later by IK (spec §4 / §11).
"""

import numpy as np

from fixture_scan import config, robot_defs


def tcp_base_distance(T_base_tcp, role, cfg=config) -> float:
    """Distance from `role`'s arm link_0 origin to the TCP position. `T_base_tcp` is in
    the planning frame (base_link)."""
    p = np.asarray(T_base_tcp, dtype=float)[:3, 3] - robot_defs.arm_base_origin_in_planning(role)
    return float(np.linalg.norm(p))


def tcp_z(T_base_tcp) -> float:
    return float(np.asarray(T_base_tcp, dtype=float)[2, 3])


def within_workspace(T_base_tcp, role, cfg=config) -> bool:
    return tcp_base_distance(T_base_tcp, role, cfg) <= cfg.MAX_TCP_BASE_DIST_M


def tcp_above_floor(T_base_tcp, cfg=config) -> bool:
    return tcp_z(T_base_tcp) >= cfg.MIN_TCP_Z_M
