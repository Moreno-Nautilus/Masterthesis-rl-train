"""Small SE(3) / SO(3) helpers shared across the planner. numpy + scipy only, no ROS."""

import numpy as np
from scipy.spatial.transform import Rotation


def normalize(v):
    v = np.asarray(v, dtype=float)
    n = np.linalg.norm(v)
    if n < 1e-12:
        raise ValueError("cannot normalize a near-zero vector")
    return v / n


def make_T(R=None, p=None) -> np.ndarray:
    T = np.eye(4)
    if R is not None:
        T[:3, :3] = R
    if p is not None:
        T[:3, 3] = np.asarray(p, dtype=float).reshape(3)
    return T


def invert_T(T: np.ndarray) -> np.ndarray:
    R = T[:3, :3]
    p = T[:3, 3]
    Ti = np.eye(4)
    Ti[:3, :3] = R.T
    Ti[:3, 3] = -R.T @ p
    return Ti


def transform_points(T: np.ndarray, pts: np.ndarray) -> np.ndarray:
    """Apply 4x4 `T` to an (..., 3) array of points."""
    pts = np.asarray(pts, dtype=float)
    shape = pts.shape
    flat = pts.reshape(-1, 3)
    out = (T[:3, :3] @ flat.T).T + T[:3, 3]
    return out.reshape(shape)


def rotation_geodesic_rad(Ra: np.ndarray, Rb: np.ndarray) -> float:
    """Geodesic angle between two rotation matrices [rad]."""
    R = Ra.T @ Rb
    cos = (np.trace(R) - 1.0) / 2.0
    return float(np.arccos(np.clip(cos, -1.0, 1.0)))


def quat_wxyz_to_R(q_wxyz) -> np.ndarray:
    w, x, y, z = q_wxyz
    return Rotation.from_quat([x, y, z, w]).as_matrix()


def R_to_quat_xyzw(R: np.ndarray):
    return Rotation.from_matrix(R).as_quat()   # (x, y, z, w)


def look_rotation(forward, up_hint=(0.0, 0.0, 1.0)) -> np.ndarray:
    """Right-handed camera rotation whose 3rd column (+Z, optical axis, OpenCV
    convention) is `forward`; 1st column (+X) right, 2nd (+Y) down. Falls back to an
    alternate up reference when `forward` is (near) parallel to `up_hint` (roll about the
    optical axis is then arbitrary but valid)."""
    fwd = normalize(forward)
    up = np.asarray(up_hint, dtype=float)
    if np.linalg.norm(np.cross(up, fwd)) < 1e-6:
        up = np.array([1.0, 0.0, 0.0])
        if np.linalg.norm(np.cross(up, fwd)) < 1e-6:
            up = np.array([0.0, 1.0, 0.0])
    right = normalize(np.cross(up, fwd))
    true_down = np.cross(fwd, right)
    return np.column_stack([right, true_down, fwd])


def roll_about_axis(axis, angle_rad) -> np.ndarray:
    return Rotation.from_rotvec(normalize(axis) * float(angle_rad)).as_matrix()
