# TODO

## Tests

- [ ] **`tests/test_build_scan_cloud_smoke.py` is stale — rewrite against the current API.**
  It was already failing before the 2026-09-07 extrinsics-override change (not caused by it).
  - Calls `build_arm_cloud(cap, _args())` — a long-superseded 2-arg
    `(cap_dir, args-Namespace)` signature. Current signature is
    `build_arm_cloud(cap_dir, arm_label, cfg, flange_cam_override=None)` and it takes a
    merged **config dict** (see `load_config`), not an `argparse.Namespace`.
  - Asserts on removed meta keys, e.g. `meta["n_points_pre_voxel"]`. Current meta keys:
    `n_points_pre_processing`, `n_points_after_tcp_exclusion`, `n_points_after_voxel`,
    `n_points_after_global_z`, `n_points_final` (plus new `extrinsics_source`,
    `n_frames_extrinsics_overridden`).
  - The other two suites pass: `tests/test_scan_cloud_backproject.py`,
    `tests/test_recalibrate_cam_flange.py`.
  - While rewriting, add a case that exercises the new extrinsics override: build a synthetic
    2-frame capture, run `build_arm_cloud` once with `flange_cam_override=None` and once with
    a known `T_flange_cam`, and assert the cloud shifts by the expected rigid transform and
    that `meta["n_frames_extrinsics_overridden"]` matches the frame count.
  - Referenced from `README.md` "Testing without hardware" — keep that in sync.
