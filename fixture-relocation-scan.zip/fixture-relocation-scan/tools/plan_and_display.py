#!/usr/bin/env python3
"""Offline RViz animation of a fixture_scan ``scan_program.json`` (the real scan motion).

Concatenates every viewpoint's pre-planned ``trajectory`` (the lead-in from ``q_current``
plus each between-viewpoint segment) and publishes it as one
``moveit_msgs/DisplayTrajectory`` on ``/<robot>/display_planned_path`` so RViz's "Planned
Path" animates the whole scan. NO camera, NO ArUco, NO move_group, NO execution.

The program itself is produced by the viewpoint planner -- host
``python3 -m fixture_scan.run_viewpoint_planner --arm hold --out scan_program.json`` (add
``--rviz`` there for the funnel + selected-viewpoint markers, which this tool does not
show). The ad-hoc half-circle orbit preview this tool used to carry was retired with the
orbit path itself; ``run_viewpoint_planner --rviz`` is the live preview now.

Prereqs (host shell, ROS 2 Humble + franka_ros2_ws overlay sourced; run under the
``fabrica-kuka-pdz8`` conda env so numpy/scipy are consistent):

    ros2 launch lbr_dual_arm_bringup mock.launch.py            # RSP + mock control + joint_states
    ros2 launch lbr_dual_arm_moveit_config moveit_rviz.launch.py

    python3 ~/fixture-relocation-scan/tools/plan_and_display.py --scan-program scan_program.json
"""

import argparse
import os
import sys
import time

import numpy as np
import rclpy
from builtin_interfaces.msg import Duration as DurationMsg
from moveit_msgs.msg import DisplayTrajectory, RobotState, RobotTrajectory
from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# _ARM is module-private in arm_planner but this is a debug tool in the same package --
# imported (not re-typed) so base-frame / TCP-link / joint-name definitions have one source.
from fixture_relocation_scan.arm_planner import _ARM

DISPLAY_DT_S = 0.1                  # RViz animation pacing ONLY -- not the real retiming
JOINT_STATES_WAIT_S = 10.0         # startup wait for the first /<robot>/joint_states


def read_current_joint_states(node, robot_name):
    """Block for the first /<robot>/joint_states and return {joint_name: position} for all
    14 arm joints -- the render base so BOTH arms show at their real current pose."""
    want = set(_ARM["hold"][3]) | set(_ARM["move"][3])
    latest = {}

    def _cb(msg):
        for n, p in zip(msg.name, msg.position):
            if n in want:
                latest[n] = float(p)

    sub = node.create_subscription(JointState, f"/{robot_name}/joint_states", _cb, 10)
    deadline = time.monotonic() + JOINT_STATES_WAIT_S
    while rclpy.ok() and not want.issubset(latest) and time.monotonic() < deadline:
        rclpy.spin_once(node, timeout_sec=0.1)
    node.destroy_subscription(sub)
    if not want.issubset(latest):
        missing = sorted(want - set(latest))
        raise RuntimeError(
            f"/{robot_name}/joint_states missing {len(missing)} joints after "
            f"{JOINT_STATES_WAIT_S}s ({missing[:3]}...). Is mock.launch.py up?")
    return latest


def publish_display(node, pub, role, points, q_now):
    """points: list of (7-vec scanning-arm config, t_seconds). q_now: {joint: pos} for all 14
    -- the render base, so BOTH arms show at their real current pose, with the scanning arm
    then animating along `points`."""
    _, base_frame, _, joint_names = _ARM[role]

    jt = JointTrajectory()
    jt.header.frame_id = base_frame
    jt.joint_names = list(joint_names)
    for q, t in points:
        pt = JointTrajectoryPoint()
        pt.positions = [float(x) for x in q]
        pt.time_from_start = DurationMsg(sec=int(t), nanosec=int((t % 1.0) * 1e9))
        jt.points.append(pt)

    rt = RobotTrajectory()
    rt.joint_trajectory = jt

    start_state = RobotState()
    ss = JointState()
    ss.name = list(q_now.keys())
    ss.position = [float(v) for v in q_now.values()]
    start_state.joint_state = ss
    start_state.is_diff = True

    disp = DisplayTrajectory()
    disp.model_id = "lbr_dual_arm"
    disp.trajectory_start = start_state
    disp.trajectory.append(rt)
    pub.publish(disp)
    node.get_logger().info(f"[{role}] published DisplayTrajectory ({len(jt.points)} points)")


def _display_scan_program(node, disp_pub, program_path, q_now):
    """Animate a fixture_scan scan_program.json: concatenate every viewpoint's
    `trajectory` (lead-in + between-viewpoint segments) and publish one DisplayTrajectory,
    idle arm pinned at its current pose."""
    from fixture_scan.scan_program import load_program

    program = load_program(program_path)
    role = program.role
    all_points = [(program.q_current, 0.0)]
    t_acc = 0.0
    for vp in program.viewpoints:
        for q in vp.trajectory[1:]:
            t_acc += DISPLAY_DT_S
            all_points.append((np.asarray(q, dtype=float), t_acc))
    node.get_logger().info(
        f"[{role}] scan_program {program_path}: {len(program.viewpoints)} viewpoints, "
        f"tiers {program.meta.get('segment_tiers')}, config_sha "
        f"{program.meta.get('config_sha')}")
    publish_display(node, disp_pub, role, all_points, q_now)
    print("\n=== SCAN PROGRAM ===")
    for vp in program.viewpoints:
        print(f"   vp {vp.index:2d}  marker {vp.marker_id}  {vp.traj_tier:13s} "
              f"{vp.trajectory.shape[0]} wp   S={vp.debug.get('S')}")


def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--scan-program", required=True,
                    help="fixture_scan viewpoint-planner output (scan_program.json) to "
                         "animate. No move_group needed.")
    ap.add_argument("--robot-name", default="lbr_dual_arm")
    args = ap.parse_args()

    rclpy.init()
    node = rclpy.create_node("plan_and_display")
    disp_pub = node.create_publisher(
        DisplayTrajectory, f"/{args.robot_name}/display_planned_path", 1)

    try:
        q_now = read_current_joint_states(node, args.robot_name)
    except RuntimeError as exc:
        node.get_logger().error(str(exc))
        node.destroy_node()
        rclpy.shutdown()
        sys.exit(1)

    _display_scan_program(node, disp_pub, args.scan_program, q_now)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
