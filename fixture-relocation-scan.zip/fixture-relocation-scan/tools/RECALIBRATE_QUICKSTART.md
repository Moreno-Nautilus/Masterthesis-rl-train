# Wrist-camera recalibration + point-cloud inspection — quickstart

Two host-side tools read the **same** ArUco/depth capture that `scan_fixture.py --capture-depth`
leaves in the fixture log dir — for the plumbers_block plan that is
`~/Fabrica-pdz/logs/kuka_pdz8_cm_aruco/<plan>/fixture/`:

```
<fixture>/hold_depth_capture/   frame_*.npz + color_*.png   left  / realsense_1 / lbr_one ("hold" arm)
<fixture>/move_depth_capture/   frame_*.npz + color_*.png   right / realsense_2 / lbr_two ("move" arm)
<fixture>/nominal_world_pose.json     ArUco board geometry (built from fixture/markers.json)
<fixture>/markers.json               marker sizes + relative poses on the plate
```

| tool | purpose |
|------|---------|
| `tools/build_scan_cloud.py` | reconstruct `hold/move/both_pointcloud.ply` for **visual inspection** |
| `tools/recalibrate_cam_flange.py` | refine each wrist camera's `T_flange_cam` from the ArUco board in those frames |

Nothing new has to be captured or configured — the recalibration reuses the exact frames the
point-cloud inspection uses, and reads the nominal `T_flange_cam` that was in force at capture
time straight out of each `frame_*.npz` (`tools/camera_transforms.yaml` just mirrors it).

---

## Why the board's world pose is not needed

The marker plate is rigid and does not move during a capture, so for every frame *i* of camera *c*:

```
T_baseC_flange_i @ T_flangeC_camC @ T_camC_board_i = T_baseC_board      (same, every frame)
```

* `T_baseC_flange_i` — robot FK, stored in each `frame_*.npz`.
* marker corner geometry — known from `markers.json` → `nominal_world_pose.json.opencv.board_obj_points_m`.
* Unknowns: the hand-eye `T_flangeC_camC` **and** the single constant board pose `T_baseC_board`.

Classic robot-world / hand-eye (`A X = Z B`) — observable from a few views with rotation
about non-parallel axes; the board pose is a **solved output**, never an input.

Both arms see the **same plate** (markers 4 and 5 show up in both `hold` and `move` frames),
and the two arm bases are related by a fixed transform (`board_origin` in
`nominal_world_pose.json`). So the solve is **joint**: one board pose (in the left base) + a
bounded 6-DoF correction to each camera's `T_flange_cam`, found by **reprojection bundle
adjustment** — minimising the pixel error of every detected marker corner across all frames
of both cameras at once. (Per-frame PnP on a single ~27 mm near-coplanar marker cluster is
noisy at the cm/deg level; the pixel-level BA is far better conditioned.)

---

## 0. Environment

Pure `numpy`/`scipy`/`opencv-python(>=4.7, cv2.aruco)`/`PyYAML` for the recalibration, plus
`open3d` for `build_scan_cloud.py --view`. All in `requirements.txt`. **No ROS needed** — both
tools are host-side and run in any env with those packages (e.g. the `bagviz` / `fabrica-kuka-pdz8`
conda env, or the `vision` container's venv).

---

## 1. Visualize the point clouds

```bash
python3 tools/build_scan_cloud.py \
    --fixture-dir ~/Fabrica-pdz/logs/kuka_pdz8_cm_aruco/plumbers_block_new_3/fixture --view
```

Three Open3D windows in turn (close each to advance): **hold**, **move**, then the **combined**
cloud (move shifted into the hold base via `nominal_world_pose.json`). Also writes
`hold/move/both_pointcloud.ply` + `*_meta.json`; open the `.ply`s in MeshLab/CloudCompare if
`open3d` is unavailable.

What you are looking for: the board/table from the two cameras should **coincide** in the
combined cloud. A visible split of the board between the two colours is the miscalibration the
next step corrects. Tunables live in `tools/build_scan_cloud.yaml` (a few on the CLI:
`--voxel-m`, `--z-min/-max`, `--uniform-k`); its `arms:` block already points at
`hold_depth_capture` / `move_depth_capture`.

---

## 2. Recalibrate

```bash
python3 tools/recalibrate_cam_flange.py --plan plumbers_block_new_3
```

`--plan X` is shorthand for `--fixture-dir ~/Fabrica-pdz/logs/kuka_pdz8_cm_aruco/X/fixture`;
use `--fixture-dir` directly for any other location. Defaults:
`--nominal-pose <fixture>/nominal_world_pose.json`,
`--camera-transforms tools/camera_transforms.yaml` (fallback/cross-check only — the nominal
is taken from the frames),
`--out tools/camera_transforms_recalibrated.yaml`. **The nominal file is never edited in place.**

### What it prints

1. **Per camera** — nominal vs recalibrated `T_flange_cam`, the correction (deg / mm; flagged
   if it hits the ±8°/±30 mm plausibility bound), an optional `cv2.calibrateRobotWorldHandEye`
   cross-check, and **reprojection RMS before → after** (the headline quality number; all
   marker corners, all frames), plus the raw per-frame PnP scatter as context.
2. **AVERAGE FIXTURE (BOARD) POSE — before vs after**, for **each** camera in its own arm
   base: the "before" is the mean of the noisy per-frame PnP estimates with the nominal
   extrinsic; the "after" is the single board pose the BA solved.
3. **FIXTURE POSE AVERAGED ACROSS BOTH CAMERAS** (in `lbr_one_link_0`): pooled "before"
   mean + spread + the **left-cam vs right-cam disagreement**, and the single solved "after"
   pose. In the joint solve the two cameras share one board pose by construction; the "before"
   disagreement is the number that should have been near zero and wasn't.
4. **VERDICT** — clean / at-bound / marginal.
5. A paste-ready `realsense_1:` / `realsense_2:` `R`/`t` block, also written to
   `camera_transforms_recalibrated.yaml`.

### Reading it

* **reprojection RMS drops to ~1 px, correction within a few °/mm, VERDICT clean** → trust it.
* Cross-check that the solved fixture pose lands near the plan's `board_origin` in
  `nominal_world_pose.json` (`lbr_one_link_0` / `lbr_two_link_0`). On the current
  plumbers_block capture the nominal calibration put the fixture ~20 mm low and the two
  cameras 37 mm / 5° apart; after recal they agree on one pose ~3 mm / ~1° from the design
  origin.
* **"at bound" / VERDICT at-bound** → the data wants a bigger change than a real mount error:
  inspect the skip list + per-frame reproj, recapture with more viewpoint tilt/spread.
* **VERDICT marginal** → reproj improved but residuals stay high (few, near-coplanar views);
  treat as indicative.
* `--no-joint` solves each camera independently (no shared board / base-to-base) — a useful
  cross-check and the fallback when only one arm was captured.

### Options

| flag | meaning |
|------|---------|
| `--no-joint` | per-camera solve, no shared board pose |
| `--base-to-base "dx,dy,dz"` / `--base-to-base single` | override `T_baseR_baseL` (default: from `board_origin`) |
| `--huber-px X` | Huber loss scale on corner reprojection residuals (default 1.0 px) |
| `--min-corners N` | min matched ArUco corners to keep a frame (default 4 = one marker) |
| `--max-reproj-px X` | drop a frame whose PnP board solve reprojects worse than X (default 3.0) |
| `--camera-transforms FILE` | nominal source if the frames lack `T_flange_cam` |

---

## 3. Apply

Back up, then copy the printed `R` / `t` into
`~/Masterthesis-vision/config/camera_extrinsics_realsense.yaml` under `realsense_1` (left /
hold) and `realsense_2` (right / move):

```bash
cp ~/Masterthesis-vision/config/camera_extrinsics_realsense.yaml{,.$(date +%Y%m%d).bak}
# paste realsense_1.R/.t and realsense_2.R/.t from tools/camera_transforms_recalibrated.yaml
```

Re-run step 1 on the same capture to confirm the board halves now coincide, and/or re-run
step 2 and check the before/after fixture-pose disagreement. To make the new values the
nominal for future runs of this tool, also copy them into `tools/camera_transforms.yaml`
(or pass `--camera-transforms tools/camera_transforms_recalibrated.yaml`).

### Before / after point clouds without touching the on-rig calibration

`build_scan_cloud.py` can rebuild every cloud from a flange->camera extrinsics file instead
of the `T_base_cam` baked into each capture `.npz`. `build_scan_cloud.yaml`'s `extrinsics:`
block points at `recalibrated_extrinsics.yaml` with `enabled: true` by default:

```bash
python3 tools/build_scan_cloud.py --fixture-dir <fixture> --view                   # recalibrated
python3 tools/build_scan_cloud.py --fixture-dir <fixture> --view --no-extrinsics   # as-captured nominal
python3 tools/build_scan_cloud.py --fixture-dir <fixture> --view \
    --extrinsics tools/camera_transforms_recalibrated.yaml                         # any other file
```

The recalibrated combined cloud should show the two board halves collapsing onto one plane
that the RealSense depth of the real slab surface sits on.

---

## No data? Synthetic demo

```bash
python3 tools/recalibrate_cam_flange.py --selftest        # synth capture w/ known truth, recal, verify
python3 tools/recalibrate_cam_flange.py --make-selftest-fixture /tmp/rc_demo \
    --nominal-pose ~/Fabrica-pdz/logs/kuka_pdz8_cm_aruco/plumbers_block_new_3/fixture/nominal_world_pose.json
```

`--selftest` injects ~2.5–3° / ~6–7 mm of extrinsic error and checks the BA brings each camera
back to <0.1° / <0.5 mm of ground truth. `--make-selftest-fixture` drops a synthetic
`hold_depth_capture/` + `move_depth_capture/` on disk (readable by **both** tools) plus the
perturbed `camera_transforms_nominal.yaml` to recalibrate against.

Regression test: `python3 tests/test_recalibrate_cam_flange.py`.
