#!/usr/bin/env python3
"""Build and visualize diagnostic point clouds from robot depth captures.

The processing pipeline is:

    per frame:
        load depth + K + T_base_cam + T_base_flange
        -> optional median depth filter
        -> depth range gate
        -> pinhole backprojection
        -> uniform per-frame downsample
        -> transform camera -> arm base
        -> optional board-relative ROI

    per arm:
        concatenate frames
        -> TCP exclusion sphere around the flange position
        -> voxel downsample
        -> global Z gate
        -> optional statistical outlier removal

    combined:
        left cloud remains in left-base frame
        right cloud is translated into left-base frame using nominal_world_pose.json

Visualization (with --view):
    1. left
    2. right
    3. combined
    Each window blocks until it is closed before the next is shown.

All tunable processing parameters live in build_scan_cloud.yaml by default.
The CLI exposes only the main workflow/decimation overrides.
"""

import argparse
import glob
import json
import os
import sys

import numpy as np


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CONFIG = os.path.join(SCRIPT_DIR, "build_scan_cloud.yaml")


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

def load_config(path):
    try:
        import yaml
    except ImportError as exc:
        raise RuntimeError(
            "PyYAML is required to read the config. Install it with: pip install pyyaml"
        ) from exc

    with open(path, "r") as fp:
        cfg = yaml.safe_load(fp) or {}

    # Keep defaults robust if a config is missing a section/key.
    defaults = {
        "depth": {
            "z_min_m": 0.05,
            "z_max_m": 1.2,
            "median_blur_ksize": 0,
        },
        "downsampling": {
            "uniform_k": 5,
            "voxel_m": 0.003,
        },
        "tcp_exclusion": {
            "enabled": True,
            "radius_m": 0.1505,
        },
        "global_z_gate": {
            "enabled": True,
            "min_m": -0.04,
            "max_m": 0.20,
        },
        "roi": {
            "enabled": False,
            "half_xy_m": 0.40,
            "z_m": [-0.05, 0.50],
        },
        "sor": {
            "enabled": False,
            "neighbors": 20,
            "std_ratio": 2.0,
        },
        "extrinsics": {
            "enabled": False,
            "file": None,
        },
        "output": {
            "color": True,
        },
        "visualization": {
            "coordinate_frame_size_m": 0.10,
        },
        "arms": {
            "left_capture_subdir": "hold_depth_capture",
            "right_capture_subdir": "move_depth_capture",
            "left_label": "left",
            "right_label": "right",
        },
    }

    def merge(dst, src):
        for k, v in src.items():
            if isinstance(v, dict) and isinstance(dst.get(k), dict):
                merge(dst[k], v)
            else:
                dst[k] = v

    merge(defaults, cfg)
    return defaults


def apply_cli_overrides(cfg, args):
    if args.uniform_k is not None:
        cfg["downsampling"]["uniform_k"] = args.uniform_k
    if args.voxel_m is not None:
        cfg["downsampling"]["voxel_m"] = args.voxel_m
    if args.z_min is not None:
        cfg["depth"]["z_min_m"] = args.z_min
    if args.z_max is not None:
        cfg["depth"]["z_max_m"] = args.z_max
    if args.no_color:
        cfg["output"]["color"] = False
    if args.extrinsics is not None:
        cfg["extrinsics"]["enabled"] = True
        cfg["extrinsics"]["file"] = args.extrinsics
    if args.no_extrinsics:
        cfg["extrinsics"]["enabled"] = False
    return cfg


def load_flange_cam_extrinsics(path):
    """Read a flange->camera extrinsics YAML (camera_transforms.yaml /
    recalibrated_extrinsics.yaml layout) -> {'left': T_flange_cam(4x4),
    'right': T_flange_cam(4x4)}.

    Each entry (keyed 'left'/'right' or 'realsense_1'/'realsense_2') carries
    R (nine row-major numbers) and t (three metres); p_flange = R @ p_cam + t.
    """
    try:
        import yaml
    except ImportError as exc:  # pragma: no cover - same guard as load_config
        raise RuntimeError(
            "PyYAML is required to read the extrinsics file. "
            "Install it with: pip install pyyaml"
        ) from exc

    with open(path, "r") as fp:
        data = yaml.safe_load(fp) or {}

    out = {}
    for side, alt in (("left", "realsense_1"), ("right", "realsense_2")):
        entry = data.get(side) or data.get(alt)
        if entry is None:
            raise KeyError(f"{path}: no '{side}' or '{alt}' entry")
        T = np.eye(4)
        T[:3, :3] = np.asarray(entry["R"], dtype=float).reshape(3, 3)
        T[:3, 3] = np.asarray(entry["t"], dtype=float).reshape(3)
        out[side] = T
    return out


# ---------------------------------------------------------------------------
# Per-frame processing
# ---------------------------------------------------------------------------

def _load_frame(npz_path):
    d = np.load(npz_path, allow_pickle=True)

    T_base_flange = (
        d["T_base_flange"].astype(float)
        if "T_base_flange" in d
        else None
    )

    if "T_base_cam" in d:
        T_base_cam = d["T_base_cam"].astype(float)
    elif "T_base_flange" in d and "T_flange_cam" in d:
        T_base_cam = (
            d["T_base_flange"].astype(float) @ d["T_flange_cam"].astype(float)
        )
    else:
        raise KeyError(
            f"{npz_path} contains neither T_base_cam nor the "
            "T_base_flange + T_flange_cam pair"
        )

    return {
        "depth_m": d["depth_m"].astype(np.float32),
        "K": d["K_depth"].astype(float).reshape(3, 3),
        "T_base_cam": T_base_cam,
        "T_base_flange": T_base_flange,
        "T_base_board": (
            d["T_base_board"].astype(float)
            if "T_base_board" in d else None
        ),
        "vp_index": int(d["vp_index"]) if "vp_index" in d else -1,
        "dt_sync": float(d["dt_sync"]) if "dt_sync" in d else float("nan"),
        "path": npz_path,
    }


def _maybe_median_blur(depth_m, ksize):
    if not ksize:
        return depth_m

    try:
        import cv2
    except ImportError:
        print(
            "  median_blur needs opencv-python; skipping blur",
            file=sys.stderr,
        )
        return depth_m

    ksize = int(ksize)
    if ksize < 3 or ksize % 2 == 0:
        raise ValueError("median_blur_ksize must be 0 or an odd integer >= 3")

    clean = np.where(np.isfinite(depth_m), depth_m, 0.0).astype(np.float32)
    blurred = cv2.medianBlur(clean, ksize)

    # Preserve invalid pixels as invalid.
    return np.where(clean > 0, blurred, 0.0)


def _backproject(depth_m, K, z_min, z_max):
    """Pinhole backproject valid pixels -> camera optical frame."""
    h, w = depth_m.shape
    us, vs = np.meshgrid(np.arange(w), np.arange(h))

    valid = (
        np.isfinite(depth_m)
        & (depth_m > z_min)
        & (depth_m < z_max)
    )

    z = depth_m[valid]
    x = (us[valid] - K[0, 2]) * z / K[0, 0]
    y = (vs[valid] - K[1, 2]) * z / K[1, 1]

    return np.stack([x, y, z], axis=1), valid


def _load_color(npz_path, valid):
    color_path = npz_path.replace("frame_", "color_").replace(".npz", ".png")
    if not os.path.exists(color_path):
        return None

    try:
        import cv2
    except ImportError:
        return None

    bgr = cv2.imread(color_path, cv2.IMREAD_COLOR)
    if bgr is None or bgr.shape[:2] != valid.shape:
        return None

    return bgr[valid][:, ::-1].astype(np.float64) / 255.0


def _roi_mask(points_base, T_base_board, half_xy, z_lo, z_hi):
    """Keep points in a board-frame box."""
    c = T_base_board[:3, 3]
    R = T_base_board[:3, :3]

    # R maps board-frame vectors into base frame, therefore R.T converts
    # base-frame vectors into board coordinates.
    local = (points_base - c) @ R

    return (
        (np.abs(local[:, 0]) <= half_xy)
        & (np.abs(local[:, 1]) <= half_xy)
        & (local[:, 2] >= z_lo)
        & (local[:, 2] <= z_hi)
    )


# ---------------------------------------------------------------------------
# Cloud processing
# ---------------------------------------------------------------------------

def voxel_downsample(points, colors, voxel_m):
    """Collapse points sharing a voxel to their centroid and mean colour."""
    if voxel_m <= 0 or len(points) == 0:
        return points, colors

    keys = np.floor(points / voxel_m).astype(np.int64)
    _, inv, counts = np.unique(
        keys, axis=0, return_inverse=True, return_counts=True
    )
    inv = inv.ravel()

    summed = np.zeros((len(counts), 3), dtype=np.float64)
    np.add.at(summed, inv, points)
    out_pts = summed / counts[:, None]

    out_cols = None
    if colors is not None:
        csum = np.zeros((len(counts), 3), dtype=np.float64)
        np.add.at(csum, inv, colors)
        out_cols = csum / counts[:, None]

    return out_pts, out_cols


voxel_average = voxel_downsample


def remove_statistical_outliers(points, colors, k, std_ratio):
    """Numpy/scipy implementation of statistical outlier removal."""
    if k <= 0 or len(points) <= k:
        return points, colors

    from scipy.spatial import cKDTree

    tree = cKDTree(points)
    d, _ = tree.query(points, k=k + 1)
    mean_d = d[:, 1:].mean(axis=1)

    keep = mean_d <= mean_d.mean() + std_ratio * mean_d.std()

    return (
        points[keep],
        colors[keep] if colors is not None else None,
    )


def apply_tcp_exclusion(points, colors, tcp_positions, radius_m):
    """Remove points inside radius_m of any captured flange/TCP position.

    tcp_positions are in the same base frame as points. This deliberately
    excludes a sphere around the flange because the robotic hand/TCP is
    15.05 cm away from the flange. Thus radius_m=0.1505 removes the region
    occupied by the hand around each captured flange pose.
    """
    if radius_m <= 0 or len(points) == 0 or not tcp_positions:
        return points, colors

    from scipy.spatial import cKDTree

    tcp = np.asarray(tcp_positions, dtype=np.float64).reshape(-1, 3)
    tree = cKDTree(tcp)

    # query_ball_point(..., return_length=True) gives the number of flange
    # positions within radius of each point. Keep points with zero hits.
    try:
        n_hits = tree.query_ball_point(
            points, radius_m, return_length=True
        )
        keep = n_hits == 0
    except TypeError:
        # Compatibility with older scipy versions.
        neighbours = tree.query_ball_point(points, radius_m)
        keep = np.fromiter(
            (len(x) == 0 for x in neighbours),
            dtype=bool,
            count=len(points),
        )

    return (
        points[keep],
        colors[keep] if colors is not None else None,
    )



def apply_global_gates(points, colors, z_min, z_max, x_min, x_max, y_min, y_max):
    """Keep points in the base/global frame z interval."""
    if len(points) == 0:
        return points, colors

    keep = (points[:, 2] >= z_min) & (points[:, 2] <= z_max)
    keep = (points[:, 1] >= y_min) & (points[:, 1] <= y_max)
    keep = (points[:, 0] >= x_min) & (points[:, 0] <= x_max)

    return (
        points[keep],
        colors[keep] if colors is not None else None,
    )


# ---------------------------------------------------------------------------
# I/O
# ---------------------------------------------------------------------------

def write_ply(path, points, colors=None):
    with open(path, "wb") as fp:
        hdr = [
            "ply",
            "format binary_little_endian 1.0",
            f"element vertex {len(points)}",
            "property float x",
            "property float y",
            "property float z",
        ]

        if colors is not None:
            hdr += [
                "property uchar red",
                "property uchar green",
                "property uchar blue",
            ]

        hdr += ["end_header", ""]
        fp.write("\n".join(hdr).encode("ascii"))

        if colors is None:
            fp.write(points.astype("<f4").tobytes())
        else:
            rec = np.empty(
                len(points),
                dtype=[("xyz", "<f4", 3), ("rgb", "u1", 3)],
            )
            rec["xyz"] = points
            rec["rgb"] = np.clip(
                colors * 255.0, 0, 255
            ).astype(np.uint8)
            fp.write(rec.tobytes())


# ---------------------------------------------------------------------------
# Arm cloud
# ---------------------------------------------------------------------------

def build_arm_cloud(cap_dir, arm_label, cfg, flange_cam_override=None):
    """Return points/colors/meta for one arm in that arm's base frame.

    If `flange_cam_override` (a 4x4 T_flange_cam) is given, each frame's
    camera->base transform is recomputed as T_base_flange @ flange_cam_override
    instead of using the T_base_cam stored in the capture .npz.
    """
    npz_paths = sorted(glob.glob(os.path.join(cap_dir, "frame_*.npz")))
    if not npz_paths:
        raise FileNotFoundError(f"no frame_*.npz in {cap_dir}")

    manifest_path = os.path.join(cap_dir, "manifest.json")
    manifest = (
        json.load(open(manifest_path))
        if os.path.exists(manifest_path)
        else {}
    )

    depth_cfg = cfg["depth"]
    ds_cfg = cfg["downsampling"]
    roi_cfg = cfg["roi"]

    all_pts = []
    all_cols = []
    tcp_positions = []
    per_frame = []

    have_color = bool(cfg["output"]["color"])
    n_override = 0

    for p in npz_paths:
        fr = _load_frame(p)

        if flange_cam_override is not None:
            if fr["T_base_flange"] is None:
                raise KeyError(
                    f"{p}: extrinsics override requested but the frame has no "
                    "T_base_flange to compose it with"
                )
            fr["T_base_cam"] = fr["T_base_flange"] @ flange_cam_override
            n_override += 1

        depth = _maybe_median_blur(
            fr["depth_m"],
            depth_cfg["median_blur_ksize"],
        )

        pts_cam, valid = _backproject(
            depth,
            fr["K"],
            depth_cfg["z_min_m"],
            depth_cfg["z_max_m"],
        )

        cols = _load_color(p, valid) if have_color else None

        # Uniform per-frame downsampling.
        uniform_k = int(ds_cfg["uniform_k"])
        if uniform_k > 1:
            pts_cam = pts_cam[::uniform_k]
            if cols is not None:
                cols = cols[::uniform_k]

        T = fr["T_base_cam"]
        pts_base = (
            (T[:3, :3] @ pts_cam.T).T
            + T[:3, 3]
        )

        if (
            roi_cfg["enabled"]
            and fr["T_base_board"] is not None
        ):
            m = _roi_mask(
                pts_base,
                fr["T_base_board"],
                roi_cfg["half_xy_m"],
                roi_cfg["z_m"][0],
                roi_cfg["z_m"][1],
            )
            pts_base = pts_base[m]
            if cols is not None:
                cols = cols[m]

        # Save the flange position from THIS captured frame.
        # This is the actual robot pose associated with the depth image,
        # not a nominal waypoint pose.
        if fr["T_base_flange"] is not None:
            tcp_positions.append(fr["T_base_flange"][:3, 3].copy())

        if cols is None:
            have_color = False

        all_pts.append(pts_base)
        all_cols.append(cols)

        per_frame.append({
            "file": os.path.basename(p),
            "vp_index": fr["vp_index"],
            "dt_sync_s": fr["dt_sync"],
            "n_points": int(len(pts_base)),
        })

        print(
            f"  {os.path.basename(p)}: {len(pts_base):7d} pts"
            f"  (dt_sync={fr['dt_sync'] * 1e3:.0f} ms)"
        )

    pts = np.concatenate(all_pts, axis=0)
    cols = (
        np.concatenate(all_cols, axis=0)
        if have_color and all(c is not None for c in all_cols)
        else None
    )

    n_pre = len(pts)

    # TCP/flange exclusion BEFORE voxelization.
    tcp_removed = 0
    if cfg["tcp_exclusion"]["enabled"]:
        before = len(pts)
        pts, cols = apply_tcp_exclusion(
            pts,
            cols,
            tcp_positions,
            cfg["tcp_exclusion"]["radius_m"],
        )
        tcp_removed = before - len(pts)

    n_after_tcp = len(pts)

    # Voxel downsample.
    pts, cols = voxel_downsample(
        pts,
        cols,
        ds_cfg["voxel_m"],
    )
    n_voxel = len(pts)

    # Global Z gate AFTER voxelization and BEFORE SOR.
    z_removed = 0
    if cfg["global_z_gate"]["enabled"]:
        before = len(pts)
        pts, cols = apply_global_gates(
            pts,
            cols,
            cfg["global_z_gate"]["min_m"],
            cfg["global_z_gate"]["max_m"],
            cfg["global_x_gate"]["min_m"],
            cfg["global_x_gate"]["max_m"],
            cfg["global_y_gate"]["min_m"],
            cfg["global_y_gate"]["max_m"],
        )
        z_removed = before - len(pts)

    n_after_z = len(pts)

    # Optional SOR, last.
    if cfg["sor"]["enabled"]:
        pts, cols = remove_statistical_outliers(
            pts,
            cols,
            cfg["sor"]["neighbors"],
            cfg["sor"]["std_ratio"],
        )

    meta = {
        "capture_dir": os.path.abspath(cap_dir),
        "arm": manifest.get("arm", arm_label),
        "n_frames": len(npz_paths),
        "extrinsics_source": (
            "override: T_base_flange @ T_flange_cam from config"
            if flange_cam_override is not None
            else "as captured (T_base_cam baked into .npz)"
        ),
        "n_frames_extrinsics_overridden": int(n_override),
        "n_points_pre_processing": int(n_pre),
        "n_points_after_tcp_exclusion": int(n_after_tcp),
        "n_points_after_voxel": int(n_voxel),
        "n_points_after_global_z": int(n_after_z),
        "n_points_final": int(len(pts)),
        "tcp_positions_count": len(tcp_positions),
        "tcp_points_removed": int(tcp_removed),
        "global_z_points_removed": int(z_removed),
        "params": cfg,
        "bbox_min": pts.min(axis=0).tolist() if len(pts) else None,
        "bbox_max": pts.max(axis=0).tolist() if len(pts) else None,
        "per_frame": per_frame,
    }

    return pts, cols, meta


# ---------------------------------------------------------------------------
# Coordinate-frame conversion
# ---------------------------------------------------------------------------

def _base_to_base_offset(nominal_pose_path):
    """Translation from right/move base into left/hold base.

    This preserves the existing nominal_world_pose convention: the two base
    frames are assumed to have aligned orientations, so only translation is
    applied.
    """
    with open(nominal_pose_path, "r") as fp:
        nominal = json.load(fp)

    p_left = np.array(
        nominal["board_origin"]["lbr_one_link_0"]["position_m"],
        dtype=float,
    )
    p_right = np.array(
        nominal["board_origin"]["lbr_two_link_0"]["position_m"],
        dtype=float,
    )

    return p_left - p_right


# ---------------------------------------------------------------------------
# Visualization
# ---------------------------------------------------------------------------

def visualize_cloud(title, points, colors, coordinate_frame_size_m):
    import open3d as o3d

    pc = o3d.geometry.PointCloud()
    pc.points = o3d.utility.Vector3dVector(points)

    if colors is not None:
        pc.colors = o3d.utility.Vector3dVector(colors)

    frame = o3d.geometry.TriangleMesh.create_coordinate_frame(
        size=coordinate_frame_size_m
    )

    print(f"[view] showing {title} -- close the window to continue")
    o3d.visualization.draw_geometries(
        [pc, frame],
        window_name=title,
    )


def visualize_sequence(clouds, combined, cfg):
    try:
        import open3d  # noqa: F401
    except Exception as exc:
        print(
            f"--view unavailable ({exc}); open the .ply files in "
            "MeshLab/CloudCompare",
            file=sys.stderr,
        )
        return

    size = cfg["visualization"]["coordinate_frame_size_m"]

    # Explicitly sequential: each call blocks until its window is closed.
    visualize_cloud(
        "Left point cloud",
        clouds["left"][0],
        clouds["left"][1],
        size,
    )
    visualize_cloud(
        "Right point cloud",
        clouds["right"][0],
        clouds["right"][1],
        size,
    )
    visualize_cloud(
        "Combined point cloud (right -> left base)",
        combined[0],
        combined[1],
        size,
    )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument(
        "--capture-dir",
        help="process a single arm capture directory",
    )
    src.add_argument(
        "--fixture-dir",
        help="fixture directory containing the two arm capture directories",
    )

    ap.add_argument(
        "--config",
        default=DEFAULT_CONFIG,
        help=f"YAML config (default: {DEFAULT_CONFIG})",
    )

    # Only the most important CLI overrides.
    ap.add_argument(
        "--uniform-k",
        type=int,
        default=None,
        help="override config downsampling.uniform_k",
    )
    ap.add_argument(
        "--voxel-m",
        type=float,
        default=None,
        help="override config downsampling.voxel_m in metres",
    )
    ap.add_argument(
        "--z-min",
        type=float,
        default=None,
        help="override config depth.z_min_m",
    )
    ap.add_argument(
        "--z-max",
        type=float,
        default=None,
        help="override config depth.z_max_m",
    )
    ap.add_argument(
        "--no-color",
        action="store_true",
        help="override config and disable color",
    )
    ap.add_argument(
        "--extrinsics",
        default=None,
        metavar="FILE",
        help="flange->camera extrinsics YAML (camera_transforms.yaml / "
        "recalibrated_extrinsics.yaml layout); enables the override and "
        "supersedes config extrinsics.file. Rebuilds each cloud as "
        "T_base_flange @ T_flange_cam instead of the captured T_base_cam",
    )
    ap.add_argument(
        "--no-extrinsics",
        action="store_true",
        help="ignore config extrinsics and use the as-captured T_base_cam "
        "(the nominal hand-eye) -- the 'before' of the before/after view",
    )
    ap.add_argument(
        "--view",
        action="store_true",
        help="sequentially view left, right, then combined clouds",
    )
    ap.add_argument(
        "--out-dir",
        default=None,
        help="where to write PLY/metadata (default: fixture/capture parent)",
    )
    ap.add_argument(
        "--nominal-pose",
        default=None,
        help="nominal_world_pose.json for right -> left base translation",
    )

    args = ap.parse_args()

    cfg = load_config(args.config)
    cfg = apply_cli_overrides(cfg, args)

    # Resolve the optional flange->camera extrinsics override.
    flange_cam = {}
    ext_cfg = cfg.get("extrinsics", {})
    if ext_cfg.get("enabled") and ext_cfg.get("file"):
        ext_path = os.path.expanduser(str(ext_cfg["file"]))
        if not os.path.isabs(ext_path):
            ext_path = os.path.join(os.path.dirname(os.path.abspath(args.config)), ext_path)
        if not os.path.exists(ext_path):
            ap.error(f"extrinsics file not found: {ext_path}")
        flange_cam = load_flange_cam_extrinsics(ext_path)
        print(
            f"[extrinsics] override ENABLED from {ext_path}\n"
            f"[extrinsics]   each cloud rebuilt as T_base_flange @ T_flange_cam "
            f"(left t={flange_cam['left'][:3, 3].round(4).tolist()} m, "
            f"right t={flange_cam['right'][:3, 3].round(4).tolist()} m)"
        )
    else:
        print(
            "[extrinsics] override disabled -- using the as-captured T_base_cam "
            "(nominal hand-eye in force at capture)"
        )

    if args.capture_dir:
        cap = args.capture_dir.rstrip("/")
        default_out = os.path.dirname(cap)

        # For single capture operation, infer a useful label.
        base = os.path.basename(cap).lower()
        if "left" in base or "hold" in base:
            label = "left"
        elif "right" in base or "move" in base:
            label = "right"
        else:
            label = "arm"

        jobs = [(label, cap)]

    else:
        fx = args.fixture_dir.rstrip("/")
        left_subdir = cfg["arms"]["left_capture_subdir"]
        right_subdir = cfg["arms"]["right_capture_subdir"]

        left_dir = os.path.join(fx, left_subdir)
        right_dir = os.path.join(fx, right_subdir)

        jobs = []
        if os.path.isdir(left_dir):
            jobs.append(("left", left_dir))
        if os.path.isdir(right_dir):
            jobs.append(("right", right_dir))

        if not jobs:
            ap.error(
                f"no configured capture directories found under {fx}: "
                f"{left_subdir}, {right_subdir}"
            )

        default_out = fx

    out_dir = args.out_dir or default_out
    os.makedirs(out_dir, exist_ok=True)

    clouds = {}

    for label, cap_dir in jobs:
        print(f"[{label}] {cap_dir}")

        pts, cols, meta = build_arm_cloud(
            cap_dir,
            label,
            cfg,
            flange_cam_override=flange_cam.get(label),
        )
        if flange_cam and label not in flange_cam:
            print(
                f"[{label}] no '{label}' entry in the extrinsics file; "
                "using the as-captured transform for this arm",
                file=sys.stderr,
            )

        ply = os.path.join(out_dir, f"{label}_pointcloud.ply")
        write_ply(ply, pts, cols)

        meta_path = os.path.join(
            out_dir,
            f"{label}_pointcloud_meta.json",
        )
        with open(meta_path, "w") as fp:
            json.dump(meta, fp, indent=2)

        print(
            f"[{label}] wrote {ply}  "
            f"({meta['n_points_final']} final pts from "
            f"{meta['n_frames']} frames)"
        )
        print(
            f"[{label}] TCP exclusion removed "
            f"{meta['tcp_points_removed']} points; "
            f"global-Z gate removed {meta['global_z_points_removed']} points"
        )

        clouds[label] = (pts, cols)

    # Combined cloud requires both arms.
    combined = None

    if "left" in clouds and "right" in clouds:
        nominal = (
            args.nominal_pose
            or os.path.join(default_out, "nominal_world_pose.json")
        )

        lp, lc = clouds["left"]
        rp, rc = clouds["right"]

        if os.path.exists(nominal):
            off = _base_to_base_offset(nominal)
            note = (
                f"right shifted by {off.round(4).tolist()} m "
                "into left base frame"
            )
        else:
            off = np.zeros(3)
            note = (
                f"NO nominal pose at {nominal} -- right NOT re-based; "
                "clouds overlaid raw"
            )
            print(f"[combined] {note}", file=sys.stderr)

        combined_pts = np.concatenate(
            [lp, rp + off],
            axis=0,
        )

        combined_cols = (
            np.concatenate([lc, rc], axis=0)
            if lc is not None and rc is not None
            else None
        )

        combined = (combined_pts, combined_cols)

        cpath = os.path.join(
            out_dir,
            "both_pointcloud.ply",
        )
        write_ply(cpath, combined_pts, combined_cols)

        print(
            f"[combined] wrote {cpath} "
            f"({len(combined_pts)} pts; {note})"
        )

    # Sequential visualization: left -> right -> combined.
    if args.view:
        if "left" not in clouds or "right" not in clouds or combined is None:
            print(
                "[view] combined visualization requires both left and right "
                "clouds; showing available single cloud only.",
                file=sys.stderr,
            )

            for label in ("left", "right"):
                if label in clouds:
                    visualize_cloud(
                        f"{label.capitalize()} point cloud",
                        clouds[label][0],
                        clouds[label][1],
                        cfg["visualization"]["coordinate_frame_size_m"],
                    )
        else:
            visualize_sequence(
                clouds,
                combined,
                cfg,
            )


if __name__ == "__main__":
    main()
