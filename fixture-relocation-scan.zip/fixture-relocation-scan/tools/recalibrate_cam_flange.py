#!/usr/bin/env python3
"""Refine the two wrist cameras' flange->camera hand-eye extrinsics from the ArUco-board
frames that were already captured for point-cloud inspection -- the board's absolute world
pose is not needed.

INPUT is the exact same capture the point-cloud tool reads:

    <fixture>/hold_depth_capture/   frame_*.npz + color_*.png    (left  / realsense_1 / lbr_one)
    <fixture>/move_depth_capture/   frame_*.npz + color_*.png    (right / realsense_2 / lbr_two)
    <fixture>/nominal_world_pose.json                            (ArUco board geometry, from markers.json)

produced by `scan_fixture.py --capture-depth` and living, for the plumbers_block plan, at
`~/Fabrica-pdz/logs/kuka_pdz8_cm_aruco/<plan>/fixture/`.  Nothing new needs to be recorded:
the nominal `T_flange_cam` in use at capture time is stored in every `frame_*.npz`
(`tools/camera_transforms.yaml` mirrors it and is only a fallback / an override).

WHY THE BOARD POSE CAN BE UNKNOWN
--------------------------------
The marker plate is rigid and stationary, so for every frame *i* of camera *c*

    T_baseC_flange_i @ T_flangeC_camC @ T_camC_board_i = T_baseC_board   (the same, every frame)

`T_baseC_flange_i` is robot FK (stored per frame); the marker corner geometry is known
(`markers.json` -> `nominal_world_pose.json.opencv.board_obj_points_m`). Unknowns are the
hand-eye `T_flangeC_camC` and the single constant board pose -- the classic robot-world /
hand-eye problem; the board pose is a solved output, never an input.

Both cameras see the SAME plate (markers 4 and 5 appear in both arms' frames), and the two
arm bases are related by a known fixed transform (`board_origin` in `nominal_world_pose.json`,
or --base-to-base). So the solve is JOINT: one board pose (in the left base) + a bounded
6-DoF correction to each camera's `T_flange_cam`, found by **reprojection bundle
adjustment** -- minimising the pixel error of every detected marker corner across all frames
of both cameras at once (far better conditioned than per-frame PnP with these small,
near-coplanar markers).

OUTPUT: a printed report -- nominal vs recalibrated `T_flange_cam` per camera; reprojection
RMS and fixture-pose spread before/after; the average fixture pose before/after for each
camera and averaged across both -- plus `camera_transforms_recalibrated.yaml`. The nominal
file is never edited in place.

Pure numpy / scipy / cv2.aruco -- no rclpy, no Masterthesis-vision imports.

    python3 tools/recalibrate_cam_flange.py --plan plumbers_block_new_3
    python3 tools/recalibrate_cam_flange.py --fixture-dir <dir>
    python3 tools/recalibrate_cam_flange.py --selftest        # synthetic, no data needed
"""

import argparse
import glob
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import cv2  # noqa: E402
from scipy.optimize import least_squares  # noqa: E402
from scipy.spatial.transform import Rotation  # noqa: E402

from fixture_relocation_scan.aruco_board_pose import load_board_from_nominal_pose  # noqa: E402

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_TRANSFORMS = os.path.join(SCRIPT_DIR, "camera_transforms.yaml")
DEFAULT_INTRINSICS = os.path.abspath(
    os.path.join(SCRIPT_DIR, "..", "config", "camera_intrinsics_realsense.yaml")
)
LOGS_ROOT = os.path.expanduser("~/Fabrica-pdz/logs/kuka_pdz8_cm_aruco")

# capture sub-directory name candidates, in preference order, per side.
LEFT_SUBDIRS = ("left_depth_capture", "hold_depth_capture")
RIGHT_SUBDIRS = ("right_depth_capture", "move_depth_capture")
SIDE_CAM_ID = {"left": "realsense_1", "right": "realsense_2"}

# bounds on the per-camera correction (a mechanical mount error is small); the board pose
# is left much freer since it is genuinely unknown.
CAM_CORR_ROT_RAD = np.radians(8.0)
CAM_CORR_TRANS_M = 0.030
BOARD_ROT_RAD = np.radians(45.0)
BOARD_TRANS_M = 0.30


# ---------------------------------------------------------------------------
# SE(3) helpers -- decoupled (rotvec, translation) local chart.
# ---------------------------------------------------------------------------

def _pose(R, t):
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = np.asarray(t, float).reshape(3)
    return T


def _inv(T):
    R = T[:3, :3].T
    return _pose(R, -R @ T[:3, 3])


def _exp(v):
    return _pose(Rotation.from_rotvec(v[:3]).as_matrix(), v[3:])


def _quat_wxyz_to_R(q):
    w, x, y, z = q
    return Rotation.from_quat([x, y, z, w]).as_matrix()


def _R_to_quat_wxyz(R):
    x, y, z, w = Rotation.from_matrix(R).as_quat()
    return np.array([w, x, y, z])


def _mean_pose(Ts):
    t = np.mean([T[:3, 3] for T in Ts], axis=0)
    R = Rotation.from_matrix([T[:3, :3] for T in Ts]).mean().as_matrix()
    return _pose(R, t)


def _spread(Ts, T_mean):
    dp = np.array([np.linalg.norm(T[:3, 3] - T_mean[:3, 3]) for T in Ts])
    da = np.array([
        np.linalg.norm(Rotation.from_matrix(T_mean[:3, :3].T @ T[:3, :3]).as_rotvec())
        for T in Ts
    ])
    return {
        "pos_rms_mm": 1e3 * float(np.sqrt(np.mean(dp ** 2))) if len(dp) else 0.0,
        "pos_max_mm": 1e3 * float(dp.max()) if len(dp) else 0.0,
        "ang_rms_deg": float(np.degrees(np.sqrt(np.mean(da ** 2)))) if len(da) else 0.0,
        "ang_max_deg": float(np.degrees(da.max())) if len(da) else 0.0,
    }


def _T_delta(T_from, T_to):
    d = _inv(T_from) @ T_to
    return {
        "trans_mm": 1e3 * float(np.linalg.norm(d[:3, 3])),
        "rot_deg": float(np.degrees(np.linalg.norm(Rotation.from_matrix(d[:3, :3]).as_rotvec()))),
    }


# ---------------------------------------------------------------------------
# Reprojection
# ---------------------------------------------------------------------------

def _project(K, T_cam_board, obj_board):
    """obj_board (N,3) in the board frame -> (N,2) pixels through T_cam_board and K."""
    P = (T_cam_board[:3, :3] @ obj_board.T).T + T_cam_board[:3, 3]
    z = np.clip(P[:, 2], 1e-6, None)
    u = K[0, 0] * P[:, 0] / z + K[0, 2]
    v = K[1, 1] * P[:, 1] / z + K[1, 2]
    return np.stack([u, v], axis=1)


def _reproj_rms_px(obs, X, board_in_base):
    """RMS pixel error over all corners of all frames, given extrinsic X and board pose
    in this camera's base frame."""
    sq = []
    for o in obs:
        T_cam_board = _inv(o["A"] @ X) @ board_in_base
        d = _project(o["K"], T_cam_board, o["obj"]) - o["img"]
        sq.append((d ** 2).sum(axis=1))
    return float(np.sqrt(np.concatenate(sq).mean())) if sq else 0.0


# ---------------------------------------------------------------------------
# I/O
# ---------------------------------------------------------------------------

def _load_yaml(path):
    import yaml
    with open(path, "r") as fp:
        return yaml.safe_load(fp)


def load_nominal_transforms(path):
    """camera_transforms.yaml / camera_extrinsics_realsense.yaml ->
    {'left': T_flange_cam, 'right': T_flange_cam}. R row-major, p_flange = R @ p_cam + t."""
    data = _load_yaml(path)
    out = {}
    for side, alt in (("left", "realsense_1"), ("right", "realsense_2")):
        entry = data.get(side) or data.get(alt)
        if entry is None:
            raise KeyError(f"{path}: no '{side}' or '{alt}' entry")
        out[side] = _pose(np.array(entry["R"], float).reshape(3, 3),
                          np.array(entry["t"], float).reshape(3))
    return out


def load_base_to_base(nominal_pose_path, override):
    """T_baseR_baseL: maps a point from the LEFT (lbr_one) base into the RIGHT (lbr_two)
    base. From `nominal_world_pose.json`'s `board_origin`, or --base-to-base
    "dx,dy,dz" / "single"."""
    if override:
        if override.strip().lower() == "single":
            return np.eye(4), "single base frame (--base-to-base single)"
        d = np.array([float(x) for x in override.split(",")], float)
        return _pose(np.eye(3), d), f"--base-to-base translation {d.tolist()} m"
    if nominal_pose_path and os.path.exists(nominal_pose_path):
        bo = json.load(open(nominal_pose_path)).get("board_origin", {})
        if "lbr_one_link_0" in bo and "lbr_two_link_0" in bo:
            L, R = bo["lbr_one_link_0"], bo["lbr_two_link_0"]
            T_bl = _pose(_quat_wxyz_to_R(L["quaternion_wxyz"]), L["position_m"])
            T_br = _pose(_quat_wxyz_to_R(R["quaternion_wxyz"]), R["position_m"])
            return T_br @ _inv(T_bl), f"board_origin in {os.path.basename(nominal_pose_path)}"
    return None, "unavailable"


def _find_side_dir(fixture_dir, subdirs):
    for name in subdirs:
        cand = os.path.join(fixture_dir, name)
        if os.path.isdir(cand):
            return cand
    return None


def load_observations(cap_dir, board, dictionary, intr_fallback, max_reproj_px, min_corners):
    """Per frame: detect the board, keep the matched marker corners + object points +
    intrinsic + FK pose.

    -> (observations, nominal_T_flange_cam_or_None, skipped)
       observation = {A: T_base_flange(4x4), K(3x3), obj(N,3 board frame), img(N,2 px),
                      T_cam_board_pnp(4x4), reproj_px, marker_ids, file}
    """
    npz_paths = sorted(glob.glob(os.path.join(cap_dir, "frame_*.npz")))
    if not npz_paths:
        raise FileNotFoundError(f"no frame_*.npz in {cap_dir}")
    detector = cv2.aruco.ArucoDetector(dictionary, cv2.aruco.DetectorParameters())
    obs, skipped, nominals = [], [], []
    for p in npz_paths:
        d = np.load(p, allow_pickle=True)
        color = p.replace("frame_", "color_").replace(".npz", ".png")
        name = os.path.basename(p)
        if not os.path.exists(color):
            skipped.append((name, "no color_*.png")); continue
        if "T_base_flange" not in d:
            skipped.append((name, "no T_base_flange")); continue
        img = cv2.imread(color, cv2.IMREAD_COLOR)
        if img is None:
            skipped.append((name, "unreadable color image")); continue
        K = (np.asarray(d["K_depth"], float).reshape(3, 3) if "K_depth" in d
             else intr_fallback)
        if K is None:
            skipped.append((name, "no K_depth and no --intrinsics-yaml")); continue

        corners, ids, _ = detector.detectMarkers(img)
        if ids is None or len(ids) == 0:
            skipped.append((name, "no markers")); continue
        obj, imgpts = board.matchImagePoints(corners, ids)
        if obj is None or len(obj) < max(min_corners, 4):
            skipped.append((name, f"only {0 if obj is None else len(obj)} matched corners")); continue
        obj = obj.reshape(-1, 3).astype(float)
        imgpts = imgpts.reshape(-1, 2).astype(float)

        ok, rvec, tvec = cv2.solvePnP(obj.astype(np.float32), imgpts.astype(np.float32),
                                      K, np.zeros((5, 1)), flags=cv2.SOLVEPNP_ITERATIVE)
        if not ok:
            skipped.append((name, "solvePnP failed")); continue
        T_cb = np.eye(4)
        T_cb[:3, :3] = cv2.Rodrigues(rvec)[0]
        T_cb[:3, 3] = tvec.reshape(3)
        reproj = float(np.linalg.norm(
            _project(K, T_cb, obj) - imgpts, axis=1).mean())
        if reproj > max_reproj_px:
            skipped.append((name, f"reproj {reproj:.2f}px > {max_reproj_px}px")); continue

        if "T_flange_cam" in d:
            nominals.append(np.asarray(d["T_flange_cam"], float).reshape(4, 4))
        obs.append({
            "A": np.asarray(d["T_base_flange"], float).reshape(4, 4),
            "K": K, "obj": obj, "img": imgpts, "T_cam_board_pnp": T_cb,
            "reproj_px": reproj,
            "marker_ids": sorted(int(i) for i in ids.reshape(-1)),
            "file": name,
        })
    nominal = _mean_pose(nominals) if nominals else None
    return obs, nominal, skipped


# ---------------------------------------------------------------------------
# Solve  (reprojection bundle adjustment)
# ---------------------------------------------------------------------------

def _board_estimates(obs, X):
    """Per-frame board pose from PnP: A @ X @ T_cam_board_pnp, in that camera's base frame."""
    return [o["A"] @ X @ o["T_cam_board_pnp"] for o in obs]


def _bounds(n_cam):
    """One board-pose block (6) + `n_cam` camera-correction blocks (6 each)."""
    lo = [-BOARD_ROT_RAD] * 3 + [-BOARD_TRANS_M] * 3
    hi = [BOARD_ROT_RAD] * 3 + [BOARD_TRANS_M] * 3
    cam_lo = [-CAM_CORR_ROT_RAD] * 3 + [-CAM_CORR_TRANS_M] * 3
    cam_hi = [CAM_CORR_ROT_RAD] * 3 + [CAM_CORR_TRANS_M] * 3
    return (np.array(lo + cam_lo * n_cam), np.array(hi + cam_hi * n_cam))


def _residual_stack(preds_and_obs):
    return np.concatenate([
        (_project(o["K"], T_cb, o["obj"]) - o["img"]).ravel()
        for T_cb, o in preds_and_obs
    ])


def solve_joint(obs_left, obs_right, X0_left, X0_right, T_RL, huber_px):
    """18 params: board pose (left base) + bounded 6-DoF correction per camera."""
    seed = _board_estimates(obs_left, X0_left) + [
        _inv(T_RL) @ T for T in _board_estimates(obs_right, X0_right)
    ]
    P0 = _mean_pose(seed)

    def residuals(theta):
        P = P0 @ _exp(theta[0:6])
        XL = X0_left @ _exp(theta[6:12])
        XR = X0_right @ _exp(theta[12:18])
        pao = [(_inv(o["A"] @ XL) @ P, o) for o in obs_left]
        pao += [(_inv(o["A"] @ XR) @ (T_RL @ P), o) for o in obs_right]
        return _residual_stack(pao)

    lo, hi = _bounds(2)
    res = least_squares(residuals, np.zeros(18), bounds=(lo, hi), loss="huber",
                        f_scale=huber_px, x_scale="jac", max_nfev=800)
    return {"X_left": X0_left @ _exp(res.x[6:12]),
            "X_right": X0_right @ _exp(res.x[12:18]),
            "P": P0 @ _exp(res.x[0:6]), "res": res}


def solve_single(obs, X0, huber_px):
    """12 params: board pose (this camera's base) + bounded 6-DoF correction."""
    P0 = _mean_pose(_board_estimates(obs, X0))

    def residuals(theta):
        P = P0 @ _exp(theta[0:6])
        X = X0 @ _exp(theta[6:12])
        return _residual_stack([(_inv(o["A"] @ X) @ P, o) for o in obs])

    lo, hi = _bounds(1)
    res = least_squares(residuals, np.zeros(12), bounds=(lo, hi), loss="huber",
                        f_scale=huber_px, x_scale="jac", max_nfev=800)
    return {"X": X0 @ _exp(res.x[6:12]), "P": P0 @ _exp(res.x[0:6]), "res": res}


def opencv_crosscheck(obs):
    """cv2.calibrateRobotWorldHandEye estimate of T_flange_cam, or None if unavailable."""
    if not hasattr(cv2, "calibrateRobotWorldHandEye") or len(obs) < 3:
        return None
    R_w2c, t_w2c, R_b2g, t_b2g = [], [], [], []
    for o in obs:
        M = o["T_cam_board_pnp"]
        R_w2c.append(M[:3, :3]); t_w2c.append(M[:3, 3])
        g = _inv(o["A"])
        R_b2g.append(g[:3, :3]); t_b2g.append(g[:3, 3])
    try:
        _, _, R_g2c, t_g2c = cv2.calibrateRobotWorldHandEye(
            R_w2c, t_w2c, R_b2g, t_b2g,
            method=cv2.CALIB_ROBOT_WORLD_HAND_EYE_SHAH)
    except Exception:
        return None
    return _inv(_pose(R_g2c, np.asarray(t_g2c).reshape(3)))


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

def _fmt_T(T):
    q = _R_to_quat_wxyz(T[:3, :3]); t = T[:3, 3]
    return (f"t=[{t[0]:+.5f} {t[1]:+.5f} {t[2]:+.5f}] m   "
            f"q_wxyz=[{q[0]:+.5f} {q[1]:+.5f} {q[2]:+.5f} {q[3]:+.5f}]")


def _fmt_pose_line(T):
    q = _R_to_quat_wxyz(T[:3, :3]); t = T[:3, 3]
    e = Rotation.from_matrix(T[:3, :3]).as_euler("xyz", degrees=True)
    return (f"pos=[{t[0]:+.4f} {t[1]:+.4f} {t[2]:+.4f}] m   "
            f"rpy=[{e[0]:+.2f} {e[1]:+.2f} {e[2]:+.2f}] deg   "
            f"q_wxyz=[{q[0]:+.4f} {q[1]:+.4f} {q[2]:+.4f} {q[3]:+.4f}]")


def report(sides, nominal, solved, T_RL, base_to_base_note, joint):
    W = 80
    print("=" * W)
    print("FLANGE->CAMERA RECALIBRATION" +
          ("  (joint two-camera reprojection bundle adjustment)" if joint
           else "  (per-camera reprojection bundle adjustment)"))
    print("=" * W)
    print(f"base-to-base transform: {base_to_base_note}")
    if joint:
        print(f"  T_baseR_baseL: {_fmt_T(T_RL)}")
    print()

    for side in sides:
        s = solved[side]
        X0, X1 = nominal[side], s["X"]
        dd = _T_delta(X0, X1)
        cv = s.get("opencv")
        markers = sorted({m for o in s["obs"] for m in o["marker_ids"]})
        print(f"[{side}]  cam_id={SIDE_CAM_ID[side]}   {s['n']} frames, "
              f"markers seen {markers}")
        print(f"  nominal      T_flange_cam : {_fmt_T(X0)}")
        print(f"  recalibrated T_flange_cam : {_fmt_T(X1)}")
        print(f"  correction                : {dd['rot_deg']:.3f} deg, {dd['trans_mm']:.2f} mm"
              + ("   [at bound -- see notes]" if s["at_bound"] else ""))
        if cv is not None:
            dcv, dcp = _T_delta(X0, cv), _T_delta(X1, cv)
            note = "" if dcp["rot_deg"] < 2 and dcp["trans_mm"] < 15 else "  <- diverges, suspect"
            print(f"  OpenCV cross-check        : {dcv['rot_deg']:.2f} deg / {dcv['trans_mm']:.1f} mm "
                  f"from nominal, {dcp['rot_deg']:.2f} deg / {dcp['trans_mm']:.1f} mm from primary{note}")
        print(f"  reprojection RMS (all corners, all frames) : "
              f"{s['reproj_before']:.2f} px  ->  {s['reproj_after']:.2f} px")
        print(f"  raw per-frame PnP scatter before           : "
              f"{s['spread_before']['pos_rms_mm']:.1f} mm / "
              f"{s['spread_before']['ang_rms_deg']:.1f} deg rms "
              f"(single-cluster PnP noise floor; BA works on pixels, not this)")
        print()

    print("-" * W)
    print("AVERAGE FIXTURE (BOARD) POSE  -- before vs after recalibration")
    print("-" * W)
    for side in sides:
        s = solved[side]
        base = "lbr_one_link_0" if side == "left" else "lbr_two_link_0"
        before = _mean_pose(_board_estimates(s["obs"], nominal[side]))
        after = s["P_in_base"]
        print(f"[{side}: {base}] before  {_fmt_pose_line(before)}")
        print(f"[{side}: {base}] after   {_fmt_pose_line(after)}   (solved; single pose)")
        print()

    if len(sides) == 2 and T_RL is not None:
        print("-" * W)
        print("FIXTURE POSE AVERAGED ACROSS BOTH CAMERAS  (in lbr_one_link_0 base)")
        print("-" * W)
        pooled_before = []
        for side in sides:
            e = _board_estimates(solved[side]["obs"], nominal[side])
            pooled_before += e if side == "left" else [_inv(T_RL) @ T for T in e]
        mb = _mean_pose(pooled_before)
        sb = _spread(pooled_before, mb)
        lb = _mean_pose(_board_estimates(solved["left"]["obs"], nominal["left"]))
        rb = _inv(T_RL) @ _mean_pose(_board_estimates(solved["right"]["obs"], nominal["right"]))
        dlr = _T_delta(lb, rb)
        print(f"before  {_fmt_pose_line(mb)}")
        print(f"        spread across all {len(pooled_before)} frames: "
              f"{sb['pos_rms_mm']:.2f} mm rms / {sb['ang_rms_deg']:.2f} deg rms")
        print(f"        left-cam mean vs right-cam mean: {dlr['trans_mm']:.2f} mm / "
              f"{dlr['rot_deg']:.2f} deg disagreement")
        after = solved["left"]["P_in_base"]
        print(f"after   {_fmt_pose_line(after)}   (single solved board pose)")
        dL = _T_delta(solved["left"]["P_in_base"], _inv(T_RL) @ solved["right"]["P_in_base"]) \
            if not joint else {"trans_mm": 0.0, "rot_deg": 0.0}
        if joint:
            print("        both cameras now share one board pose by construction "
                  "(joint solve).")
        else:
            print(f"        left vs right solved board pose: {dL['trans_mm']:.2f} mm / "
                  f"{dL['rot_deg']:.2f} deg")
        print()

    # verdict
    print("-" * W)
    worst_reproj = max(solved[s]["reproj_after"] for s in sides)
    any_bound = any(solved[s]["at_bound"] for s in sides)
    improved = all(solved[s]["reproj_after"] <= solved[s]["reproj_before"] + 0.05 for s in sides)
    if worst_reproj < 1.5 and not any_bound and improved:
        print("VERDICT: solve converged cleanly -- apply the recalibrated extrinsics.")
    elif any_bound:
        print("VERDICT: a correction hit its bound. The data wants a bigger change than a "
              "plausible\n         mount error -- likely a bad frame or too few / "
              "near-coplanar views.\n         Inspect the skip list and per-frame reproj; "
              "recapture with more tilt variety.")
    else:
        print("VERDICT: marginal. Reprojection improved but residuals remain high for these\n"
              "         small near-coplanar markers. Treat the numbers as indicative; a "
              "capture with\n         more viewpoints / marker spread would tighten them.")
    print("-" * W)

    print("RECALIBRATED T_flange_cam  (paste into camera_extrinsics_realsense.yaml)")
    print("-" * W)
    for side in sides:
        X = solved[side]["X"]
        print(f"{SIDE_CAM_ID[side]}:  # {side}")
        print("  R: [" + ", ".join(f"{v:.16g}" for v in X[:3, :3].reshape(9)) + "]")
        print("  t: [" + ", ".join(f"{v:.16g}" for v in X[:3, 3]) + "]")
    print("=" * W)


# ---------------------------------------------------------------------------
# Recalibrated YAML
# ---------------------------------------------------------------------------

def write_recalibrated_yaml(path, solved, meta):
    lines = [
        "# Recalibrated flange->camera extrinsics from tools/recalibrate_cam_flange.py.",
        "# Layout matches camera_transforms.yaml / camera_extrinsics_realsense.yaml:",
        "#   R row-major 3x3, t metres, p_flange = R @ p_cam + t  (= T_flange_cam).",
        "#",
        f"# generated    : {meta['when']}",
        f"# capture      : {meta['capture']}",
        f"# nominal from : {meta['nominal_src']}",
        f"# base-to-base : {meta['base_to_base_note']}",
        f"# solve        : {meta['mode']}",
    ]
    for side in solved:
        s = solved[side]
        lines.append(f"# {side:5s} {s['n']} frames  correction {s['delta']['rot_deg']:.3f} deg / "
                     f"{s['delta']['trans_mm']:.2f} mm  reproj {s['reproj_before']:.2f}->"
                     f"{s['reproj_after']:.2f} px")
    lines.append("")
    for side in solved:
        X = solved[side]["X"]
        lines.append(f"{side}:")
        lines.append(f"  cam_id: {SIDE_CAM_ID[side]}")
        lines.append("  R:")
        lines += [f"  - {v!r}" for v in X[:3, :3].reshape(9).tolist()]
        lines.append("  t:")
        lines += [f"  - {v!r}" for v in X[:3, 3].tolist()]
        lines.append("")
    with open(path, "w") as fp:
        fp.write("\n".join(lines))


# ---------------------------------------------------------------------------
# Synthetic capture (for --selftest / --make-selftest-fixture)
# ---------------------------------------------------------------------------

def _render_board_image(board_obj_points, board_ids, dictionary, K, T_cam_board,
                        img_wh, noise_px, rng):
    w, h = img_wh
    canvas = np.full((h, w, 3), 210, np.uint8)
    rvec = cv2.Rodrigues(T_cam_board[:3, :3])[0]
    tvec = T_cam_board[:3, 3].reshape(3, 1)
    src = np.array([[0, 0], [1, 0], [1, 1], [0, 1]], np.float32) * 240.0
    for mid, obj in zip(board_ids, board_obj_points):
        gray = cv2.aruco.generateImageMarker(dictionary, int(mid), 240)
        bgr = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        proj, _ = cv2.projectPoints(np.asarray(obj, np.float32), rvec, tvec, K, np.zeros((5, 1)))
        dst = proj.reshape(-1, 2).astype(np.float32)
        if noise_px:
            dst = dst + rng.normal(0, noise_px, dst.shape).astype(np.float32)
        if np.any(~np.isfinite(dst)) or dst.min() < -w or dst.max() > 2 * w:
            continue
        H = cv2.getPerspectiveTransform(src, dst)
        warp = cv2.warpPerspective(bgr, H, (w, h))
        mask = cv2.warpPerspective(np.full((240, 240), 255, np.uint8), H, (w, h))
        canvas[mask > 0] = warp[mask > 0]
    return canvas


def _render_plane_depth(K, T_cam_board, img_wh):
    w, h = img_wh
    us, vs = np.meshgrid(np.arange(w), np.arange(h))
    dirs = np.stack([(us - K[0, 2]) / K[0, 0], (vs - K[1, 2]) / K[1, 1], np.ones_like(us)], -1)
    n, p0 = T_cam_board[:3, 2], T_cam_board[:3, 3]
    with np.errstate(divide="ignore", invalid="ignore"):
        s = (p0 @ n) / (dirs @ n)
    z = s * dirs[..., 2]
    z[~np.isfinite(z) | (z <= 0.05) | (z > 2.0)] = 0.0
    return z.astype(np.float32)


def _look_at(cam_pos, target, up=(0.0, 0.0, 1.0)):
    z = np.asarray(target, float) - np.asarray(cam_pos, float)
    z /= np.linalg.norm(z)
    x = np.cross(np.asarray(up, float), z); x /= np.linalg.norm(x)
    return _pose(np.column_stack([x, np.cross(z, x), z]), cam_pos)


def synthesize_fixture(out_dir, nominal_pose_path, transforms_path, *, n_per_cam=10,
                       noise_px=0.2, perturb_deg=(2.5, -3.0), perturb_mm=(6.0, -7.0),
                       seed=0, write_perturbed_transforms=None):
    rng = np.random.default_rng(seed)
    board, dictionary, _ = load_board_from_nominal_pose(nominal_pose_path)
    obj_pts = board.getObjPoints()
    ids = board.getIds().reshape(-1)
    marker_centroid = np.concatenate([np.asarray(m) for m in obj_pts]).mean(axis=0)
    K = np.array([[436.31, 0, 418.63], [0, 435.65, 236.51], [0, 0, 1.0]])
    img_wh = (848, 480)

    X_gt = load_nominal_transforms(transforms_path)
    T_RL, note = load_base_to_base(nominal_pose_path, None)
    if T_RL is None:
        T_RL = _pose(np.eye(3), [0.0, -0.84, 0.0])
    data = json.load(open(nominal_pose_path))
    p_seed = np.array(data["board_origin"]["lbr_one_link_0"]["position_m"])
    q_seed = data["board_origin"]["lbr_one_link_0"]["quaternion_wxyz"]
    P_gt = _pose(_quat_wxyz_to_R(q_seed), p_seed) @ _exp(
        np.array([0.03, -0.02, 0.05, 0.008, -0.006, 0.004]))

    perturbed, info = {}, {"X_gt": X_gt, "P_gt": P_gt, "T_RL": T_RL, "note": note, "K": K}
    side_capdir = {"left": "hold_depth_capture", "right": "move_depth_capture"}
    for si, side in enumerate(("left", "right")):
        cap = os.path.join(out_dir, side_capdir[side])
        os.makedirs(cap, exist_ok=True)
        G_c = P_gt if side == "left" else T_RL @ P_gt
        axis = rng.normal(size=3); axis /= np.linalg.norm(axis)
        tax = rng.normal(size=3); tax /= np.linalg.norm(tax)
        perturbed[side] = X_gt[side] @ _exp(np.concatenate(
            [np.radians(perturb_deg[si]) * axis, 1e-3 * perturb_mm[si] * tax]))
        board_c = (G_c @ np.append(marker_centroid, 1.0))[:3]
        for i in range(n_per_cam):
            off = np.array([rng.uniform(-0.06, 0.06), rng.uniform(-0.06, 0.06),
                            rng.uniform(0.25, 0.33)])
            up = np.array([rng.uniform(-0.25, 0.25), 1.0, rng.uniform(-0.25, 0.25)])
            T_base_cam = _look_at(board_c + off, board_c, up) @ _exp(np.array(
                [rng.uniform(-0.07, 0.07), rng.uniform(-0.07, 0.07), rng.uniform(-0.5, 0.5),
                 0, 0, 0]))
            T_cam_board = _inv(T_base_cam) @ G_c
            A = T_base_cam @ _inv(X_gt[side])
            img = _render_board_image(obj_pts, ids, dictionary, K, T_cam_board, img_wh,
                                      noise_px, rng)
            cv2.imwrite(os.path.join(cap, f"color_{i:03d}.png"), img)
            np.savez_compressed(
                os.path.join(cap, f"frame_{i:03d}.npz"),
                depth_m=_render_plane_depth(K, T_cam_board, img_wh),
                encoding="32FC1", K_depth=K, T_base_flange=A, T_flange_cam=perturbed[side],
                T_base_cam=A @ perturbed[side], T_base_board=G_c, vp_index=i, dt_sync=0.0,
                arm=("hold" if side == "left" else "move"))
        json.dump({"arm": "hold" if side == "left" else "move", "n_frames": n_per_cam},
                  open(os.path.join(cap, "manifest.json"), "w"))
    info["perturbed"] = perturbed
    if write_perturbed_transforms:
        write_recalibrated_yaml(
            write_perturbed_transforms,
            {s: {"X": perturbed[s], "n": 0, "delta": _T_delta(X_gt[s], perturbed[s]),
                 "reproj_before": 0.0, "reproj_after": 0.0} for s in ("left", "right")},
            {"when": "synthetic", "capture": out_dir, "nominal_src": transforms_path,
             "base_to_base_note": note, "mode": "synthetic perturbed nominal"})
    return info


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------

def run(fixture_dir, *, nominal_pose, transforms_path, intrinsics_yaml, out_yaml,
        base_to_base, huber_px, max_reproj_px, min_corners, joint, quiet=False):
    board, dictionary, _ = load_board_from_nominal_pose(nominal_pose)
    yaml_nominal = None
    if transforms_path and os.path.exists(transforms_path):
        try:
            yaml_nominal = load_nominal_transforms(transforms_path)
        except Exception as exc:
            if not quiet:
                print(f"[warn] could not read {transforms_path}: {exc}")

    idata = _load_yaml(intrinsics_yaml) if intrinsics_yaml and os.path.exists(intrinsics_yaml) else {}
    dirs = {"left": _find_side_dir(fixture_dir, LEFT_SUBDIRS),
            "right": _find_side_dir(fixture_dir, RIGHT_SUBDIRS)}
    sides = [s for s in ("left", "right") if dirs[s]]
    if not sides:
        raise SystemExit(f"no capture dirs under {fixture_dir} "
                         f"(looked for {LEFT_SUBDIRS + RIGHT_SUBDIRS})")

    obs, nominal = {}, {}
    for s in sides:
        e = idata.get(SIDE_CAM_ID[s])
        fb = np.array(e["K"], float).reshape(3, 3) if e and "K" in e else None
        o, npz_nominal, skipped = load_observations(dirs[s], board, dictionary, fb,
                                                    max_reproj_px, min_corners)
        if not quiet:
            print(f"[{s}] {dirs[s]}: {len(o)} usable frames, {len(skipped)} skipped")
            for name, why in skipped:
                print(f"      skip {name}: {why}")
        if len(o) < 3:
            raise SystemExit(f"[{s}] need >=3 usable frames, got {len(o)}")
        obs[s] = o
        # nominal T_flange_cam: prefer what the capture actually used; fall back to the YAML.
        if npz_nominal is not None:
            nominal[s] = npz_nominal
            src = "frame_*.npz (T_flange_cam in use at capture)"
            if yaml_nominal is not None:
                dd = _T_delta(npz_nominal, yaml_nominal[s])
                if not quiet and (dd["rot_deg"] > 0.5 or dd["trans_mm"] > 2.0):
                    print(f"      note: {os.path.basename(transforms_path)} '{s}' differs from the "
                          f"captured nominal by {dd['rot_deg']:.2f} deg / {dd['trans_mm']:.2f} mm "
                          f"-- using the captured one")
        elif yaml_nominal is not None:
            nominal[s] = yaml_nominal[s]
            src = os.path.basename(transforms_path)
        else:
            raise SystemExit(f"[{s}] no nominal T_flange_cam: frames lack it and "
                             f"{transforms_path} is unusable")

    T_RL, note = load_base_to_base(nominal_pose, base_to_base)
    use_joint = joint and len(sides) == 2 and T_RL is not None
    if joint and not use_joint and not quiet:
        print(f"[warn] joint solve unavailable ({note}; sides={sides}); per-camera solve")

    if use_joint:
        j = solve_joint(obs["left"], obs["right"], nominal["left"], nominal["right"],
                        T_RL, huber_px)
        Xs = {"left": j["X_left"], "right": j["X_right"]}
        P_in_base = {"left": j["P"], "right": T_RL @ j["P"]}
    else:
        Xs, P_in_base = {}, {}
        for s in sides:
            r = solve_single(obs[s], nominal[s], huber_px)
            Xs[s], P_in_base[s] = r["X"], r["P"]

    solved = {}
    for s in sides:
        d = _T_delta(nominal[s], Xs[s])
        at_bound = (d["rot_deg"] > np.degrees(CAM_CORR_ROT_RAD) - 0.1 or
                    d["trans_mm"] > CAM_CORR_TRANS_M * 1e3 - 0.5)
        solved[s] = {
            "X": Xs[s], "obs": obs[s], "n": len(obs[s]), "delta": d, "at_bound": at_bound,
            "P_in_base": P_in_base[s],
            "opencv": opencv_crosscheck(obs[s]),
            "reproj_before": _reproj_rms_px(obs[s], nominal[s],
                                            _mean_pose(_board_estimates(obs[s], nominal[s]))),
            "reproj_after": _reproj_rms_px(obs[s], Xs[s], P_in_base[s]),
            "spread_before": _spread(_board_estimates(obs[s], nominal[s]),
                                     _mean_pose(_board_estimates(obs[s], nominal[s]))),
        }

    if not quiet:
        report(sides, nominal, solved, T_RL, note, use_joint)

    meta = {"when": time.strftime("%Y-%m-%d %H:%M:%S"), "capture": fixture_dir,
            "nominal_src": "frame_*.npz" + ("" if yaml_nominal is None else " (yaml matched/overridden)"),
            "base_to_base_note": note, "mode": "joint two-camera BA" if use_joint else "per-camera BA"}
    write_recalibrated_yaml(out_yaml, {s: solved[s] for s in sides}, meta)
    if not quiet:
        print(f"wrote {out_yaml}")
    return {"nominal": nominal, "solved": solved, "sides": sides, "joint": use_joint}


def _find_selftest_nominal_pose():
    home = os.path.expanduser("~")
    cands = [os.path.join(LOGS_ROOT, "plumbers_block_new_3/fixture/nominal_world_pose.json")]
    cands += sorted(glob.glob(os.path.join(home, "Fabrica-pdz/logs/*/*/fixture/nominal_world_pose.json")))
    for c in cands:
        if os.path.exists(c):
            try:
                if "opencv" in json.load(open(c)):
                    return c
            except Exception:
                pass
    return None


def _selftest():
    import tempfile
    nominal_pose = _find_selftest_nominal_pose()
    if nominal_pose is None:
        raise SystemExit("selftest needs an ArUco nominal_world_pose.json (with an 'opencv' "
                         "block) under ~/Fabrica-pdz/logs/.../fixture/; none found.")
    print(f"selftest board geometry: {nominal_pose}")
    with tempfile.TemporaryDirectory() as td:
        info = synthesize_fixture(td, nominal_pose, DEFAULT_TRANSFORMS, seed=1,
                                  write_perturbed_transforms=os.path.join(td, "nominal.yaml"))
        out = run(td, nominal_pose=nominal_pose,
                  transforms_path=os.path.join(td, "nominal.yaml"),
                  intrinsics_yaml=DEFAULT_INTRINSICS, out_yaml=os.path.join(td, "recal.yaml"),
                  base_to_base=None, huber_px=1.0, max_reproj_px=3.0, min_corners=8, joint=True)
        print("\n--- SELFTEST CHECKS (recovered vs ground-truth extrinsic) ---")
        ok = True
        for s in out["sides"]:
            d = _T_delta(out["solved"][s]["X"], info["X_gt"][s])
            d0 = _T_delta(info["perturbed"][s], info["X_gt"][s])
            print(f"[{s}] nominal was {d0['rot_deg']:.3f} deg / {d0['trans_mm']:.2f} mm off GT; "
                  f"after recal {d['rot_deg']:.3f} deg / {d['trans_mm']:.2f} mm off GT")
            if d["rot_deg"] > 1.2 or d["trans_mm"] > 6.0:
                ok = False
        print("SELFTEST:", "PASS" if ok else "FAIL")
        if not ok:
            raise SystemExit(1)


def _resolve_fixture_dir(args):
    if args.fixture_dir:
        return args.fixture_dir
    if args.plan:
        cand = os.path.join(LOGS_ROOT, args.plan, "fixture")
        if not os.path.isdir(cand):
            raise SystemExit(f"--plan {args.plan}: no fixture dir at {cand}")
        return cand
    return None


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--fixture-dir", help="dir with {hold,move}_depth_capture/ + "
                                          "nominal_world_pose.json")
    ap.add_argument("--plan", help=f"shortcut for --fixture-dir {LOGS_ROOT}/<plan>/fixture")
    ap.add_argument("--nominal-pose", default=None,
                    help="nominal_world_pose.json (default: <fixture>/nominal_world_pose.json)")
    ap.add_argument("--camera-transforms", default=DEFAULT_TRANSFORMS,
                    help="nominal flange->camera YAML; only a fallback/cross-check -- the "
                         "nominal is read from the capture frames when present")
    ap.add_argument("--intrinsics-yaml", default=DEFAULT_INTRINSICS,
                    help="fallback colour intrinsics if a frame lacks K_depth")
    ap.add_argument("--out", default=None,
                    help="recalibrated YAML (default: <camera-transforms dir>/"
                         "camera_transforms_recalibrated.yaml)")
    ap.add_argument("--base-to-base", default=None,
                    help='override T_baseR_baseL: "dx,dy,dz" translation, or "single"')
    ap.add_argument("--huber-px", type=float, default=1.0,
                    help="Huber loss scale on corner reprojection residuals (px)")
    ap.add_argument("--max-reproj-px", type=float, default=3.0,
                    help="drop a frame whose PnP board solve reprojects worse than this")
    ap.add_argument("--min-corners", type=int, default=4,
                    help="min matched ArUco corners to keep a frame (4 = one marker)")
    ap.add_argument("--no-joint", action="store_true",
                    help="solve each camera independently (no shared board pose)")
    ap.add_argument("--selftest", action="store_true",
                    help="synthesise a capture with known truth, recalibrate, and check")
    ap.add_argument("--make-selftest-fixture", metavar="DIR", default=None,
                    help="write a synthetic capture set to DIR and exit")
    args = ap.parse_args()

    if args.selftest:
        _selftest()
        return
    if args.make_selftest_fixture:
        if not args.nominal_pose:
            raise SystemExit("--make-selftest-fixture needs --nominal-pose <nominal_world_pose.json>")
        info = synthesize_fixture(args.make_selftest_fixture, args.nominal_pose,
                                  args.camera_transforms, seed=1,
                                  write_perturbed_transforms=os.path.join(
                                      args.make_selftest_fixture, "camera_transforms_nominal.yaml"))
        print(f"wrote synthetic capture to {args.make_selftest_fixture}")
        for s in ("left", "right"):
            d = _T_delta(info["X_gt"][s], info["perturbed"][s])
            print(f"  {s}: injected {d['rot_deg']:.2f} deg / {d['trans_mm']:.2f} mm error vs GT")
        return

    fixture_dir = _resolve_fixture_dir(args)
    if not fixture_dir:
        ap.error("give --fixture-dir or --plan (or use --selftest / --make-selftest-fixture)")
    nominal_pose = args.nominal_pose or os.path.join(fixture_dir, "nominal_world_pose.json")
    if not os.path.exists(nominal_pose):
        ap.error(f"nominal_world_pose.json not found at {nominal_pose}; pass --nominal-pose")
    out_yaml = args.out or os.path.join(os.path.dirname(os.path.abspath(args.camera_transforms)),
                                        "camera_transforms_recalibrated.yaml")
    run(fixture_dir, nominal_pose=nominal_pose, transforms_path=args.camera_transforms,
        intrinsics_yaml=args.intrinsics_yaml, out_yaml=out_yaml, base_to_base=args.base_to_base,
        huber_px=args.huber_px, max_reproj_px=args.max_reproj_px, min_corners=args.min_corners,
        joint=not args.no_joint)


if __name__ == "__main__":
    main()
