# Marker Z audit + wrist-camera recalibration — findings (2026-09-07)

Context: verify the ArUco marker plane is at **z = −0.020 m** in the arm-base frames
(table surface at −0.025 m, printed board 5 mm thick), fix it in the Fabrica-pdz
fixture generation if wrong, then re-run `tools/recalibrate_cam_flange.py` and record the
before/after. Capture used throughout:
`~/Fabrica-pdz/logs/kuka_pdz8_cm_aruco/plumbers_block_new_3/fixture/` (7 `hold` + 7 `move`
frames).

---

## 1. Marker Z audit — already correct, nothing overwritten

Every artifact in the chain already places the marker plane at exactly **−0.020 m** in both
`lbr_one_link_0` and `lbr_two_link_0`. No file was edited; no pose was overwritten.

| quantity | value | source |
|---|---|---|
| table / slab-bottom (`board_origin`) | −0.025 m in `lbr_one_link_0` & `lbr_two_link_0` | `plumbers_block_new_3/fixture/nominal_world_pose.json` → `board_origin` |
| slab thickness | 5 mm (`BOTTOM_THICKNESS = 0.5` cm) | `Fabrica-pdz/planning/run_fixture_gen.py:30` |
| marker plane | **−0.020 m** in both arm-base frames (−0.025 + 0.005) | `nominal_world_pose.json` → `markers[0..5].{lbr_one_link_0,lbr_two_link_0}.position_m[2]` |
| marker plane, world frame | +0.005 m | same file, `markers[*].world` |
| marker plane, fixture-native frame | +0.005 m (`plane_z_cm: 0.5`, `board_obj_points_m` z = 0.005) | `fixture/markers.json` |

### Why the generation is already consistent (no code change needed)

1. `planning/utils/fixture_markers.py::add_aruco_markers_to_fixture` is called with
   `slab_top_z = BOTTOM_THICKNESS = 0.5` cm and writes every marker corner /
   `T_fixture_marker_m` / `plane_z_cm` at that height in the **fixture-native** frame
   (origin = slab bottom). → marker plane 5 mm above the fixture origin.
2. `planning/utils/fixture_world_frame.py::board_to_arm_base_transform` maps the
   fixture-native frame into each arm base with a **−`KUKA_BASE_Z` = −2.5 cm** Z offset
   (`planning/robot/workcell.py:9` — "arms sit on 2.5 cm steel blocks, not on the table").
   → fixture origin (slab bottom) lands at −0.025 m, marker plane at −0.020 m.
3. `planning/tools/export_fixture_nominal_pose.py` composes (1)×(2) and writes
   `nominal_world_pose.json` with the markers already at −0.02 m.

Cross-checked `cooling_manifold_aruco_2/fixture/markers.json` — same `plane_z_cm: 0.5`,
`board_obj_points_m` z = 0.005. Consistent.

### What was NOT changed

`markers.json`, `nominal_world_pose.json`, `fixture.obj`, `pickup.json`, every motion plan,
and all of Fabrica-pdz's generation code — left untouched, because the geometry is already
what was requested.

> If the intent was instead to move the fixture-native frame **origin** onto the marker
> plane (markers at z = 0, board origin at −0.02), that is a different change: it shifts
> `fixture.obj` vertices and `pickup.json`, i.e. the fixtures and motion plans. Out of scope
> here — raise separately.

---

## 2. Recalibration re-run — before vs after

`python3 tools/recalibrate_cam_flange.py --plan plumbers_block_new_3 --out tools/recalibrated_extrinsics.yaml`
— joint two-camera reprojection bundle adjustment, 7 + 7 frames, all markers 0–5 seen by
both arms, 0 frames skipped. `T_baseR_baseL` from `board_origin`: t = [0, −0.84, 0] m,
identity rotation.

### Camera hand-eye `T_flange_cam`

| camera | translation t [m] | quat wxyz | Δ vs nominal | reproj RMS (all corners) |
|---|---|---|---|---|
| **left** (`realsense_1`, hold) nominal | [−0.04917, +0.00021, +0.06151] | [+0.68070, +0.19444, +0.17238, +0.68493] | — | 1.89 px |
| **left** recalibrated | [−0.05031, −0.00888, +0.06366] | [+0.68147, +0.18366, +0.18446, +0.68399] | **1.86°, 9.41 mm** | **1.04 px** |
| **right** (`realsense_2`, move) nominal | [−0.05433, −0.00768, +0.06636] | [+0.68542, +0.19462, +0.18661, +0.67638] | — | 3.47 px |
| **right** recalibrated | [−0.04578, −0.01129, +0.06148] | [+0.68388, +0.18232, +0.18565, +0.68161] | **1.55°, 10.49 mm** | **1.01 px** |

Both corrections are well within the ±8° / ±30 mm plausible-mount-error bound. OpenCV
`calibrateRobotWorldHandEye` cross-check agreed within tolerance.

### Fixture / board pose (fixture-native origin)

| frame | before (mean of per-frame PnP, nominal extrinsics) | after (single solved pose) |
|---|---|---|
| left `lbr_one_link_0` | pos [+0.0985, +0.4315, **−0.0462**] m  rpy [−2.95, +0.05, +89.88]° | pos [+0.0963, +0.4283, **−0.0239**] m  rpy [−0.13, −0.22, +90.59]° |
| right `lbr_two_link_0` | pos [+0.0986, −0.4186, **−0.0105**] m  rpy [+0.88, +3.32, +91.09]° | pos [+0.0963, −0.4117, **−0.0239**] m  rpy [−0.13, −0.22, +90.59]° |
| both cams, in `lbr_one_link_0` | pos [+0.0986, +0.4265, −0.0283] m; spread 24.0 mm / 5.4° rms; **left-vs-right disagreement 37.2 mm / 5.15°** | pos [+0.0963, +0.4283, −0.0239] m — one shared pose by construction |

Design `board_origin` (lbr_one) = [0.1, 0.42, −0.025] m.

- **Before:** nominal hand-eye put the fixture ~21 mm low on the left, ~15 mm high on the
  right, the two cameras 37 mm / 5° apart on where the plate is.
- **After:** single pose **4.6 mm / ~0.6° from the design origin** (z −0.0239 vs −0.025).
  Recovered marker plane = −0.0239 + 0.005 = **−0.0189 m**, i.e. 1.1 mm above the −0.020
  design target — inside the BA residual, not a geometry error.

VERDICT (tool): converged cleanly — apply the recalibrated extrinsics.

Result is numerically identical to the prior `tools/camera_transforms_recalibrated.yaml`
(2026-09-07 07:43) because no input changed — the marker Z was already −0.02.

### Output

`tools/recalibrated_extrinsics.yaml` — same layout as `camera_transforms.yaml` /
`camera_extrinsics_realsense.yaml` (`left:`/`right:` with `R` row-major 9, `t` metres,
`p_flange = R @ p_cam + t`). Paste `R`/`t` into
`~/Masterthesis-vision/config/camera_extrinsics_realsense.yaml` under `realsense_1` /
`realsense_2` to apply on the rig (nominal file never edited in place).

---

## 3. Point-cloud visualizer — before/after switch

`tools/build_scan_cloud.py` can now rebuild every cloud from an extrinsics file instead of
the `T_base_cam` baked into each capture `.npz`:

- `tools/build_scan_cloud.yaml` → new `extrinsics:` block, `enabled: true`,
  `file: recalibrated_extrinsics.yaml` (path resolved relative to the YAML's dir).
- `tools/build_scan_cloud.py` → when enabled, each frame's
  `T_base_cam = T_base_flange @ T_flange_cam` from that file; new `--extrinsics FILE` and
  `--no-extrinsics` CLI flags; `*_pointcloud_meta.json` records `extrinsics_source` and
  `n_frames_extrinsics_overridden`.

```bash
python3 tools/build_scan_cloud.py --fixture-dir <fixture> --view                 # recalibrated (default)
python3 tools/build_scan_cloud.py --fixture-dir <fixture> --view --no-extrinsics # as-captured nominal
python3 tools/build_scan_cloud.py --fixture-dir <fixture> --view --extrinsics tools/camera_transforms_recalibrated.yaml
```

Both paths verified to run and produce distinct clouds on `plumbers_block_new_3`. Independent
check still to do on a machine with a display: in the recalibrated combined cloud the two
board halves should collapse onto one plane, and the RealSense depth of the real slab surface
should sit on the solved marker plane (the check the BA itself cannot make).

---

## Files touched

- `tools/build_scan_cloud.yaml` — added `extrinsics:` block.
- `tools/build_scan_cloud.py` — `load_flange_cam_extrinsics()`, per-arm override in
  `build_arm_cloud()`, `--extrinsics` / `--no-extrinsics`, meta fields.
- `tools/recalibrated_extrinsics.yaml` — new (recalibration output).
- `tools/RECALIBRATE_QUICKSTART.md` — documented the before/after view.
- `TODO.md` — logged the stale `test_build_scan_cloud_smoke.py`.
