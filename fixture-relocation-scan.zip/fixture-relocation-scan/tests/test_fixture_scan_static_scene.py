#!/usr/bin/env python3
"""Vendored static-scene YAML sanity + drift check (no ROS).

    conda activate fabrica-kuka-pdz8
    python3 ~/fixture-relocation-scan/tests/test_fixture_scan_static_scene.py

`fixture_scan/scene_publisher.py::publish_static_scene` pushes `table` + `mock_box` from
`config.STATIC_SCENE_OBJECTS_YAML` (a copy of the bringup file vendored into this package so
the container has it). This checks the copy parses, has the two boxes, and -- when the
upstream file is present on this host -- still matches it.
"""

import os
import sys

import yaml

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fixture_scan import config, robot_defs

_UPSTREAM = os.path.expanduser(
    "~/franka_ros2_ws/src/lbr_fri_ros2_stack/lbr_demos/lbr_dual_arm/"
    "lbr_dual_arm_bringup/config/mock_scene_objects.yaml"
)


def _load(path):
    with open(path, "r") as fp:
        return yaml.safe_load(fp)


def test_vendored_yaml_parses_and_has_the_two_boxes():
    path = config.STATIC_SCENE_OBJECTS_YAML
    assert os.path.isfile(path), f"STATIC_SCENE_OBJECTS_YAML missing: {path}"
    spec = _load(path)

    assert spec["frame_id"] == robot_defs.PLANNING_FRAME == "base_link"
    ids = [o["id"] for o in spec["objects"]]
    assert ids == ["table", "mock_box"], ids
    for o in spec["objects"]:
        assert len(o["size_m"]) == 3 and all(v > 0 for v in o["size_m"]), o
        assert len(o["position_m"]) == 3, o
        assert len(o.get("rpy_rad", [0, 0, 0])) == 3, o
    print(f"  vendored static scene: frame_id={spec['frame_id']} objects={ids}")


def test_vendored_yaml_matches_upstream_when_present():
    if not os.path.isfile(_UPSTREAM):
        print(f"  upstream {_UPSTREAM} absent (container / non-franka host) -- skipped")
        return
    ours = _load(config.STATIC_SCENE_OBJECTS_YAML)
    theirs = _load(_UPSTREAM)
    assert ours == theirs, (
        "vendored fixture_scan/mock_scene_objects.yaml has drifted from the bringup copy "
        f"-- re-sync from {_UPSTREAM}\n  ours={ours}\n  theirs={theirs}")
    print("  vendored static scene == lbr_dual_arm_bringup/config/mock_scene_objects.yaml")


def _run():
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        print(f"- {t.__name__}")
        t()
    print(f"\nALL {len(tests)} static-scene checks passed.")


if __name__ == "__main__":
    _run()
