#!/usr/bin/env python3
"""End-to-end smoke test for tools/build_scan_cloud.py: synthesize a 2-frame capture dir
(same fronto-parallel plane seen from two flange poses) and check build_arm_cloud + the
PLY writer produce a sane merged cloud in the arm base frame. No ROS, no hardware.

    conda activate fabrica-kuka-pdz8
    python3 ~/fixture-relocation-scan/tests/test_build_scan_cloud_smoke.py
"""

import argparse
import json
import os
import sys
import tempfile

import numpy as np

_PROJ = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(_PROJ, "tools"))

import build_scan_cloud as bsc

K = np.array([[400.0, 0.0, 160.0], [0.0, 400.0, 120.0], [0.0, 0.0, 1.0]])
W, H = 320, 240


def _plane_depth(z0=0.45):
    return np.full((H, W), z0, dtype=np.float32)


def _args(**over):
    d = dict(z_min=0.05, z_max=1.2, uniform_k=5, median_blur=0, voxel_m=0.003,
             roi=False, roi_half_xy=0.40, roi_z=(-0.05, 0.50),
             sor=False, sor_neighbors=20, sor_std=2.0, no_color=True)
    d.update(over)
    return argparse.Namespace(**d)


def _write_frame(cap_dir, idx, T_base_flange, T_flange_cam, T_base_board):
    depth = _plane_depth()
    np.savez_compressed(
        os.path.join(cap_dir, f"frame_{idx:03d}.npz"),
        depth_raw=(depth * 1000).astype(np.uint16), depth_m=depth, encoding="16UC1",
        K_depth=K, T_base_flange=T_base_flange, T_flange_cam=T_flange_cam,
        T_base_cam=T_base_flange @ T_flange_cam, T_base_board=T_base_board,
        stamp_depth=1.0, stamp_flange=1.01, dt_sync=0.01, vp_index=idx, marker_id=7,
        arm="hold", n_stacked=1)


def test_two_frame_merge():
    with tempfile.TemporaryDirectory() as td:
        cap = os.path.join(td, "hold_depth_capture")
        os.makedirs(cap)
        T_fc = np.eye(4)                                   # camera == flange
        T_bf0 = np.eye(4)
        T_bf1 = np.eye(4); T_bf1[0, 3] = 0.02              # 2 cm base-x shift
        T_board = np.eye(4); T_board[:3, 3] = [0.0, 0.0, 0.40]
        _write_frame(cap, 0, T_bf0, T_fc, T_board)
        _write_frame(cap, 1, T_bf1, T_fc, T_board)
        with open(os.path.join(cap, "manifest.json"), "w") as fp:
            json.dump({"arm": "hold", "n_frames": 2}, fp)

        pts, cols, meta = bsc.build_arm_cloud(cap, _args())

        assert cols is None
        assert meta["n_frames"] == 2
        # 320x240 valid px, uniform_k=5 -> ~15360/frame, 2 frames
        assert meta["n_points_pre_voxel"] > 2000
        assert meta["n_points_after_voxel"] < meta["n_points_pre_voxel"], "voxel merge must shrink"
        assert len(pts) == meta["n_points_final"] > 0
        # every point sits on the plane z==0.45 in the base frame (both cams identity-ish)
        assert np.abs(pts[:, 2] - 0.45).max() < 1e-3, np.abs(pts[:, 2] - 0.45).max()

        out_ply = os.path.join(td, "hold_pointcloud.ply")
        bsc.write_ply(out_ply, pts, cols)
        assert os.path.getsize(out_ply) > 0
        head = open(out_ply, "rb").read(120).decode("ascii", "replace")
        assert f"element vertex {len(pts)}" in head
        print(f"  2 frames -> {meta['n_points_pre_voxel']} pre-voxel -> "
              f"{meta['n_points_after_voxel']} voxels -> {meta['n_points_final']} final; "
              f"PLY {os.path.getsize(out_ply)} B  OK")


def test_opt_in_roi_and_sor_run():
    with tempfile.TemporaryDirectory() as td:
        cap = os.path.join(td, "move_depth_capture")
        os.makedirs(cap)
        I = np.eye(4)
        board = np.eye(4); board[:3, 3] = [0, 0, 0.40]
        _write_frame(cap, 0, I, I, board)
        with open(os.path.join(cap, "manifest.json"), "w") as fp:
            json.dump({"arm": "move"}, fp)
        n_default = bsc.build_arm_cloud(cap, _args(voxel_m=0.0))[2]["n_points_pre_voxel"]
        n_roi = bsc.build_arm_cloud(cap, _args(voxel_m=0.0, roi=True))[2]["n_points_pre_voxel"]
        _, _, m_sor = bsc.build_arm_cloud(cap, _args(sor=True))
        assert n_roi <= n_default
        assert m_sor["params"]["sor"] is not None and m_sor["n_points_final"] > 0
        print(f"  default {n_default} pre-voxel; --roi {n_roi} (<=); --sor final "
              f"{m_sor['n_points_final']}  OK")


def main():
    for fn in (test_two_frame_merge, test_opt_in_roi_and_sor_run):
        print(fn.__name__)
        fn()
    print("all build_scan_cloud smoke checks passed")


if __name__ == "__main__":
    main()
