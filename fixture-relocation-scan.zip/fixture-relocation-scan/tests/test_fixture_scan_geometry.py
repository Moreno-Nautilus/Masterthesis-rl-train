#!/usr/bin/env python3
"""Phase 1 (geometry front-end) checks for fixture_scan -- no ROS, no robot.

Runs the sample -> visibility -> workspace -> score funnel on the real
`plumbers_block_new_3` nominal inputs and asserts the counts are sane, plus unit checks
on sampling determinism, the pinhole projection, marker-corner geometry and the
orientation roll optimiser.

    conda activate fabrica-kuka-pdz8
    python3 ~/fixture-relocation-scan/tests/test_fixture_scan_geometry.py
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fixture_scan import config, robot_defs
from fixture_scan.geometry import invert_T, look_rotation, make_T, rotation_geodesic_rad
from fixture_scan import inputs as fs_inputs
from fixture_scan.marker_visibility import evaluate_marker
from fixture_scan.orientation import optimize_orientation
from fixture_scan.pipeline import run_geometry_frontend
from fixture_scan.sampling import fibonacci_hemisphere, sample_candidates
from fixture_scan.workspace_filter import tcp_base_distance

NOMINAL = config.DEFAULT_NOMINAL_POSE
INTR = config.DEFAULT_INTRINSICS_YAML
EXTR = config.DEFAULT_EXTRINSICS_YAML


def test_sampling_deterministic_and_upper_hemisphere():
    a = sample_candidates(np.array([0.5, 0.4, 0.0]))
    b = sample_candidates(np.array([0.5, 0.4, 0.0]))
    assert len(a) == config.N_SAMPLES
    assert all(np.allclose(x.camera_position, y.camera_position) for x, y in zip(a, b)), \
        "sampling must be deterministic from RNG_SEED"
    dirs = np.array([c.viewing_direction for c in a])
    elev = np.degrees(np.arcsin(np.clip(dirs[:, 2], -1, 1)))
    assert elev.min() >= config.MIN_ELEVATION_DEG - 1e-6
    assert elev.max() <= config.MAX_ELEVATION_DEG + 1e-6
    radii = np.array([c.radius_m for c in a])
    assert radii.min() >= config.RADIUS_MIN_M - 1e-9
    assert radii.max() <= config.RADIUS_MAX_M + 1e-9
    # equal-area lattice: no clustering -> nearest-neighbour angular spread is tight
    assert np.std(np.linalg.norm(np.diff(np.sort(dirs[:, 2]), 1), ord=1)) < 1.0
    print(f"  sampling: {len(a)} pts, elevation [{elev.min():.1f}, {elev.max():.1f}] deg, "
          f"radius [{radii.min():.3f}, {radii.max():.3f}] m  OK")


def test_fibonacci_unit_norm():
    d = fibonacci_hemisphere(200, 10.0, 80.0)
    assert np.allclose(np.linalg.norm(d, axis=1), 1.0, atol=1e-9)
    print("  fibonacci_hemisphere: all unit-norm  OK")


def test_marker_corners_match_file_positions():
    """Corners transformed from opencv.board_obj_points_m must recentre on the per-marker
    positions the JSON lists in the arm base frame, SHIFTED into the planning frame
    (base_link) by the fixed base_link<-lbr_one_link_0 offset (impl-plan §4 cross-check)."""
    import json
    nominal = json.load(open(NOMINAL))
    fx = fs_inputs.load_fixture(NOMINAL, "hold")
    off = robot_defs.arm_base_origin_in_planning("hold")   # base_link <- lbr_one_link_0
    by_id = {m["id"]: np.array(m["lbr_one_link_0"]["position_m"]) + off
             for m in nominal["markers"]}
    for m in fx.markers:
        expected = by_id[m.id]
        err = np.linalg.norm(m.center_base - expected)
        assert err < 1e-3, f"marker {m.id} centre off by {err*1e3:.2f} mm"
        # marker edge lengths == size_m
        edges = np.linalg.norm(np.roll(m.corners_base, -1, 0) - m.corners_base, axis=1)
        assert np.allclose(edges, m.size_m, atol=1e-4), f"marker {m.id} not square"
    assert np.allclose(fx.markers[0].normal_base, [0, 0, 1], atol=1e-6), \
        "board Rz(90) -> marker normal should be base +Z"
    print(f"  marker geometry: {len(fx.markers)} markers, centres match file to <1 mm  OK")


def test_pinhole_projection_principal_point():
    intr = fs_inputs.load_intrinsics(INTR, "realsense_1")
    uv = intr.project(np.array([0.0, 0.0, 1.0]))
    assert np.allclose(uv, [intr.cx, intr.cy], atol=1e-6), "on-axis point -> principal point"
    uv2 = intr.project(np.array([0.0, 0.0, -1.0]))
    assert np.all(np.isnan(uv2)), "point behind camera must not project"
    # a point one focal-length right at z=1 lands fx px right of cx
    uv3 = intr.project(np.array([1.0, 0.0, 1.0]))
    assert abs(uv3[0] - (intr.cx + intr.fx)) < 1e-6
    print(f"  pinhole: {intr.width}x{intr.height}, principal point + behind-camera  OK")


def test_orientation_puts_axis_on_ray_and_minimises_roll():
    fx = fs_inputs.load_fixture(NOMINAL, "hold")
    intr = fs_inputs.load_intrinsics(INTR, "realsense_1")
    c_F = fx.fixture_center_base
    cam_pos = c_F + np.array([0.0, 0.0, 0.25])   # straight above the fixture centre
    # reference orientation = looking straight down with a known roll
    R_ref = look_rotation([0, 0, -1], up_hint=(1, 0, 0))
    got = optimize_orientation(cam_pos, fx.markers, intr, R_cam_current=R_ref, cfg=config)
    assert got is not None, "a marker should be visible from 0.25 m straight above"
    marker_id, R, metrics = got
    # optical axis (col 2) points from camera toward the chosen marker
    m = next(mm for mm in fx.markers if mm.id == marker_id)
    ray = (m.center_base - cam_pos)
    ray /= np.linalg.norm(ray)
    assert np.dot(R[:, 2], ray) > np.cos(np.radians(config.MAX_MARKER_RAY_ANGLE_DEG))
    assert metrics["ray_angle_deg"] < 1.0, "axis should sit on the ray"
    assert metrics["rotation_from_current_deg"] < 90.0
    print(f"  orientation: marker {marker_id}, ray_angle {metrics['ray_angle_deg']:.2f} deg, "
          f"rot-from-ref {metrics['rotation_from_current_deg']:.1f} deg  OK")


def test_geometry_funnel_on_nominal_inputs():
    res = run_geometry_frontend("hold", NOMINAL, INTR, EXTR)
    s = res["stats"]
    survivors = res["survivors"]
    print(f"  funnel[hold]: sampled={s['sampled']} "
          f"rej_visibility={s['rejected_visibility']} rej_workspace={s['rejected_workspace']} "
          f"survivors={len(survivors)}")
    assert s["sampled"] == config.N_SAMPLES
    assert 5 <= len(survivors) <= s["sampled"], \
        f"expected a non-trivial survivor set, got {len(survivors)}"
    # survivors sorted by descending S, all with a marker + TCP pose + finite scores
    S = [c.total_score for c in survivors]
    assert S == sorted(S, reverse=True)
    for c in survivors:
        assert c.selected_marker_id is not None
        assert c.T_base_tcp is not None
        # base-distance is measured from the arm's own link_0 origin, not the base_link
        # (planning-frame) origin the pose is now expressed in.
        assert tcp_base_distance(c.T_base_tcp, "hold") <= config.MAX_TCP_BASE_DIST_M + 1e-9
        assert 0.0 <= c.marker_quality <= 1.0 and 0.0 <= c.fov_margin <= 1.0
    top = survivors[0]
    print(f"  top viewpoint: {top.debug_dict()}")
    # both arms run
    res_m = run_geometry_frontend("move", NOMINAL, INTR, EXTR)
    assert len(res_m["survivors"]) >= 5
    print(f"  funnel[move]: survivors={len(res_m['survivors'])}  OK")


def _run():
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        print(f"- {t.__name__}")
        t()
    print(f"\nALL {len(tests)} geometry checks passed.")


if __name__ == "__main__":
    _run()
