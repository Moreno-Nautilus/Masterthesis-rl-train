"""Plain-script checks for half_circle_waypoints.py. Pure math, no ROS.

Run:  python3 tests/test_half_circle_waypoints.py
"""

import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")))

import numpy as np

from fixture_relocation_scan.half_circle_waypoints import half_circle_waypoints


def test_waypoints_stay_on_own_side():
    """hold's waypoints must stay on the -Y side of the board, move's on +Y (own side only)."""
    board_center = np.array([0.1, -0.4, 0.02])
    for arm_key, expected_sign in (("hold", -1.0), ("move", 1.0)):
        waypoints = half_circle_waypoints(board_center, arm_key, radii_m=[0.2], height_m=0.15, n_per_radius=7)
        assert len(waypoints) == 7
        for wp in waypoints:
            dy = wp[1] - board_center[1]
            assert np.sign(dy) == expected_sign or abs(dy) < 1e-9, (arm_key, wp)
        print(f"  {arm_key}: 7 waypoints, all on the {('- ' if expected_sign < 0 else '+')}Y side  OK")


def test_radii_and_height_are_respected():
    board_center = np.array([0.0, 0.0, 0.0])
    radii_m = [0.15, 0.25]
    height_m = 0.10
    waypoints = half_circle_waypoints(board_center, "move", radii_m, height_m=height_m, n_per_radius=5)
    assert len(waypoints) == len(radii_m) * 5
    for i, radius_m in enumerate(radii_m):
        for wp in waypoints[i * 5:(i + 1) * 5]:
            planar_dist = np.linalg.norm(wp[:2] - board_center[:2])
            assert abs(planar_dist - radius_m) < 1e-9, (radius_m, planar_dist)
            assert abs(wp[2] - (board_center[2] + height_m)) < 1e-9
    print("  radii/height match every waypoint exactly  OK")


def test_invalid_arm_key_rejected():
    try:
        half_circle_waypoints(np.zeros(3), "nope", [0.2], height_m=0.1, n_per_radius=3)
        assert False, "expected ValueError"
    except ValueError:
        pass
    print("  invalid arm_key rejected  OK")


def main():
    for fn in (test_waypoints_stay_on_own_side, test_radii_and_height_are_respected, test_invalid_arm_key_rejected):
        print(fn.__name__)
        fn()
    print("all half_circle_waypoints checks passed")


if __name__ == "__main__":
    main()
