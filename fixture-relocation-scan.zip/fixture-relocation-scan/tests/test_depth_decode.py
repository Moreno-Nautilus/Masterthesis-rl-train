#!/usr/bin/env python3
"""Unit checks for fixture_relocation_scan/depth_decode.py -- no ROS, no hardware.

    conda activate fabrica-kuka-pdz8
    python3 ~/fixture-relocation-scan/tests/test_depth_decode.py
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fixture_relocation_scan.depth_decode import (
    depth_to_meters, img_to_numpy_depth, stamp_to_sec,
)


class _FakeImg:
    def __init__(self, arr, encoding, pad_bytes=0):
        h, w = arr.shape
        self.height, self.width, self.encoding = h, w, encoding
        elem = 2 if encoding == "16UC1" else 4
        self.step = w * elem + pad_bytes
        if pad_bytes:
            rows = [arr[r].tobytes() + b"\x00" * pad_bytes for r in range(h)]
            self.data = b"".join(rows)
        else:
            self.data = arr.tobytes()


class _FakeStamp:
    def __init__(self, sec, nanosec):
        self.sec, self.nanosec = sec, nanosec


def test_16uc1_millimetres_roundtrip():
    mm = (np.arange(12, dtype=np.uint16).reshape(3, 4) + 1) * 100  # 100..1200 mm
    raw = img_to_numpy_depth(_FakeImg(mm, "16UC1"))
    assert raw.dtype == np.uint16 and np.array_equal(raw, mm)
    m = depth_to_meters(raw, "16UC1")
    assert np.allclose(m, mm.astype(np.float32) * 1e-3)
    print("  16UC1 decode + mm->m  OK")


def test_16uc1_with_row_padding():
    mm = (np.arange(6, dtype=np.uint16).reshape(2, 3) + 1) * 250
    raw = img_to_numpy_depth(_FakeImg(mm, "16UC1", pad_bytes=8))
    assert np.array_equal(raw, mm), raw
    print("  16UC1 row-padding stripped  OK")


def test_32fc1_passthrough():
    d = np.random.default_rng(0).random((4, 5), dtype=np.float32) * 2.0
    raw = img_to_numpy_depth(_FakeImg(d, "32FC1"))
    assert np.allclose(raw, d)
    assert np.allclose(depth_to_meters(raw, "32FC1"), d)
    print("  32FC1 passthrough  OK")


def test_bad_encoding_raises():
    for fn, args in ((img_to_numpy_depth, (_FakeImg(np.zeros((2, 2), np.uint16), "mono8"),)),
                     (depth_to_meters, (np.zeros((2, 2)), "mono8"))):
        try:
            fn(*args)
            assert False, "expected ValueError"
        except ValueError:
            pass
    print("  unsupported encoding raises  OK")


def test_stamp_to_sec():
    assert abs(stamp_to_sec(_FakeStamp(5, 500_000_000)) - 5.5) < 1e-9
    print("  stamp_to_sec  OK")


def main():
    for fn in (test_16uc1_millimetres_roundtrip, test_16uc1_with_row_padding,
               test_32fc1_passthrough, test_bad_encoding_raises, test_stamp_to_sec):
        print(fn.__name__)
        fn()
    print("all depth_decode checks passed")


if __name__ == "__main__":
    main()
