"""Synthetic self-test for aruco_board_pose.py -- the one thing genuinely verifiable without
hardware (docs/live_fixture_relocation_implementation_plan.md, Deliverable 3 verification).

Renders a small pinhole image containing a synthetically-placed ArUco board at a *known*
T_cam_board (project each marker's known 3D corners through that pose, warp a canonical
generated marker bitmap into the resulting image quadrilateral), feeds it through
aruco_board_pose.solve_board_pose(), and checks the recovered pose matches the known one.
No rclpy, no docker, no hardware -- just cv2 with cv2.aruco.ArucoDetector
(opencv-python>=4.7; confirmed available e.g. in the `imgpy` conda env, or the vision
container's venv).

Run:  python3 tests/test_aruco_board_pose_synthetic.py
"""

import json
import os
import sys
import tempfile

project_dir = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.append(project_dir)

import cv2
import numpy as np

from fixture_relocation_scan.aruco_board_pose import load_board_from_nominal_pose, solve_board_pose

DICTIONARY_NAME = "DICT_4X4_50"
IMAGE_SIZE = (640, 480)  # (width, height)
CANONICAL_MARKER_PX = 200


def _make_nominal_pose_json(tmp_dir, marker_ids, marker_centers_m, marker_size_m):
    half = marker_size_m / 2.0
    board_obj_points_m = []
    for cx, cy in marker_centers_m:
        # Index 0..3 must land, after projection through the test's rvec=0 camera (world axes
        # == camera axes, so +Y maps straight to +image_y, i.e. "down"), in the same winding as
        # _render_synthetic_image's canonical src_pts (TL,TR,BR,BL in true image top-left
        # convention) -- otherwise the warp is a mirror of a valid marker, which ArUco detection
        # correctly rejects (not one of the 4 valid rotations). Smallest world Y -> smallest
        # image y -> "top".
        board_obj_points_m.append([
            [cx - half, cy - half, 0.0],  # top-left
            [cx + half, cy - half, 0.0],  # top-right
            [cx + half, cy + half, 0.0],  # bottom-right
            [cx - half, cy + half, 0.0],  # bottom-left
        ])
    payload = {"opencv": {
        "dictionary": DICTIONARY_NAME,
        "marker_length_m": marker_size_m,
        "board_ids": list(marker_ids),
        "board_obj_points_m": board_obj_points_m,
    }}
    path = os.path.join(tmp_dir, "nominal_world_pose.json")
    with open(path, "w") as fp:
        json.dump(payload, fp)
    return path, board_obj_points_m


def _render_synthetic_image(board_obj_points_m, marker_ids, K, rvec, tvec):
    dictionary = cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, DICTIONARY_NAME))
    width, height = IMAGE_SIZE
    canvas = np.full((height, width, 3), 200, dtype=np.uint8)
    dist = np.zeros((8, 1))
    src_pts = np.array([[0, 0], [CANONICAL_MARKER_PX, 0],
                        [CANONICAL_MARKER_PX, CANONICAL_MARKER_PX], [0, CANONICAL_MARKER_PX]], dtype=np.float32)
    for marker_id, obj_points in zip(marker_ids, board_obj_points_m):
        marker_gray = cv2.aruco.generateImageMarker(dictionary, marker_id, CANONICAL_MARKER_PX)
        marker_bgr = cv2.cvtColor(marker_gray, cv2.COLOR_GRAY2BGR)
        projected, _ = cv2.projectPoints(np.array(obj_points, dtype=np.float32), rvec, tvec, K, dist)
        dst_pts = projected.reshape(-1, 2).astype(np.float32)
        H = cv2.getPerspectiveTransform(src_pts, dst_pts)
        warped = cv2.warpPerspective(marker_bgr, H, IMAGE_SIZE)
        mask = cv2.warpPerspective(np.full((CANONICAL_MARKER_PX, CANONICAL_MARKER_PX), 255, dtype=np.uint8), H, IMAGE_SIZE)
        canvas[mask > 0] = warped[mask > 0]
    return canvas


def _rotation_angle_error_rad(R_a, R_b):
    R_err = R_a.T @ R_b
    return float(np.arccos(np.clip((np.trace(R_err) - 1.0) / 2.0, -1.0, 1.0)))


def test_solve_board_pose_recovers_known_pose():
    with tempfile.TemporaryDirectory() as tmp_dir:
        marker_ids = [0, 1]
        nominal_path, board_obj_points_m = _make_nominal_pose_json(
            tmp_dir, marker_ids, [(-0.05, 0.0), (0.05, 0.0)], marker_size_m=0.03)
        board, dictionary, marker_length_m = load_board_from_nominal_pose(nominal_path)
        assert marker_length_m == 0.03

        K = np.array([[600.0, 0.0, 320.0], [0.0, 600.0, 240.0], [0.0, 0.0, 1.0]])
        rvec = np.zeros((3, 1))
        tvec = np.array([[0.0], [0.0], [0.4]])
        img = _render_synthetic_image(board_obj_points_m, marker_ids, K, rvec, tvec)

        T_cam_board, corners_px, reproj_err_px = solve_board_pose(img, K, board, dictionary)

        R_expected, _ = cv2.Rodrigues(rvec)
        assert reproj_err_px < 1.0, f"reprojection error too high: {reproj_err_px}"
        assert np.allclose(T_cam_board[:3, 3], tvec.reshape(3), atol=0.01), T_cam_board[:3, 3]
        angle_err_rad = _rotation_angle_error_rad(T_cam_board[:3, :3], R_expected)
        assert angle_err_rad < np.radians(2.0), f"rotation error too high: {np.degrees(angle_err_rad):.2f} deg"
        assert corners_px.shape[0] >= 4
        print(f"  recovered pose within {np.linalg.norm(T_cam_board[:3, 3] - tvec.reshape(3)) * 1000:.2f} mm / "
              f"{np.degrees(angle_err_rad):.3f} deg, reproj err {reproj_err_px:.3f} px  OK")


def test_solve_board_pose_raises_when_board_absent():
    with tempfile.TemporaryDirectory() as tmp_dir:
        nominal_path, _ = _make_nominal_pose_json(tmp_dir, [0], [(0.0, 0.0)], marker_size_m=0.03)
        board, dictionary, _ = load_board_from_nominal_pose(nominal_path)
        blank = np.full((IMAGE_SIZE[1], IMAGE_SIZE[0], 3), 200, dtype=np.uint8)
        K = np.array([[600.0, 0.0, 320.0], [0.0, 600.0, 240.0], [0.0, 0.0, 1.0]])
        try:
            solve_board_pose(blank, K, board, dictionary)
            assert False, "expected RuntimeError for a board-absent image"
        except RuntimeError:
            pass
        print("  blank image correctly raises RuntimeError  OK")


def main():
    for fn in (test_solve_board_pose_recovers_known_pose, test_solve_board_pose_raises_when_board_absent):
        print(fn.__name__)
        fn()
    print("all aruco_board_pose synthetic checks passed")


if __name__ == "__main__":
    main()
