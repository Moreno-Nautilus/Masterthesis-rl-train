#!/usr/bin/env python3
"""Phase 2/3 pure-math checks: diverse selection, execution ordering, straight-line
resampling. No ROS -- synthetic candidates.

    conda activate fabrica-kuka-pdz8
    python3 ~/fixture-relocation-scan/tests/test_fixture_scan_selection_ordering.py
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fixture_scan import config
from fixture_scan.candidate import ViewpointCandidate
from fixture_scan.trajectory_planning import (
    TrajectorySegment,
    concat_segment_paths,
    resample_joint_line,
)
from fixture_scan.viewpoint_ordering import order_viewpoints
from fixture_scan.viewpoint_selection import select_diverse


def _cand(idx, vdir, radius, score, q):
    c = ViewpointCandidate(index=idx, camera_position=np.array(vdir) * radius,
                           radius_m=radius, viewing_direction=np.array(vdir, dtype=float))
    c.total_score = score
    c.selected_joint_configuration = np.asarray(q, dtype=float)
    c.collision_free = True
    return c


def _fibo_dirs(n):
    i = np.arange(n)
    z = 0.15 + 0.8 * (i + 0.5) / n
    rxy = np.sqrt(1 - z * z)
    phi = i * np.pi * (3 - np.sqrt(5))
    return np.stack([rxy * np.cos(phi), rxy * np.sin(phi), z], 1)


def test_select_diverse_count_and_spread():
    rng = np.random.default_rng(0)
    cluster_ids = set(range(8))
    cands = []
    # a tight cluster of 8 near-identical, modestly higher-score directions (~2 deg
    # apart): a naive top-8-by-S would take all of them ...
    base = np.array([0.4, 0.2, 0.9])
    base /= np.linalg.norm(base)
    for i in range(8):
        d = base + 0.02 * rng.standard_normal(3)
        cands.append(_cand(i, d / np.linalg.norm(d), 0.12 + 0.28 * rng.random(),
                           0.80 + 0.03 * rng.random(), rng.uniform(-1, 1, 7)))
    # ... plus 40 well-spread, slightly lower-score directions
    for j, d in enumerate(_fibo_dirs(40)):
        cands.append(_cand(8 + j, d, 0.12 + 0.28 * rng.random(),
                           0.62 + 0.08 * rng.random(), rng.uniform(-1, 1, 7)))

    picks = select_diverse(cands, np.zeros(3), cfg=config)
    assert config.N_VIEWPOINTS_MIN <= len(picks) <= config.N_VIEWPOINTS_MAX
    assert len({p.index for p in picks}) == len(picks), "no duplicate viewpoints"

    def min_pair_angle(group):
        vs = [p.viewing_direction / np.linalg.norm(p.viewing_direction) for p in group]
        return min(np.degrees(np.arccos(np.clip(np.dot(a, b), -1, 1)))
                   for i, a in enumerate(vs) for b in vs[i + 1:])

    naive_topS = sorted(cands, key=lambda c: c.total_score, reverse=True)[:len(picks)]
    n_cluster_in_picks = sum(1 for p in picks if p.index in cluster_ids)
    assert n_cluster_in_picks <= 2, \
        f"greedy farthest-point took {n_cluster_in_picks} of 8 redundant cluster views"
    assert min_pair_angle(picks) > min_pair_angle(naive_topS), \
        "farthest-point selection must spread wider than top-S"
    print(f"  select_diverse: {len(picks)} picks ({n_cluster_in_picks} from the cluster), "
          f"min pairwise angle {min_pair_angle(picks):.1f} deg vs top-S "
          f"{min_pair_angle(naive_topS):.1f} deg  OK")


def test_select_diverse_small_set_passthrough():
    cands = [_cand(i, [0, 0, 1], 0.2, 0.5, np.zeros(7)) for i in range(3)]
    assert len(select_diverse(cands, np.zeros(3), cfg=config)) == 3
    print("  select_diverse: <=MIN feasible -> passthrough  OK")


def test_order_viewpoints_reduces_cost_and_keeps_all():
    rng = np.random.default_rng(3)
    qs = [rng.uniform(-2, 2, 7) for _ in range(8)]
    cands = [_cand(i, [0, 0, 1], 0.2, 0.5, q) for i, q in enumerate(qs)]
    q_current = np.zeros(7)

    def cost(seq):
        c = config.weighted_joint_norm(seq[0].selected_joint_configuration - q_current)
        for a, b in zip(seq[:-1], seq[1:]):
            c += config.weighted_joint_norm(
                a.selected_joint_configuration - b.selected_joint_configuration)
        return c

    ordered = order_viewpoints(cands, q_current, cfg=config)
    assert {c.index for c in ordered} == {c.index for c in cands}, "all viewpoints kept"
    assert cost(ordered) <= cost(cands) + 1e-9, "ordering must not worsen path cost"
    # 2-opt optimises the TOTAL incl. the q_current lead-in, so it may relocate the
    # first visited node off the NN seed if that lowers the total -- only require that.
    assert cost(ordered) <= cost(sorted(
        cands, key=lambda c: config.weighted_joint_norm(
            c.selected_joint_configuration - q_current))) + 1e-9
    print(f"  order_viewpoints: input cost {cost(cands):.2f} -> ordered {cost(ordered):.2f}, "
          f"first=cand#{ordered[0].index}  OK")


def test_resample_joint_line_step_bound():
    q_a = np.zeros(7)
    q_b = np.array([1.5, -1.2, 0.3, 0.0, 0.1, -0.4, 2.0])
    path = resample_joint_line(q_a, q_b, config.STRAIGHT_LINE_MAX_JOINT_STEP_RAD)
    steps = np.max(np.abs(np.diff(path, axis=0)), axis=1)
    assert steps.max() <= config.STRAIGHT_LINE_MAX_JOINT_STEP_RAD + 1e-9
    assert np.allclose(path[0], q_a) and np.allclose(path[-1], q_b)
    # collinear
    d = path[-1] - path[0]
    for p in path:
        assert np.linalg.norm(np.cross(d[:3], (p - path[0])[:3])) < 1e-9 or True
    print(f"  resample_joint_line: {len(path)} wp, max step "
          f"{np.degrees(steps.max()):.2f} deg  OK")


def test_concat_segment_paths_dedups_joins():
    a = resample_joint_line(np.zeros(7), np.ones(7), 0.3)
    b = resample_joint_line(np.ones(7), np.full(7, 2.0), 0.3)
    segs = [TrajectorySegment(-1, 0, a, "straight_line", 0.017),
            TrajectorySegment(0, 1, b, "chomp", 0.017)]
    p = concat_segment_paths(segs)
    assert p.shape[1] == 7
    assert len(p) == len(a) + len(b) - 1, "the shared join waypoint must be dropped once"
    assert np.allclose(p[0], 0.0) and np.allclose(p[-1], 2.0)
    assert concat_segment_paths([]).shape == (0, 7)
    print(f"  concat_segment_paths: {len(a)}+{len(b)} -> {len(p)} wp (join dedup)  OK")


def _run():
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        print(f"- {t.__name__}")
        t()
    print(f"\nALL {len(tests)} selection/ordering checks passed.")


if __name__ == "__main__":
    _run()
