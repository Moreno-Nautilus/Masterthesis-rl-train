"""Synthetic self-test for tools/recalibrate_cam_flange.py.

Generates a two-camera ArUco-board capture with a *known* ground-truth board pose and a
deliberately perturbed nominal flange->camera extrinsic, runs the joint recalibration, and
checks the recovered extrinsic collapses the injected error and the two cameras' fixture
estimates come into agreement. No rclpy, no hardware -- just cv2.aruco + scipy.

Needs an ArUco `nominal_world_pose.json` (an `opencv` block: board dictionary + object
points) under ~/Fabrica-pdz/logs/.../fixture/. Skips cleanly if none is present.

Run:  python3 tests/test_recalibrate_cam_flange.py
"""

import os
import sys
import tempfile

project_dir = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, project_dir)

import numpy as np  # noqa: E402

from tools.recalibrate_cam_flange import (  # noqa: E402
    DEFAULT_INTRINSICS,
    DEFAULT_TRANSFORMS,
    _find_selftest_nominal_pose,
    _T_delta,
    load_nominal_transforms,
    run,
    synthesize_fixture,
)

_NOMINAL_POSE = _find_selftest_nominal_pose()


def _require_board():
    if _NOMINAL_POSE is None:
        print("  SKIP: no ArUco nominal_world_pose.json found under ~/Fabrica-pdz/logs/")
        return False
    return True


def test_camera_transforms_yaml_parses():
    T = load_nominal_transforms(DEFAULT_TRANSFORMS)
    for side in ("left", "right"):
        assert T[side].shape == (4, 4)
        assert np.allclose(T[side][3], [0, 0, 0, 1])
        assert abs(np.linalg.det(T[side][:3, :3]) - 1.0) < 1e-6
    print("  camera_transforms.yaml: left + right are valid SE(3)  OK")


def test_joint_recalibration_recovers_perturbation():
    if not _require_board():
        return
    with tempfile.TemporaryDirectory() as td:
        info = synthesize_fixture(td, _NOMINAL_POSE, DEFAULT_TRANSFORMS, seed=3,
                                  write_perturbed_transforms=os.path.join(td, "nominal.yaml"))
        out = run(td, nominal_pose=_NOMINAL_POSE,
                  transforms_path=os.path.join(td, "nominal.yaml"),
                  intrinsics_yaml=DEFAULT_INTRINSICS,
                  out_yaml=os.path.join(td, "recal.yaml"),
                  base_to_base=None, huber_px=1.0, max_reproj_px=3.0, min_corners=8,
                  joint=True, quiet=True)

        assert out["joint"] is True
        for side in ("left", "right"):
            X_star = out["solved"][side]["X"]
            before = _T_delta(info["perturbed"][side], info["X_gt"][side])
            after = _T_delta(X_star, info["X_gt"][side])
            assert before["rot_deg"] > 1.5, before          # perturbation really was injected
            assert after["rot_deg"] < 1.2, (side, after)    # ...and mostly removed
            assert after["trans_mm"] < 6.0, (side, after)
            # reprojection consistency improves
            assert out["solved"][side]["reproj_after"] <= out["solved"][side]["reproj_before"] + 1e-6
            print(f"  [{side}] {before['rot_deg']:.2f} deg/{before['trans_mm']:.1f} mm off GT "
                  f"-> {after['rot_deg']:.2f} deg/{after['trans_mm']:.1f} mm  OK")

        assert os.path.exists(os.path.join(td, "recal.yaml"))


def test_recalibrated_yaml_roundtrips():
    if not _require_board():
        return
    with tempfile.TemporaryDirectory() as td:
        synthesize_fixture(td, _NOMINAL_POSE, DEFAULT_TRANSFORMS, seed=4,
                           write_perturbed_transforms=os.path.join(td, "nominal.yaml"))
        run(td, nominal_pose=_NOMINAL_POSE, transforms_path=os.path.join(td, "nominal.yaml"),
            intrinsics_yaml=DEFAULT_INTRINSICS, out_yaml=os.path.join(td, "recal.yaml"),
            base_to_base=None, huber_px=1.0, max_reproj_px=3.0, min_corners=8,
            joint=True, quiet=True)
        reloaded = load_nominal_transforms(os.path.join(td, "recal.yaml"))
        for side in ("left", "right"):
            assert reloaded[side].shape == (4, 4)
            assert abs(np.linalg.det(reloaded[side][:3, :3]) - 1.0) < 1e-6
        print("  recalibrated YAML reloads via load_nominal_transforms  OK")


def main():
    for fn in (test_camera_transforms_yaml_parses,
               test_joint_recalibration_recovers_perturbation,
               test_recalibrated_yaml_roundtrips):
        print(fn.__name__)
        fn()
    print("all recalibrate_cam_flange checks passed")


if __name__ == "__main__":
    main()
