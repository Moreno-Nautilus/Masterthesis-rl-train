#!/usr/bin/env python3
"""scan_program.json build + load round-trip (no ROS).

    conda activate fabrica-kuka-pdz8
    python3 ~/fixture-relocation-scan/tests/test_fixture_scan_scan_program.py
"""

import os
import sys
import tempfile

import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fixture_scan import config
from fixture_scan.candidate import ViewpointCandidate
from fixture_scan.geometry import make_T
from fixture_scan import scan_program as sp
from fixture_scan.trajectory_planning import TrajectorySegment, resample_joint_line


def _fake_plan(n=6):
    rng = np.random.default_rng(1)
    ordered, segments = [], []
    q_prev = np.zeros(7)
    for k in range(n):
        q = rng.uniform(-1.5, 1.5, 7)
        c = ViewpointCandidate(index=100 + k, camera_position=rng.uniform(-.3, .5, 3),
                               radius_m=0.15 + 0.02 * k,
                               viewing_direction=np.array([0., 0., 1.]))
        c.selected_marker_id = k % 6
        c.selected_joint_configuration = q
        c.T_base_tcp = make_T(np.eye(3), c.camera_position)
        c.total_score = 0.8 - 0.03 * k
        c.collision_free = True
        ordered.append(c)
        path = resample_joint_line(q_prev, q, config.STRAIGHT_LINE_MAX_JOINT_STEP_RAD)
        segments.append(TrajectorySegment(
            from_index=k - 1, to_index=k, path=path,
            tier="straight_line" if k % 2 == 0 else "chomp",
            checked_step_rad=config.COLLISION_CHECK_STEP_RAD))
        q_prev = q
    return ordered, segments


def test_build_and_load_roundtrip():
    ordered, segments = _fake_plan(6)
    q_current = np.zeros(7)
    other_arm_q = np.full(7, 0.1)
    prog = sp.build_program(
        "hold", ordered, segments, q_current=q_current, other_arm_q=other_arm_q,
        fixture_pose_path="/x/nominal_world_pose.json", cam_id="realsense_1",
        intrinsics_path="/x/intr.yaml", extrinsics_path="/x/extr.yaml", plan="plumbers_block_new_3")

    assert prog["meta"]["arm_role"] == "hold"
    assert prog["meta"]["config_sha"] == config.config_sha()
    assert prog["meta"]["n_viewpoints"] == 6
    assert len(prog["meta"]["segment_tiers"]) == 6

    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as fp:
        path = fp.name
    sp.write_program(path, prog)
    loaded = sp.load_program(path)
    os.unlink(path)

    assert loaded.role == "hold"
    assert np.allclose(loaded.q_current, q_current)
    assert np.allclose(loaded.other_arm_q, other_arm_q)
    assert len(loaded.viewpoints) == 6
    for k, (vp, seg, cand) in enumerate(zip(loaded.viewpoints, segments, ordered)):
        assert vp.index == k
        assert np.allclose(vp.joint_config, cand.selected_joint_configuration)
        assert vp.trajectory.shape == seg.path.shape
        assert np.allclose(vp.trajectory[-1], cand.selected_joint_configuration, atol=1e-9)
        assert vp.trajectory.shape[1] == 7
        assert vp.traj_tier == seg.tier
        assert vp.marker_id == cand.selected_marker_id
    # viewpoint 0's trajectory is the lead-in from q_current
    assert np.allclose(loaded.viewpoints[0].trajectory[0], q_current, atol=1e-9)
    print(f"  scan_program: 6 viewpoints, round-trip OK, tiers "
          f"{[v.traj_tier for v in loaded.viewpoints]}")


def test_program_from_dict_matches_load_program():
    """program_from_dict(dict) == load_program(file) -- the in-process --plan-viewpoints
    path must yield the same ScanProgram the container gets from a staged file."""
    ordered, segments = _fake_plan(5)
    prog = sp.build_program(
        "move", ordered, segments, q_current=np.full(7, 0.2), other_arm_q=np.zeros(7),
        fixture_pose_path="/x/nominal_world_pose.json", cam_id="realsense_2",
        intrinsics_path="/x/intr.yaml", extrinsics_path="/x/extr.yaml",
        plan="plumbers_block_new_3", intrinsics_source="camera_info")

    from_dict = sp.program_from_dict(prog)

    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as fp:
        path = fp.name
    sp.write_program(path, prog)
    from_file = sp.load_program(path)
    os.unlink(path)

    assert from_dict.meta == from_file.meta
    assert from_dict.role == from_file.role == "move"
    assert from_dict.meta["intrinsics_source"] == "camera_info"
    assert len(from_dict.viewpoints) == len(from_file.viewpoints) == 5
    for a, b in zip(from_dict.viewpoints, from_file.viewpoints):
        assert a.index == b.index
        assert a.traj_tier == b.traj_tier
        assert a.marker_id == b.marker_id
        assert np.allclose(a.trajectory, b.trajectory)
        assert np.allclose(a.joint_config, b.joint_config)
        assert np.allclose(a.T_base_tcp, b.T_base_tcp)
    print(f"  program_from_dict == load_program: 5 viewpoints, tiers "
          f"{[v.traj_tier for v in from_dict.viewpoints]}")


def _run():
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        print(f"- {t.__name__}")
        t()
    print(f"\nALL {len(tests)} scan_program checks passed.")


if __name__ == "__main__":
    _run()
