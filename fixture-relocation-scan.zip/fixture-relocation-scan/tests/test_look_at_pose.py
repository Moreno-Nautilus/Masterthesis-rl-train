"""Plain-script checks for look_at_pose.py's pure-math solve_look_at_flange_pose. Pure math, no
ROS, no Masterthesis-vision import (that's only needed by flange_matrix_to_arm_target, not
tested here -- it just wraps an already-solved 4x4 into Masterthesis-vision's ArmTarget type).

Run:  python3 tests/test_look_at_pose.py
"""

import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")))

import numpy as np

from fixture_relocation_scan.look_at_pose import FLANGE_TO_FINGERTIP_M, solve_look_at_flange_pose


def test_camera_axis_points_at_target():
    """The solved flange pose's camera axis (R_flange @ R_flange_cam's Z column) must point
    from the camera position back at the target."""
    target_pos = np.array([0.5, -0.4, 0.05])
    camera_pos_hint = np.array([0.5, -0.6, 0.20])  # off to the side and above
    T_flange_cam = np.eye(4)
    T_flange_cam[:3, 3] = [0.0, 0.0, 0.09]  # purely axial, 9cm ahead of the flange
    fingertip_standoff_m = 0.10

    T_flange = solve_look_at_flange_pose(target_pos, camera_pos_hint, T_flange_cam, fingertip_standoff_m)
    R_flange, t_flange = T_flange[:3, :3], T_flange[:3, 3]
    camera_pos = t_flange + R_flange @ T_flange_cam[:3, 3]
    camera_z_axis = R_flange @ T_flange_cam[:3, :3][:, 2]

    to_target = target_pos - camera_pos
    to_target_dir = to_target / np.linalg.norm(to_target)
    assert np.allclose(camera_z_axis, to_target_dir, atol=1e-9), (camera_z_axis, to_target_dir)
    print("  camera +Z axis points exactly at the target  OK")


def test_fingertip_standoff_is_respected():
    """The FINGERTIP (flange + FLANGE_TO_FINGERTIP_M along the tool axis), not the camera, must
    sit exactly fingertip_standoff_m from the target -- the whole point of this function."""
    target_pos = np.array([0.0, 0.0, 0.0])
    camera_pos_hint = np.array([0.3, 0.0, 0.0])
    T_flange_cam = np.eye(4)
    T_flange_cam[:3, 3] = [0.0, 0.0, 0.08]
    fingertip_standoff_m = 0.15

    T_flange = solve_look_at_flange_pose(target_pos, camera_pos_hint, T_flange_cam, fingertip_standoff_m)
    R_flange, t_flange = T_flange[:3, :3], T_flange[:3, 3]
    fingertip_pos = t_flange + R_flange @ np.array([0.0, 0.0, FLANGE_TO_FINGERTIP_M])
    dist_to_target = np.linalg.norm(fingertip_pos - target_pos)
    assert abs(dist_to_target - fingertip_standoff_m) < 1e-9, dist_to_target
    print(f"  fingertip stands off {dist_to_target * 100:.2f} cm from target (asked for "
          f"{fingertip_standoff_m * 100:.2f} cm)  OK")


def test_degenerate_hint_raises():
    try:
        solve_look_at_flange_pose(np.zeros(3), np.zeros(3), np.eye(4), 0.1)
        assert False, "expected ValueError for a coincident target/camera hint"
    except ValueError:
        pass
    print("  coincident target/camera hint rejected  OK")


def main():
    for fn in (test_camera_axis_points_at_target, test_fingertip_standoff_is_respected, test_degenerate_hint_raises):
        print(fn.__name__)
        fn()
    print("all look_at_pose checks passed")


if __name__ == "__main__":
    main()
