#!/usr/bin/env python3
"""Geometry checks for tools/build_scan_cloud.py -- backprojection, base-frame transform,
ROI crop, voxel average, statistical outlier removal, PLY IO. No ROS, no hardware.

    conda activate fabrica-kuka-pdz8
    python3 ~/fixture-relocation-scan/tests/test_scan_cloud_backproject.py
"""

import os
import sys
import tempfile

import numpy as np

_PROJ = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(_PROJ, "tools"))

import build_scan_cloud as bsc

K = np.array([[600.0, 0.0, 320.0], [0.0, 600.0, 240.0], [0.0, 0.0, 1.0]])
W, H = 640, 480


def _T(rpy=(0, 0, 0), t=(0, 0, 0)):
    from scipy.spatial.transform import Rotation
    T = np.eye(4)
    T[:3, :3] = Rotation.from_euler("xyz", rpy).as_matrix()
    T[:3, 3] = t
    return T


def _tilted_plane_depth(normal_cam, d):
    """Depth image whose every valid pixel's 3D point satisfies normal_cam . p = d."""
    us, vs = np.meshgrid(np.arange(W), np.arange(H))
    rays = np.stack([(us - K[0, 2]) / K[0, 0], (vs - K[1, 2]) / K[1, 1], np.ones_like(us)], axis=-1)
    denom = rays @ normal_cam
    z = d / denom
    z[(z <= 0) | (z > 5)] = np.nan
    return z.astype(np.float32)


def test_backproject_points_lie_on_plane():
    n_cam = np.array([0.1, -0.2, 0.97])
    n_cam /= np.linalg.norm(n_cam)
    depth = _tilted_plane_depth(n_cam, d=0.6)
    pts_cam, valid = bsc._backproject(depth, K, z_min=0.05, z_max=2.0)
    resid = pts_cam @ n_cam - 0.6
    assert np.abs(resid).max() < 1e-4, np.abs(resid).max()
    assert valid.sum() > 0.5 * W * H
    print(f"  {valid.sum()} pts, max plane residual {np.abs(resid).max()*1e3:.3g} mm  OK")


def test_base_frame_transform_preserves_plane():
    n_cam = np.array([0.0, 0.0, 1.0])
    depth = _tilted_plane_depth(n_cam, d=0.5)
    pts_cam, _ = bsc._backproject(depth, K, 0.05, 2.0)
    pts_cam = pts_cam[::4]  # uniform downsample, as build_arm_cloud does
    Tbc = _T(rpy=(0.3, -0.4, 1.1), t=(0.7, -0.2, 0.4))
    pts_base = (Tbc[:3, :3] @ pts_cam.T).T + Tbc[:3, 3]
    n_base = Tbc[:3, :3] @ n_cam
    d_base = n_base @ (Tbc[:3, :3] @ np.array([0, 0, 0.5]) + Tbc[:3, 3])
    resid = pts_base @ n_base - d_base
    assert np.abs(resid).max() < 1e-4, np.abs(resid).max()
    print(f"  transformed plane residual {np.abs(resid).max()*1e3:.3g} mm  OK")


def test_roi_mask_keeps_only_the_box():
    rng = np.random.default_rng(0)
    T_board = _T(t=(0.5, 0.0, 0.3))
    pts = rng.uniform(-1, 1, size=(20000, 3)) + np.array([0.5, 0.0, 0.3])
    m = bsc._roi_mask(pts, T_board, half_xy=0.2, z_lo=-0.05, z_hi=0.1)
    local = (pts[m] - T_board[:3, 3]) @ T_board[:3, :3]
    assert np.abs(local[:, :2]).max() <= 0.2 + 1e-9
    assert local[:, 2].min() >= -0.05 - 1e-9 and local[:, 2].max() <= 0.1 + 1e-9
    assert 0 < m.sum() < len(pts)
    print(f"  ROI kept {m.sum()}/{len(pts)}  OK")


def test_voxel_average_fuses_and_means():
    # cluster centres sit mid-voxel so sub-voxel jitter never crosses a cell boundary
    ca, cb = np.array([0.105, 0.205, 0.305]), np.array([0.505, 0.505, 0.505])
    a = ca + np.random.default_rng(1).normal(scale=3e-4, size=(500, 3))
    b = cb + np.zeros((10, 3))
    out, _ = bsc.voxel_average(np.vstack([a, b]), None, voxel_m=0.01)
    assert len(out) == 2, len(out)
    near = out[np.argmin(np.linalg.norm(out - ca, axis=1))]
    assert np.allclose(near, a.mean(axis=0), atol=1e-6), near   # exact centroid
    print(f"  510 pts -> {len(out)} voxels, centroid {near.round(5).tolist()}  OK")


def test_sor_drops_flyers():
    rng = np.random.default_rng(2)
    inliers = rng.normal(scale=1e-3, size=(2000, 3))
    flyers = rng.uniform(-0.5, 0.5, size=(20, 3)) + np.array([2.0, 0, 0])
    pts = np.vstack([inliers, flyers])
    out, _ = bsc.remove_statistical_outliers(pts, None, k=20, std_ratio=2.0)
    assert len(out) >= 1900 and len(out) <= 2000, len(out)
    assert np.linalg.norm(out, axis=1).max() < 0.1
    print(f"  {len(pts)} -> {len(out)} after SOR (flyers removed)  OK")


def test_write_ply_roundtrip():
    pts = np.random.default_rng(3).random((100, 3)).astype(np.float64)
    cols = np.random.default_rng(4).random((100, 3))
    with tempfile.TemporaryDirectory() as td:
        p = os.path.join(td, "c.ply")
        bsc.write_ply(p, pts, cols)
        head = open(p, "rb").read(200).decode("ascii", "replace")
        assert "element vertex 100" in head and "property uchar red" in head
        # parse back the binary block
        with open(p, "rb") as fp:
            raw = fp.read()
        body = raw.split(b"end_header\n", 1)[1]
        rec = np.frombuffer(body, dtype=[("xyz", "<f4", 3), ("rgb", "u1", 3)])
        assert np.allclose(rec["xyz"], pts.astype("<f4"), atol=1e-6)
    print("  PLY header + binary body roundtrip  OK")


def main():
    for fn in (test_backproject_points_lie_on_plane,
               test_base_frame_transform_preserves_plane,
               test_roi_mask_keeps_only_the_box,
               test_voxel_average_fuses_and_means,
               test_sor_drops_flyers,
               test_write_ply_roundtrip):
        print(fn.__name__)
        fn()
    print("all build_scan_cloud geometry checks passed")


if __name__ == "__main__":
    main()
