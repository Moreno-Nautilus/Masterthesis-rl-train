"""Joint-position arm motion for the live fixture scan.

**Thin adapter over the real executor node.** The scan runs on the HOST (conda
``fabrica-kuka-pdz8`` + ``~/franka_ros2_ws`` sourced), so
``lbr_dual_arm_pdz_bringup.plan_executor_node`` is importable. ``JtcArmMotion`` is a
subclass of ``PlanExecutor`` that **reuses its trajectory shaping and goal handling
verbatim** -- ``_send_arm_path -> _timed_waypoints -> _run_goal`` -- instead of maintaining
a hand-copy that drifts from the original. ``__init__`` here sets only the attributes those
inherited methods read, and wires the ``/joint_states`` sub + one combined-14-joint
``FollowJointTrajectory`` client. Everything about how a trajectory is timed, blended,
seam-anchored and sent is the executor node's code, unchanged.

Config it pins (matching ``hardware_plan_executor_node`` / ``FriCartesianImpedancePlanExecutor``):
  * ``_combined = True``            -- one 14-joint goal, idle arm pinned to the anchor config
  * ``_seam_anchor = "commanded"``  -- point 0 anchored on the previous commanded config so
    the JTC's ``desired`` does not step at goal-accept (a step there is read by the KUKA
    cabinet's INTERNAL Cartesian tracking-performance monitor -- below ROS, unsuppressable
    -- as a fault and latches an immediate Level-1 safety stop; see
    ``plan_executor_node.py`` ~L160-174 / ``FINDINGS_command_path_and_jump_2026-09-01.md``)
  * ``_tolerate_goal_tol = True``   -- each arm runs the cabinet's own FRI
    ``CARTESIAN_IMPEDANCE_CONTROL``, so a compliant arm rarely settles inside the JTC goal
    tolerance; a small ``GOAL_TOLERANCE_VIOLATED`` is expected, not a failure.

Unlike a full plan run, the scan's first goal has no prior command from this process to be
continuous with. ``__init__`` seeds ``_last_commanded_positions`` from the JTC's live
``state.desired`` (== what the controller is actually holding) so the very first
``_send_arm_path`` anchors correctly too. If the arms were **hand-moved** after the JTC
last commanded them, ``state.desired`` is stale -- restart (deactivate/reactivate) the
``joint_trajectory_controller`` before the scan so it re-latches ``desired = actual``.
"""

import numpy as np
import rclpy
from control_msgs.action import FollowJointTrajectory
from control_msgs.msg import JointTrajectoryControllerState
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import JointState

from lbr_dual_arm_pdz_bringup.plan_executor_node import (  # the real executor node
    ALL_JOINTS,
    ARM_JOINTS,
    DIVERGENCE_TOL_RAD_DEFAULT,
    ROLE_TO_ARM,
    PlanExecutor,
)


class JtcArmMotion(PlanExecutor):
    """Drives one arm at a time to a joint config (or along an (N,7) path) via the combined
    14-joint ``joint_trajectory_controller``, delegating the actual trajectory build + send
    to the inherited ``PlanExecutor._send_arm_path``. Every move is a standalone rest-to-rest
    goal; the idle arm is pinned at the seam-anchor config."""

    def __init__(self, node_name="fixture_scan_jtc_motion", robot_name="lbr_dual_arm", *,
                 time_scale=1.0, divergence_tol_rad=DIVERGENCE_TOL_RAD_DEFAULT,
                 on_failure="raise"):
        # Grandparent Node.__init__ only -- skip PlanExecutor.__init__ (argparse / gripper /
        # plan-loading / RViz, none of which the scan uses).
        Node.__init__(self, node_name)

        if on_failure not in ("raise", "continue"):
            raise ValueError(f"on_failure must be raise|continue, got {on_failure!r}")

        # --- attributes the inherited _send_arm_path / _timed_waypoints / _run_goal read ---
        self._combined = True
        self._seam_anchor = "commanded"
        self._tolerate_goal_tol = True
        self._on_failure = on_failure
        self._time_scale = float(time_scale) if time_scale and time_scale > 0 else 1.0
        self._divergence_tol_rad = (
            float(divergence_tol_rad) if divergence_tol_rad and divergence_tol_rad > 0 else None)
        self._last_commanded_positions = None      # seeded from state.desired below
        self._last_feedback = None
        self._current_positions = {}               # filled by inherited _joint_state_cb
        self._cart_err = {}                        # kept empty -> _cartesian_error_str -> None
        self._visualize_held_parts = False
        self.frame_idx = 0

        self.create_subscription(
            JointState, f"/{robot_name}/joint_states", self._joint_state_cb, 10)

        # The JTC's held setpoint -- what a goal-accept step would move `desired` FROM. Used
        # to seed _last_commanded_positions so the FIRST _send_arm_path (seam-anchor
        # "commanded") anchors on what the controller is really holding.
        self._jtc_desired = {}
        _state_qos = QoSProfile(depth=1)
        _state_qos.reliability = ReliabilityPolicy.RELIABLE
        _state_qos.durability = DurabilityPolicy.TRANSIENT_LOCAL
        self.create_subscription(
            JointTrajectoryControllerState,
            f"/{robot_name}/joint_trajectory_controller/state", self._jtc_state_cb, _state_qos)

        client = ActionClient(
            self, FollowJointTrajectory,
            f"/{robot_name}/joint_trajectory_controller/follow_joint_trajectory")
        self._arm_clients = {"lbr_one": client, "lbr_two": client}  # _send_arm_path keys by arm
        self.get_logger().info("waiting for joint_trajectory_controller action server...")
        if not client.wait_for_server(timeout_sec=20.0):
            raise RuntimeError(
                f"/{robot_name}/joint_trajectory_controller/follow_joint_trajectory not "
                "available after 20s -- is the hardware bring-up up and the controller active? "
                "(ros2 control list_controllers)")

        self.get_logger().info("waiting for initial /joint_states (all 14 joints)...")
        while rclpy.ok() and not all(j in self._current_positions for j in ALL_JOINTS):
            rclpy.spin_once(self, timeout_sec=0.5)

        # Seed the seam anchor from the JTC's held setpoint (up to ~1 s for the state topic).
        for _ in range(50):
            rclpy.spin_once(self, timeout_sec=0.02)
            if all(j in self._jtc_desired for j in ALL_JOINTS):
                self._last_commanded_positions = [self._jtc_desired[j] for j in ALL_JOINTS]
                measured = np.array([self._current_positions[j] for j in ALL_JOINTS])
                drift = np.degrees(np.abs(np.array(self._last_commanded_positions) - measured)).max()
                self.get_logger().info(
                    f"seam anchor seeded from JTC state.desired (max {drift:.2f} deg off "
                    f"measured). If that is large the arms were hand-moved since the JTC last "
                    f"commanded them -- restart the joint_trajectory_controller before scanning.")
                break
        else:
            self.get_logger().warn(
                "no joint_trajectory_controller/state received -- first move will anchor on "
                "the measured pose (fine if the JTC was just (re)activated).")

    # -- feedback ------------------------------------------------------------------------
    def _jtc_state_cb(self, msg):
        if not msg.desired.positions:
            return
        names = list(msg.joint_names) or ALL_JOINTS
        for name, position in zip(names, msg.desired.positions):
            self._jtc_desired[name] = position

    def current_arm_q(self, role: str) -> np.ndarray:
        """Freshly measured 7-vector for `role`'s arm (spins the node first)."""
        arm = ROLE_TO_ARM[role]
        for _ in range(5):
            rclpy.spin_once(self, timeout_sec=0.02)
        return np.array([self._current_positions[j] for j in ARM_JOINTS[arm]])

    # -- public move -------------------------------------------------------------------
    def move_arm_to_joints(self, role: str, q_target, description: str = "scan move") -> None:
        """Move `role`'s arm to `q_target` -- a single 7-vector or an (N,7) joint path -- via
        the inherited ``PlanExecutor._send_arm_path`` (identical timing / blending / seam
        anchoring / goal handling to the executor node). Blocks until the goal finishes;
        raises on a real failure per ``on_failure``."""
        path = np.asarray(q_target, dtype=float)
        if path.ndim == 1:
            path = path.reshape(1, 7)
        if path.ndim != 2 or path.shape[1] != 7:
            raise ValueError(f"q_target must be (7,) or (N,7), got {path.shape}")
        self._send_arm_path(role, path, description, active_part=None)
