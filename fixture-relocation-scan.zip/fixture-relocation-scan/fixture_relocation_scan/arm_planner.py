"""Collision-free joint trajectories to a flange pose, via MoveIt move_group.

Replaces the old "one compute_ik solution -> joint-lerp straight to it" path, which drove the
arm along an unvetted joint-space line to whatever (often near-singular, seed-ignoring) branch
KDL returned -- a straight-down look-at over an off-to-the-side fixture flips the wrist, and
the un-planned sweep tripped a cabinet protective stop.

Here move_group plans: it does IK + collision checking + goal-branch selection and returns a
joint trajectory from the current state to the pose. Pipeline: OMPL / RRTConnect -- the only
general pipeline configured on this stack (ompl | pilz | chomp; no STOMP). The scan works in
the known-free space above the table, so RRTConnect returns a near-straight path fast.

PLAN ONLY (``plan_only=True``). Execution is streamed through
``jtc_arm_motion.JtcArmMotion`` so there is one command path onto the combined
joint_trajectory_controller -- same as lbr_dual_arm_pdz_bringup's
fri_cartesian_impedance_plan_executor_node.
"""

import numpy as np
import rclpy
from geometry_msgs.msg import Pose, Point, Quaternion
from moveit_msgs.action import MoveGroup
from moveit_msgs.msg import (
    BoundingVolume,
    Constraints,
    JointConstraint,
    MotionPlanRequest,
    OrientationConstraint,
    PlanningOptions,
    PositionConstraint,
)
from rclpy.action import ActionClient
from scipy.spatial.transform import Rotation
from sensor_msgs.msg import JointState
from shape_msgs.msg import SolidPrimitive

# scan arm key -> (planning group, base frame, TCP tip link, ordered joint names) and the
# lbr_*_link_ee -> lbr_*_pdz_gripper_tcp offset (Rz(-90 deg) then +0.1355 m along Z).
# Moved to fixture_scan/robot_defs.py (2026-09-06 viewpoint-planner port) so these live in
# one place; re-imported here under their historical names. Literal fallback keeps
# arm_planner working if the fixture_scan package is not on sys.path (e.g. a minimal
# container stage that ships only fixture_relocation_scan/).
try:
    from fixture_scan.robot_defs import ARM as _ARM, T_EE_TCP as _T_EE_TCP
except ImportError:
    _ARM = {
        "hold": ("arm_one", "lbr_one_link_0", "lbr_one_pdz_gripper_tcp",
                 [f"lbr_one_A{i}" for i in range(1, 8)]),
        "move": ("arm_two", "lbr_two_link_0", "lbr_two_pdz_gripper_tcp",
                 [f"lbr_two_A{i}" for i in range(1, 8)]),
    }
    _T_EE_TCP = np.array([
        [0.0, 1.0, 0.0, 0.0],
        [-1.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 1.0, 0.1355],
        [0.0, 0.0, 0.0, 1.0],
    ])
_MOVEIT_SUCCESS = 1  # moveit_msgs/MoveItErrorCodes.SUCCESS

# The pdz fingertip END sits ~15 mm past the TCP (grasp centre) along the tool axis, so a TCP
# this high keeps the fingertip clear of the ~0.175 m free-space floor the user specified.
DEFAULT_MIN_TCP_Z_M = 0.19


class ArmPlanner:
    def __init__(self, node, robot_name="lbr_dual_arm", *,
                 planning_time_s=8.0, planning_attempts=20,
                 vel_scale=0.1, acc_scale=0.1,
                 pos_tol_m=0.015, ang_tol_rad=np.radians(20.0),
                 min_tcp_z_m=DEFAULT_MIN_TCP_Z_M):
        self._node = node
        self._log = node.get_logger()
        self._planning_time_s = float(planning_time_s)
        self._planning_attempts = int(planning_attempts)
        self._vel_scale = float(vel_scale)
        self._acc_scale = float(acc_scale)
        self._pos_tol_m = float(pos_tol_m)
        self._ang_tol_rad = float(ang_tol_rad)
        self._min_tcp_z_m = float(min_tcp_z_m)

        self._ac = ActionClient(node, MoveGroup, f"/{robot_name}/move_action")
        self._log.info("waiting for move_group /move_action ...")
        if not self._ac.wait_for_server(timeout_sec=15.0):
            raise RuntimeError(
                f"/{robot_name}/move_action not available after 15s -- is the namespaced "
                "move_group up? (ros2 launch lbr_dual_arm_pdz_bringup move_group_ns.launch.py "
                "mode:=hardware use_cartesian_impedance:=true)")

    def plan_to_flange_pose(self, role: str, T_base_flange: np.ndarray,
                            start_q=None, other_arm_q=None) -> np.ndarray:
        """Plan a collision-free joint path to the flange pose `T_base_flange` (4x4, in
        `role`'s arm base frame). The goal constraint is applied to the gripper TCP
        (= `T_base_flange @ _T_EE_TCP`); planning uses the arm_one/arm_two group. Returns
        (N,7) ndarray in ARM_JOINTS order. Raises on any planning failure, or if the implied
        TCP sits below the fingertip-clearance floor.

        Start state: ALWAYS a diff against move_group's monitored current state
        (`start_state.is_diff = True`) -- any joint not explicitly overridden keeps its
        current measured value, never 0. `start_q` None (default) and `other_arm_q` None:
        plan purely from the monitored state -- what the live scan does (each move begins
        where the last one left the robot). `start_q` (7-vector): override just `role`'s 7
        joints -- for offline/iterative planning where no robot is executing between
        segments, so the caller chains segment N's start to segment N-1's end
        (tools/plan_and_display.py). `other_arm_q` (7-vector): additionally override the
        idle arm's 7 joints -- used by the offline tool to reproduce the parked-idle-arm
        world that the live scan reaches for real via park_other_arm()."""
        group, base_frame, tip_link, joint_names = _ARM[role]

        T_base_tcp = np.asarray(T_base_flange, dtype=float) @ _T_EE_TCP
        if T_base_tcp[2, 3] < self._min_tcp_z_m:
            raise RuntimeError(
                f"[{role}] TCP z={T_base_tcp[2, 3]:.3f} m below the {self._min_tcp_z_m:.3f} m "
                f"fingertip-clearance floor -- raise the viewpoint")

        pos = Point(x=float(T_base_tcp[0, 3]),
                    y=float(T_base_tcp[1, 3]),
                    z=float(T_base_tcp[2, 3]))
        qx, qy, qz, qw = Rotation.from_matrix(T_base_tcp[:3, :3]).as_quat()
        quat = Quaternion(x=float(qx), y=float(qy), z=float(qz), w=float(qw))

        pcon = PositionConstraint()
        pcon.header.frame_id = base_frame
        pcon.link_name = tip_link
        region = BoundingVolume()
        region.primitives.append(
            SolidPrimitive(type=SolidPrimitive.SPHERE, dimensions=[self._pos_tol_m]))
        region.primitive_poses.append(Pose(position=pos, orientation=Quaternion(w=1.0)))
        pcon.constraint_region = region
        pcon.weight = 1.0

        ocon = OrientationConstraint()
        ocon.header.frame_id = base_frame
        ocon.link_name = tip_link
        ocon.orientation = quat
        ocon.absolute_x_axis_tolerance = self._ang_tol_rad
        ocon.absolute_y_axis_tolerance = self._ang_tol_rad
        ocon.absolute_z_axis_tolerance = self._ang_tol_rad
        ocon.weight = 1.0

        goal_constraints = Constraints()
        goal_constraints.position_constraints.append(pcon)
        goal_constraints.orientation_constraints.append(ocon)

        req = self._build_request(role, group, base_frame, joint_names,
                                  [goal_constraints], start_q, other_arm_q)
        return self._run_plan(
            role, req, joint_names,
            fail_ctx=(f"for TCP pos={np.round(T_base_tcp[:3, 3], 3).tolist()} "
                      f"in {base_frame}"))

    def plan_to_joint_config(self, role: str, q_target,
                             start_q=None, other_arm_q=None) -> np.ndarray:
        """Plan a collision-free joint path to the 7-vector joint config `q_target` for
        `role`'s arm, via the same move_group / RRTConnect path as `plan_to_flange_pose`.
        Returns (N,7) ndarray in ARM_JOINTS order.

        This is what `scan_fixture.park_other_arm` uses to move the idle arm to its plan's
        first waypoint: routing it through the planner (instead of a single measured->target
        joint goal streamed straight to the JTC) makes the park a dense, acceleration-
        continuous, collision-checked trajectory -- the same shape the executor node runs --
        so a large park delta can't drive the arm hard enough to trip a cabinet protective
        stop. `start_state` handling (`is_diff=True` always, optional `start_q`/`other_arm_q`
        per-joint overrides) matches `plan_to_flange_pose` exactly."""
        group, base_frame, _tip_link, joint_names = _ARM[role]
        q_target = np.asarray(q_target, dtype=float).reshape(-1)
        if q_target.shape != (7,):
            raise ValueError(f"q_target must be a 7-vector, got {q_target.shape}")

        goal_constraints = Constraints()
        for name, pos in zip(joint_names, q_target):
            goal_constraints.joint_constraints.append(JointConstraint(
                joint_name=name, position=float(pos),
                tolerance_above=1e-3, tolerance_below=1e-3, weight=1.0))

        req = self._build_request(role, group, base_frame, joint_names,
                                  [goal_constraints], start_q, other_arm_q)
        return self._run_plan(
            role, req, joint_names,
            fail_ctx=f"for joint goal {np.round(q_target, 3).tolist()}")

    # -- shared move_group plumbing ---------------------------------------------------------
    def _build_request(self, role, group, base_frame, joint_names,
                       goal_constraints_list, start_q, other_arm_q):
        req = MotionPlanRequest()
        req.group_name = group
        for gc in goal_constraints_list:
            req.goal_constraints.append(gc)
        req.num_planning_attempts = self._planning_attempts
        req.allowed_planning_time = self._planning_time_s
        req.max_velocity_scaling_factor = self._vel_scale
        req.max_acceleration_scaling_factor = self._acc_scale
        # is_diff=True ALWAYS: unspecified joints keep their monitored current value (never
        # snap to 0). start_q / other_arm_q only add per-joint overrides on top of that.
        req.start_state.is_diff = True
        names, positions = [], []
        if start_q is not None:
            names += list(joint_names)
            positions += [float(x) for x in np.asarray(start_q, dtype=float)]
        if other_arm_q is not None:
            other_role = "move" if role == "hold" else "hold"
            _, _, _, other_joints = _ARM[other_role]
            names += list(other_joints)
            positions += [float(x) for x in np.asarray(other_arm_q, dtype=float)]
        if names:
            req.start_state.joint_state = JointState(name=names, position=positions)
        req.workspace_parameters.header.frame_id = base_frame
        req.workspace_parameters.min_corner.x = -2.0
        req.workspace_parameters.min_corner.y = -2.0
        req.workspace_parameters.min_corner.z = -2.0
        req.workspace_parameters.max_corner.x = 2.0
        req.workspace_parameters.max_corner.y = 2.0
        req.workspace_parameters.max_corner.z = 2.0
        return req

    def _run_plan(self, role, req, joint_names, fail_ctx=""):
        goal = MoveGroup.Goal()
        goal.request = req
        goal.planning_options = PlanningOptions()
        goal.planning_options.plan_only = True
        goal.planning_options.planning_scene_diff.is_diff = True
        goal.planning_options.planning_scene_diff.robot_state.is_diff = True

        send_future = self._ac.send_goal_async(goal)
        rclpy.spin_until_future_complete(self._node, send_future)
        gh = send_future.result()
        if gh is None or not gh.accepted:
            raise RuntimeError(f"[{role}] move_group rejected the planning goal")
        result_future = gh.get_result_async()
        rclpy.spin_until_future_complete(self._node, result_future)
        result = result_future.result().result
        code = result.error_code.val
        if code != _MOVEIT_SUCCESS:
            raise RuntimeError(
                f"[{role}] planning failed (MoveItErrorCode {code}) "
                f"{fail_ctx}".rstrip())

        jt = result.planned_trajectory.joint_trajectory
        if not jt.points:
            raise RuntimeError(f"[{role}] planner returned an empty trajectory")
        try:
            idx = [list(jt.joint_names).index(j) for j in joint_names]
        except ValueError as exc:
            raise RuntimeError(
                f"[{role}] planned trajectory missing a joint: {exc} "
                f"(got {list(jt.joint_names)})") from exc
        path = np.array([[pt.positions[i] for i in idx] for pt in jt.points])
        dur = jt.points[-1].time_from_start
        self._log.info(
            f"[{role}] planned {len(path)} waypoints "
            f"(~{dur.sec + dur.nanosec / 1e9:.1f}s pre-retime)")
        return path
