"""Small, dependency-light readers for the offline plan artifacts (`motion.pkl`).

Split out of `scan_fixture.py` so both it and the offline MoveIt preview
(`tools/plan_and_display.py`) share one definition -- the preview must not import
`scan_fixture` (that pulls in cv2 / open3d, absent on the host / in the mock env).
Only stdlib + numpy here.
"""

import pickle

import numpy as np


def first_joint_waypoint(motion_pkl_path, motion_type):
    """The arm's very first commanded joint config in `motion.pkl` for `motion_type`
    ("hold" | "move") -- its 'init' entry's sole waypoint. This is the config
    `scan_fixture.park_other_arm` drives the idle arm to before the other arm scans, and
    the config the offline preview pins the idle arm at so its collision world matches.

    Returns a (7,) float ndarray. Raises LookupError if there is no such arm entry.
    """
    with open(motion_pkl_path, "rb") as fp:
        paths = pickle.load(fp)
    for entry_motion_type, body_type, path, _active_part, _task in paths:
        if entry_motion_type == motion_type and body_type == "arm":
            return np.asarray(path[0], dtype=float)
    raise LookupError(f"no {motion_type!r}/arm entry found in {motion_pkl_path}")
