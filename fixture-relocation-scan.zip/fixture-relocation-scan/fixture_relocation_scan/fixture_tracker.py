"""Live ArUco fixture pose tracker.

docs/live_fixture_relocation_implementation_plan.md (Fabrica-pdz), Deliverable 3. Subscribes
directly to the already-published RealSense + flange-pose topics -- no dependency on
Masterthesis-vision's BoardPoseNode/multicam_grabber. Topic names, message types, and QoS
confirmed live against Masterthesis-vision's own src/perception/ros/learn_runners/
camera_registry_realsense.py, src/calibration/flange_pose_store.py, and
src/perception/ros/qos_profiles.py.
"""

import numpy as np
import rclpy
import yaml
from geometry_msgs.msg import PoseStamped
from rclpy.node import Node
from rclpy.qos import HistoryPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import CameraInfo, Image

from fixture_relocation_scan.aruco_board_pose import solve_board_pose
from fixture_relocation_scan.depth_decode import (
    DepthFrame,
    depth_to_meters as _depth_to_meters,
    img_to_numpy_depth as _img_to_numpy_depth,
    stamp_to_sec as _stamp_to_sec,
)

# BEST_EFFORT, depth 1 -- matches Masterthesis-vision's qos_profile_sensor_data_low_latency,
# duplicated here (rather than imported) to keep this package's only Masterthesis-vision
# dependency the one deliberate exception (cartesian_impedance_dual_arm.py, used in
# scan_fixture.py), per the design doc's stated boundary.
QOS_SENSOR_DATA_LOW_LATENCY = QoSProfile(
    reliability=ReliabilityPolicy.BEST_EFFORT, history=HistoryPolicy.KEEP_LAST, depth=1,
)

# cam_id -> (rgb topic, camera_info topic), matching realsense2_camera's default namespacing
# (confirmed live: /realsense_1/camera/color/image_rect, /realsense_2/camera/color/image_rect).
CAMERA_TOPICS = {
    "realsense_1": ("/realsense_1/camera/color/image_rect", "/realsense_1/camera/color/camera_info"),
    "realsense_2": ("/realsense_2/camera/color/image_rect", "/realsense_2/camera/color/camera_info"),
}
# cam_id -> (flange pose topic, arm role) -- realsense_1/hold = left = lbr_one; realsense_2/move
# = right = lbr_two (confirmed live in flange_pose_store.py / camera_registry_realsense.py).
FLANGE_POSE_TOPICS = {
    "realsense_1": ("/left/ee_pose", "hold"),
    "realsense_2": ("/right/ee_pose", "move"),
}
# cam_id -> (aligned-depth topic, its camera_info). realsense2_camera publishes depth
# already warped into the color optical frame (align_depth.enable:=true), so the pixel
# grid matches color/image_rect and this camera_info's K is the correct intrinsic for
# backprojection -- confirmed against Masterthesis-vision's camera_registry_realsense.py.
CAMERA_DEPTH_TOPICS = {
    "realsense_1": ("/realsense_1/camera/aligned_depth_to_color/image_rect",
                    "/realsense_1/camera/aligned_depth_to_color/camera_info"),
    "realsense_2": ("/realsense_2/camera/aligned_depth_to_color/image_rect",
                    "/realsense_2/camera/aligned_depth_to_color/camera_info"),
}


def load_flange_to_camera(extrinsics_yaml_path, cam_id):
    """Own tiny loader for Masterthesis-vision/config/camera_extrinsics_realsense.yaml -- reads
    the file directly by path rather than importing src/calibration/io_extrinsics.py, per the
    design doc's stated boundary (single source of truth, no vendored copy to drift).
    YAML: {cam_id: {R: [9 row-major floats], t: [3 floats]}}, T_flange_cam (p_flange = R@p_cam+t).
    """
    with open(extrinsics_yaml_path, "r") as fp:
        data = yaml.safe_load(fp)
    entry = data[cam_id]
    T_flange_cam = np.eye(4)
    T_flange_cam[:3, :3] = np.array(entry["R"], dtype=float).reshape(3, 3)
    T_flange_cam[:3, 3] = np.array(entry["t"], dtype=float).reshape(3)
    return T_flange_cam


def _k_from_camerainfo(msg: CameraInfo) -> np.ndarray:
    return np.array(msg.k, dtype=float).reshape(3, 3)


def _img_to_numpy_bgr(msg: Image) -> np.ndarray:
    """Decode a color Image message to an OpenCV BGR array without cv_bridge -- mirrors
    handeye_flange_cam_realsense.py::_img_to_numpy_bgr (handles row padding + rgb/bgr/alpha)."""
    h, w = int(msg.height), int(msg.width)
    enc = msg.encoding.lower()
    if enc in ("rgb8", "bgr8"):
        channels = 3
    elif enc in ("bgra8", "rgba8"):
        channels = 4
    else:
        raise ValueError(f"Unsupported RGB encoding: {msg.encoding}")

    data = np.frombuffer(msg.data, dtype=np.uint8)
    step = int(msg.step)
    row_bytes = w * channels
    if step == row_bytes:
        img = data.reshape(h, w, channels)
    else:
        img = np.zeros((h, w, channels), dtype=np.uint8)
        for r in range(h):
            start = r * step
            img[r] = data[start:start + row_bytes].reshape(w, channels)

    if channels == 4:
        img = img[:, :, :3]
    if enc.startswith("rgb"):
        img = img[:, :, ::-1].copy()
    return img


def _pose_msg_to_matrix(msg: PoseStamped) -> np.ndarray:
    from scipy.spatial.transform import Rotation

    p = msg.pose.position
    q = msg.pose.orientation
    T = np.eye(4)
    T[:3, :3] = Rotation.from_quat([q.x, q.y, q.z, q.w]).as_matrix()
    T[:3, 3] = [p.x, p.y, p.z]
    return T


class ArucoFixtureTracker(Node):
    """Subscribes RGB/CameraInfo/flange-pose for one wrist camera and composes
    T_base_board = T_base_flange @ T_flange_cam @ T_cam_board, holding the last-known pose
    across dropouts. `board`/`dictionary` come from aruco_board_pose.load_board_from_nominal_pose.
    """

    def __init__(self, cam_id, extrinsics_yaml_path, board, dictionary, node_name=None,
                 subscribe_depth=False):
        if cam_id not in CAMERA_TOPICS:
            raise ValueError(f"cam_id must be one of {sorted(CAMERA_TOPICS)}, got {cam_id!r}")
        super().__init__(node_name or f"aruco_fixture_tracker_{cam_id}")

        self._board, self._dictionary = board, dictionary
        self._T_flange_cam = load_flange_to_camera(extrinsics_yaml_path, cam_id)
        self._K = None
        self._last_pose = None  # (T_base_board, reproj_err_px), most recent successful lock-on

        rgb_topic, info_topic = CAMERA_TOPICS[cam_id]
        flange_topic, self.arm_role = FLANGE_POSE_TOPICS[cam_id]
        self._latest_flange_T = None
        self._flange_stamp_s = None

        self.create_subscription(CameraInfo, info_topic, self._on_camera_info, QOS_SENSOR_DATA_LOW_LATENCY)
        self.create_subscription(PoseStamped, flange_topic, self._on_flange_pose, QOS_SENSOR_DATA_LOW_LATENCY)
        self.create_subscription(Image, rgb_topic, self._on_image, QOS_SENSOR_DATA_LOW_LATENCY)

        # Optional depth path -- only wired when a caller wants point clouds
        # (scan_fixture --capture-depth). Off by default so lock-on / report-only
        # runs add no extra bus load.
        self._depth_msg = None
        self._depth_stamp_s = None
        self._K_depth = None
        self._latest_rgb_bgr = None
        if subscribe_depth:
            depth_topic, depth_info_topic = CAMERA_DEPTH_TOPICS[cam_id]
            self.create_subscription(Image, depth_topic, self._on_depth, QOS_SENSOR_DATA_LOW_LATENCY)
            self.create_subscription(CameraInfo, depth_info_topic, self._on_depth_info, QOS_SENSOR_DATA_LOW_LATENCY)

    def _on_camera_info(self, msg):
        self._K = _k_from_camerainfo(msg)

    def _on_flange_pose(self, msg):
        self._latest_flange_T = _pose_msg_to_matrix(msg)
        self._flange_stamp_s = _stamp_to_sec(msg.header.stamp)

    def _on_depth(self, msg):
        self._depth_msg = msg
        self._depth_stamp_s = _stamp_to_sec(msg.header.stamp)

    def _on_depth_info(self, msg):
        self._K_depth = _k_from_camerainfo(msg)

    def _on_image(self, msg):
        if self._K is None or self._latest_flange_T is None:
            return
        try:
            img_bgr = _img_to_numpy_bgr(msg)
        except ValueError as exc:
            self.get_logger().debug(f"rgb decode failed: {exc}")
            return
        self._latest_rgb_bgr = img_bgr
        try:
            T_cam_board, _corners, reproj_err_px = solve_board_pose(img_bgr, self._K, self._board, self._dictionary)
        except (ValueError, RuntimeError) as exc:
            self.get_logger().debug(f"lock-on attempt failed: {exc}")
            return
        T_base_board = self._latest_flange_T @ self._T_flange_cam @ T_cam_board
        self._last_pose = (T_base_board, reproj_err_px)

    def get_latest_pose(self):
        """Returns (T_base_board, reproj_err_px), or None if never locked on."""
        return self._last_pose

    def grab_depth_frame(self):
        """Freshest synchronized depth capture as a DepthFrame, or None if the depth
        stream, its intrinsic, or the flange pose has not arrived yet. Does NOT
        backproject -- offline reconstruction (tools/build_scan_cloud.py) owns that."""
        if self._depth_msg is None or self._K_depth is None or self._latest_flange_T is None:
            return None
        raw = _img_to_numpy_depth(self._depth_msg)
        return DepthFrame(
            depth_raw=raw,
            depth_m=_depth_to_meters(raw, self._depth_msg.encoding),
            encoding=self._depth_msg.encoding,
            K_depth=self._K_depth.copy(),
            T_base_flange=self._latest_flange_T.copy(),
            T_flange_cam=self._T_flange_cam.copy(),
            stamp_depth=float(self._depth_stamp_s),
            stamp_flange=float(self._flange_stamp_s),
        )

    def get_latest_rgb_bgr(self):
        """Most recent decoded color frame (HxWx3 BGR uint8), or None."""
        return self._latest_rgb_bgr

    @property
    def flange_to_camera(self):
        """4x4 T_flange_cam for this tracker's camera (from camera_extrinsics_realsense.yaml)."""
        return self._T_flange_cam
