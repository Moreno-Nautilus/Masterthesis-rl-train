"""Wrist look-at target construction.

docs/live_fixture_relocation_implementation_plan.md (Fabrica-pdz), Deliverable 3. Pure math, no
ROS -- builds an ArmTarget whose camera axis points at a world/board target, honoring the
flange->camera and flange->fingertip offsets so *fingertip* clearance (not camera clearance) is
what's checked against the minimum standoff.

Geometric assumption (undocumented elsewhere, needs confirming against the real gripper CAD
before hardware use): the fingertip is taken to sit purely along the flange's own local +Z
(tool/approach) axis, FLANGE_TO_FINGERTIP_M ahead of the flange -- the flange pose is solved
purely from that offset and the requested fingertip standoff. Only T_flange_cam's *rotation* is
used, to orient the flange so the camera's optical axis (whatever direction that rotates to)
still points at the target regardless of any lateral camera mount offset; the camera's own
translation offset does not otherwise affect where the flange is placed. This is a
simplification, not a verified fact about the real gripper mount.
"""

import numpy as np

# user-provided figure (docs/live_fixture_relocation_plan.md), not derived from any repo file:
# flange -> gripper fingertip distance along the tool axis.
FLANGE_TO_FINGERTIP_M = 0.1505

_ARM_KEY_TO_GROUP = {
    "hold": ("arm_one_flange", "lbr_one_link_0", "lbr_one_link_ee"),
    "move": ("arm_two_flange", "lbr_two_link_0", "lbr_two_link_ee"),
}


def _normalize(v):
    n = np.linalg.norm(v)
    if n < 1e-9:
        raise ValueError("cannot normalize a near-zero vector")
    return v / n


def solve_look_at_flange_pose(target_pos, camera_pos_hint, T_flange_cam, fingertip_standoff_m, up_hint=(0.0, 0.0, 1.0)):
    """Solve for a flange pose (4x4, in the arm's own base frame) whose camera axis (+Z, OpenCV
    optical convention) points at `target_pos`, with the *fingertip* -- not the camera -- held
    `fingertip_standoff_m` away from `target_pos` along that same axis.

    `camera_pos_hint` picks which side of the target the flange approaches from (only its
    direction relative to `target_pos` matters, its distance is discarded and replaced by the
    solved standoff distance). All positions/vectors in the same (arm base) frame.
    Returns a 4x4 np.ndarray T_armBase_flange.
    """
    target_pos = np.asarray(target_pos, dtype=float)
    camera_pos_hint = np.asarray(camera_pos_hint, dtype=float)
    up_hint = np.asarray(up_hint, dtype=float)

    view_dir = _normalize(target_pos - camera_pos_hint)  # camera's +Z axis, world/base frame

    # view_dir (near) parallel to up_hint -- e.g. the camera looking straight down at the
    # fixture from directly above -- makes cross(up_hint, view_dir) degenerate. Fall back to an
    # alternate reference axis; the resulting roll about the optical axis is then arbitrary but
    # valid (neither the IK nor the ArUco board solve constrains camera roll).
    if np.linalg.norm(np.cross(up_hint, view_dir)) < 1e-6:
        up_hint = np.array([1.0, 0.0, 0.0])
        if np.linalg.norm(np.cross(up_hint, view_dir)) < 1e-6:
            up_hint = np.array([0.0, 1.0, 0.0])

    right = _normalize(np.cross(up_hint, view_dir))
    true_up = np.cross(view_dir, right)
    R_cam = np.column_stack([right, true_up, view_dir])

    R_flange_cam = T_flange_cam[:3, :3]
    R_flange = R_cam @ R_flange_cam.T

    # Both the camera and the fingertip sit ahead of the flange along the tool axis (+view_dir,
    # toward the target); only the fingertip's offset matters for where the flange itself goes
    # -- the camera's own offset only affects how far *it* ends up from the target (checked by
    # the caller if framing distance matters), not the flange placement solved here.
    flange_to_target_along_axis = fingertip_standoff_m + FLANGE_TO_FINGERTIP_M
    flange_pos = target_pos - view_dir * flange_to_target_along_axis

    T_flange = np.eye(4)
    T_flange[:3, :3] = R_flange
    T_flange[:3, 3] = flange_pos
    return T_flange


def flange_matrix_to_arm_target(arm_key, T_armBase_flange):
    """Wrap a 4x4 T_armBase_flange as a Masterthesis-vision ArmTarget for the bare flange
    (no gripper), for use with CartesianImpedanceDualArmClient.move_to_cartesian."""
    from src.calibration.cartesian_impedance_dual_arm import ArmTarget
    from src.utils.se3 import SE3

    if arm_key not in _ARM_KEY_TO_GROUP:
        raise ValueError(f"arm_key must be one of {sorted(_ARM_KEY_TO_GROUP)}, got {arm_key!r}")
    group_name, base_frame, tip_link = _ARM_KEY_TO_GROUP[arm_key]
    return ArmTarget(
        group_name=group_name, base_frame=base_frame, tip_link=tip_link,
        T_armBase_flange=SE3.from_matrix(T_armBase_flange),
    )
