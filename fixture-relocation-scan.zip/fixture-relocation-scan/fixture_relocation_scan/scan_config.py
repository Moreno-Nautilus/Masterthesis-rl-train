"""Scan viewpoint geometry -- the single source of truth shared by the live scan
(`scan_fixture.py`) and the offline MoveIt preview (`tools/plan_and_display.py`).

Kept dependency-light (stdlib + numpy only) precisely so the preview can import it without
pulling in `scan_fixture`'s cv2 / open3d. Anything here that changes -- orbit height, radii,
standoff -- changes both paths at once; that is the point. Do NOT re-declare these in the
preview.
"""

import os

MIN_FINGERTIP_STANDOFF_M = 0.05
# (near_delta, far_delta) added to MIN_FINGERTIP_STANDOFF_M -> the two orbit radii.
NEAR_FAR_RADII_M = (0.20, 0.5)
# Camera-viewpoint height above the board for the approach + orbit half-circles. Sets how
# steeply the camera looks down; must be high enough that the planned gripper TCP clears
# ArmPlanner's fingertip-clearance floor (~0.19 m) given the board sits near table level.
ORBIT_HEIGHT_M = 0.4

# scan arm role -> wrist camera id (realsense2_camera namespacing; hold = left = lbr_one).
ARM_TO_CAM_ID = {"hold": "realsense_1", "move": "realsense_2"}

DEFAULT_EXTRINSICS_YAML = os.environ.get(
    "CAMERA_EXTRINSICS_YAML",
    os.path.expanduser("~/Masterthesis-vision/config/camera_extrinsics_realsense.yaml"),
)


def build_orbit_radii(min_fingertip_standoff_m=MIN_FINGERTIP_STANDOFF_M):
    return tuple(min_fingertip_standoff_m + delta for delta in NEAR_FAR_RADII_M)
