"""Dependency-light depth-image decoding for the fixture scan.

Split out of fixture_tracker.py (which pulls in rclpy / sensor_msgs) so the decode logic
stays unit-testable on the host with no ROS sourced -- same rationale as scan_config.py /
plan_inputs.py. The two decoders mirror
Masterthesis-vision/src/perception/ros/multicam_grabber.py (_img_to_numpy_depth /
_depth_to_meters); duplicated, not imported, to keep this package's Masterthesis-vision
coupling to the one deliberate exception per the design doc's boundary.
"""

from dataclasses import dataclass

import numpy as np


def stamp_to_sec(stamp) -> float:
    """ROS Time message -> float seconds."""
    return float(stamp.sec) + float(stamp.nanosec) * 1e-9


def img_to_numpy_depth(msg) -> np.ndarray:
    """Decode a depth Image message into an HxW array, handling row padding (step).
    `msg` only needs .height/.width/.encoding/.step/.data (duck-typed for tests)."""
    h, w = int(msg.height), int(msg.width)
    enc = msg.encoding
    if enc == "32FC1":
        dtype, elem_size = np.float32, 4
    elif enc == "16UC1":
        dtype, elem_size = np.uint16, 2
    else:
        raise ValueError(f"Unsupported depth Image encoding: {enc}")
    data = np.frombuffer(msg.data, dtype=dtype)
    step_elems = int(msg.step // elem_size)
    if step_elems == w:
        return data.reshape(h, w)
    out = np.zeros((h, w), dtype=dtype)
    for r in range(h):
        out[r, :] = data[r * step_elems:r * step_elems + w]
    return out


def depth_to_meters(depth: np.ndarray, encoding: str) -> np.ndarray:
    """Raw depth -> metres: 32FC1 already metres, 16UC1 millimetres."""
    if encoding == "32FC1":
        return depth.astype(np.float32)
    if encoding == "16UC1":
        return depth.astype(np.float32) * 1e-3
    raise ValueError(f"Unsupported depth encoding: {encoding}")


@dataclass
class DepthFrame:
    """One synchronized depth capture -- raw arrays + the frame chain needed to
    backproject offline. No Open3D, no processing (see scan_fixture.dwell_and_capture and
    tools/build_scan_cloud.py)."""
    depth_raw: np.ndarray        # HxW, as received (uint16 mm or float32 m)
    depth_m: np.ndarray          # HxW float32, metres
    encoding: str                # "16UC1" | "32FC1"
    K_depth: np.ndarray          # (3,3) intrinsic of the aligned-depth image
    T_base_flange: np.ndarray    # (4,4) freshest flange pose in the arm base frame
    T_flange_cam: np.ndarray     # (4,4) static hand-eye extrinsic
    stamp_depth: float           # seconds
    stamp_flange: float          # seconds
