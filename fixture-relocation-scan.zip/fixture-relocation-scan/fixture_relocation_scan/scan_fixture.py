#!/usr/bin/env python3
"""Live fixture relocation scan entry point.

docs/live_fixture_relocation_implementation_plan.md (Fabrica-pdz), Deliverable 3. Locates the
ArUco pickup fixture live via a wrist camera, scans it into a point cloud, and writes
fixture_pose_correction.json -- the only output the rest of the system (Fabrica-pdz's
planning/patch_motion_for_fixture_correction.py, run online by lbr_dual_arm_pdz_bringup's
tools/run_corrected_plan.sh) consumes. Never writes pickup.json or motion.pkl: "offline
generated plans should not be changed."

This is the only file in this package that commands real robot motion -- via arm_planner
(move_group plans the idle-arm park) and jtc_arm_motion (streams joint-position waypoints to
the combined joint_trajectory_controller, the KUKA cabinets running FRI
CARTESIAN_IMPEDANCE_CONTROL underneath -- same command path as lbr_dual_arm_pdz_bringup's
fri_cartesian_impedance_plan_executor_node). Per this project's safety practice, do not run
this against a live rig without a human present and confirming it's safe to move.

The scanning viewpoints + the collision-free joint trajectories between them come from the
tested fixture_scan viewpoint planner (fixture_scan/pipeline.py::run_full_plan), reached
either as a pre-staged scan_program.json (--scan-program) or planned in-process here
(--plan-viewpoints, via fixture_scan.plan_scan). There is no ad-hoc orbit path.

6 steps, matching the design doc:
  1. park the OTHER arm at its plan's first joint waypoint from motion.pkl (out of the way).
  2. (--plan-viewpoints) run the viewpoint planner in-process from the post-park measured
     state; then drive to planned viewpoint 0 and lock on to a marker for the pose estimate.
  3. average several locked-on samples for a stable pose estimate, then replay the planned
     per-viewpoint trajectories, dwelling at each to dump one raw depth frame (no
     processing on this side).
  4. save <arm>_board_pose.json + <arm>_depth_capture/ (raw .npz frames + manifest.json);
     the host-side tools/build_scan_cloud.py turns the frames into <arm>_pointcloud.ply
     offline (filter -> backproject -> arm base frame -> voxel-average).
  5. --both: combine hold's and move's board poses into the SE(2) (dx, dy, dyaw) world-frame
     delta plus both cloud paths, written to fixture_pose_correction.json.
  6. --report-only: stop after the first lock-on, as a frame-chain sanity check.
"""

import argparse
import json
import os
import sys
import time

import numpy as np
import rclpy
from scipy.spatial.transform import Rotation

sys.path.insert(0, os.environ.get("MASTERTHESIS_VISION_DIR", os.path.expanduser("~/Masterthesis-vision")))

from fixture_relocation_scan.aruco_board_pose import load_board_from_nominal_pose
from fixture_relocation_scan.arm_planner import ArmPlanner
from fixture_relocation_scan.fixture_tracker import ArucoFixtureTracker
from fixture_relocation_scan.jtc_arm_motion import JtcArmMotion
from fixture_relocation_scan.plan_inputs import first_joint_waypoint
from fixture_relocation_scan.scan_config import ARM_TO_CAM_ID, DEFAULT_EXTRINSICS_YAML

DEFAULT_OUT_DIR = os.path.expanduser(
    "~/Fabrica-pdz/logs/kuka_pdz8_cm_aruco/plumbers_block_new_3/fixture/"
)

LOCK_ON_TIMEOUT_S = 5.0
LOCK_ON_POLL_S = 0.1
LOCK_ON_SEARCH_STEPS = (0.0, 0.05, -0.05, 0.10, -0.10)  # widening XY nudges, meters, if nominal misses


def park_other_arm(motion, planner, motion_pkl_path, scanning_arm):
    """Move the arm NOT doing the scan to its plan's first joint waypoint, out of the way.

    The park target can be far from wherever the idle arm is currently sitting; a single
    measured->target joint goal streamed straight to the JTC is one long rest-to-rest
    segment that can drive the arm hard enough to trip a cabinet protective stop. So plan
    it through move_group (dense, collision-checked, acceleration-continuous) exactly like
    the approach/orbit moves and the executor node -- `move_arm_to_joints` then just
    re-times and streams that path. Falls back to the direct joint goal only if no planner
    is available (e.g. a caller that constructs `motion` without `planner`)."""
    other_arm = "move" if scanning_arm == "hold" else "hold"
    q_active = first_joint_waypoint(motion_pkl_path, other_arm)
    if planner is not None:
        path = planner.plan_to_joint_config(other_arm, q_active)
    else:
        path = q_active
    motion.move_arm_to_joints(
        other_arm, path, description=f"park {other_arm} arm for {scanning_arm} scan")


def lock_on(tracker, target_pos_xy, timeout_s=LOCK_ON_TIMEOUT_S, search_steps=LOCK_ON_SEARCH_STEPS):
    """Spin the tracker's node while nudging the reported target (informational only -- the
    camera has already been physically pointed at target_pos_xy by the caller; this widening
    search is for logging/diagnosis, since lock-on itself only depends on what's actually in
    frame) until a pose is available or timeout_s elapses. Returns (T_base_board, reproj_err_px).
    """
    del target_pos_xy, search_steps  # informational only; see docstring
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        rclpy.spin_once(tracker, timeout_sec=LOCK_ON_POLL_S)
        pose = tracker.get_latest_pose()
        if pose is not None:
            return pose
    raise TimeoutError(f"no ArUco lock-on within {timeout_s}s")


def average_pose(tracker, n_samples=10, sample_interval_s=0.1):
    samples = []
    for _ in range(n_samples):
        rclpy.spin_once(tracker, timeout_sec=sample_interval_s)
        pose = tracker.get_latest_pose()
        if pose is not None:
            samples.append(pose[0])
    if not samples:
        raise RuntimeError("lost lock-on while averaging")
    positions = np.mean([T[:3, 3] for T in samples], axis=0)
    rotations = Rotation.from_matrix([T[:3, :3] for T in samples])
    mean_rotation = rotations.mean().as_matrix()
    T_mean = np.eye(4)
    T_mean[:3, :3] = mean_rotation
    T_mean[:3, 3] = positions
    return T_mean


def dwell_and_capture(tracker, cap_dir, frame_index, vp_index, marker_id, T_base_board,
                      dwell_s=0.5, n_frames=1, save_color=True):
    """Hold still for `dwell_s` (the arm is already stopped at the waypoint), then grab
    `n_frames` depth frames and write frame_{frame_index:03d}.npz (+ color_*.png). With
    n_frames>1 the per-pixel depth is median-stacked to cut speckle. Returns a small record
    dict for the run manifest, or None if the depth stream is unavailable (warn, don't
    raise -- a scan that still yields a board pose beats one that aborts)."""
    deadline = time.monotonic() + max(dwell_s, 0.0)
    stack = []
    ref = None
    while time.monotonic() < deadline or not stack:
        rclpy.spin_once(tracker, timeout_sec=0.05)
        frame = tracker.grab_depth_frame()
        if frame is None:
            if time.monotonic() >= deadline:
                break
            continue
        ref = frame
        # 0 = "no reading" for 16UC1 -- NaN it so the median ignores dropout pixels
        stack.append(np.where(frame.depth_m > 0, frame.depth_m, np.nan))
        if len(stack) >= n_frames and time.monotonic() >= deadline:
            break
    if ref is None:
        print(f"[{tracker.arm_role}] no depth frame at vp {vp_index} (stream absent) -- "
              f"skipping capture", file=sys.stderr)
        return None

    with np.errstate(invalid="ignore"):
        depth_m = (stack[0] if len(stack) == 1
                   else np.nanmedian(np.stack(stack), axis=0)).astype(np.float32)
    T_base_cam = ref.T_base_flange @ ref.T_flange_cam
    valid = np.isfinite(depth_m) & (depth_m > 0)
    npz_name = f"frame_{frame_index:03d}.npz"
    np.savez_compressed(
        os.path.join(cap_dir, npz_name),
        depth_raw=ref.depth_raw,
        depth_m=depth_m.astype(np.float32),
        encoding=ref.encoding,
        K_depth=ref.K_depth,
        T_base_flange=ref.T_base_flange,
        T_flange_cam=ref.T_flange_cam,
        T_base_cam=T_base_cam,
        T_base_board=np.asarray(T_base_board, dtype=float),
        stamp_depth=ref.stamp_depth,
        stamp_flange=ref.stamp_flange,
        dt_sync=abs(ref.stamp_depth - ref.stamp_flange),
        vp_index=vp_index,
        marker_id=-1 if marker_id is None else marker_id,
        arm=tracker.arm_role,
        n_stacked=len(stack),
    )
    color_name = None
    if save_color:
        rgb = tracker.get_latest_rgb_bgr()
        if rgb is not None:
            try:
                import cv2
                color_name = f"color_{frame_index:03d}.png"
                cv2.imwrite(os.path.join(cap_dir, color_name), rgb)
            except Exception as exc:  # cv2 missing / write failure -- color is optional
                print(f"[{tracker.arm_role}] color save skipped: {exc}", file=sys.stderr)
                color_name = None
    return {
        "file": npz_name,
        "color_file": color_name,
        "vp_index": vp_index,
        "marker_id": -1 if marker_id is None else int(marker_id),
        "dt_sync_s": float(abs(ref.stamp_depth - ref.stamp_flange)),
        "n_stacked": len(stack),
        "n_valid_px": int(valid.sum()),
        "depth_min_m": float(depth_m[valid].min()) if valid.any() else None,
        "depth_median_m": float(np.median(depth_m[valid])) if valid.any() else None,
    }


def run_single_arm_scan(arm_key, nominal_pose_path, motion_pkl_path, extrinsics_yaml_path,
                        out_dir, report_only=False, motion=None, planner=None,
                        scan_program_path=None, plan_viewpoints=False, client_node=None,
                        intrinsics_yaml=None, intrinsics_source="auto", plan=None,
                        robot_name="lbr_dual_arm", capture_depth=False, dwell_s=0.5,
                        depth_frames_per_viewpoint=1, save_color=True,
                        capture_only_current=False):
    """The scanning viewpoints + the collision-free joint trajectories between them come
    from the fixture_scan viewpoint planner (`fixture_scan/pipeline.py::run_full_plan`),
    reached one of two ways:

      `scan_program_path`  -- a pre-staged `scan_program.json` (host two-step). Per
        impl-plan §7 the scanning arm must NOT be moved between generating it and this run
        (viewpoint 0's trajectory is the lead-in from that q_current).
      `plan_viewpoints`    -- run the planner IN-PROCESS here, from the post-park measured
        scanning-arm state, via `fixture_scan.plan_scan.plan_scan_program` (needs
        `client_node` for the live joint_states / camera_info reads). One planning code
        path shared with the host CLI.

    Exactly one of the two is required whenever a motion backend is given. Everything
    downstream (drive to viewpoint 0, lock-on, averaging, per-viewpoint replay, output
    files) is identical for both.

    `capture_depth`: at each waypoint dwell `dwell_s` (arm held still) and dump one raw
    depth frame (median of `depth_frames_per_viewpoint`) + optional color into
    <out_dir>/<arm>_depth_capture/. No filtering / backprojection here -- the host-side
    tools/build_scan_cloud.py reconstructs <arm>_pointcloud.ply offline.
    `capture_only_current`: no motion, grab a single frame at the current pose (bus /
    frame-chain sanity check) and return."""
    cam_id = ARM_TO_CAM_ID[arm_key]
    board, dictionary, _marker_len_m = load_board_from_nominal_pose(nominal_pose_path)
    want_depth = capture_depth or capture_only_current

    if motion is not None and scan_program_path is None and not plan_viewpoints:
        raise ValueError(
            "a scan with motion needs the viewpoint plan: pass --scan-program "
            "<scan_program.json> or --plan-viewpoints (plan it in-process)")
    if scan_program_path is not None and plan_viewpoints:
        raise ValueError("--scan-program and --plan-viewpoints are mutually exclusive")

    program = None
    if scan_program_path is not None:
        from fixture_scan.scan_program import load_program
        program = load_program(scan_program_path)
        if program.role != arm_key:
            raise ValueError(
                f"scan_program is for arm_role={program.role!r}, not {arm_key!r}")

    if not rclpy.ok():
        rclpy.init(args=None)
    tracker = ArucoFixtureTracker(cam_id, extrinsics_yaml_path, board, dictionary,
                                  subscribe_depth=want_depth)
    cap_dir = os.path.join(out_dir or DEFAULT_OUT_DIR, f"{arm_key}_depth_capture")
    try:
        with open(nominal_pose_path, "r") as fp:
            nominal = json.load(fp)
        nominal_board_pos = np.array(nominal["board_origin"]["lbr_one_link_0" if arm_key == "hold" else "lbr_two_link_0"]["position_m"])

        if capture_only_current:
            os.makedirs(cap_dir, exist_ok=True)
            for _ in range(50):  # ~2.5 s to let depth/info/flange buffers fill
                rclpy.spin_once(tracker, timeout_sec=0.05)
                if tracker.grab_depth_frame() is not None:
                    break
            last = tracker.get_latest_pose()
            T_ref = last[0] if last is not None else np.eye(4)
            rec = dwell_and_capture(tracker, cap_dir, 0, -1, None, T_ref,
                                    dwell_s=dwell_s, n_frames=depth_frames_per_viewpoint,
                                    save_color=save_color)
            return {"arm": arm_key, "capture_dir": cap_dir, "frame": rec}

        if motion is not None:
            park_other_arm(motion, planner, motion_pkl_path, arm_key)
            if plan_viewpoints and program is None:
                # Run the tested viewpoint planner in-process from the post-park measured
                # scanning-arm state -- same pipeline the host `run_viewpoint_planner` uses.
                from fixture_scan import plan_scan
                from fixture_scan.scan_program import program_from_dict
                program_dict, res = plan_scan.plan_scan_program(
                    arm_key, robot_name=robot_name, nominal_pose=nominal_pose_path,
                    motion_pkl=motion_pkl_path, intrinsics_yaml=intrinsics_yaml,
                    extrinsics_yaml=extrinsics_yaml_path, plan=plan,
                    intrinsics_source=intrinsics_source, node=client_node,
                    q_current=motion.current_arm_q(arm_key),
                    log=lambda m: print(f"[{arm_key}] {m}"))
                if program_dict is None:
                    raise RuntimeError(
                        f"[{arm_key}] viewpoint planning produced no collision-free "
                        f"program: {res.get('trajectory_error')}")
                program = program_from_dict(program_dict)
                print(f"[{arm_key}] planned {len(program.viewpoints)} viewpoints, tiers "
                      f"{[v.traj_tier for v in program.viewpoints]}")
            # drive to the first planned viewpoint (its trajectory is the lead-in from
            # q_current) to frame a marker for lock-on.
            motion.move_arm_to_joints(
                arm_key, program.viewpoints[0].trajectory,
                description=f"{arm_key} scan_program viewpoint 0 (lock-on frame)")

        T_base_board, reproj_err_px = lock_on(tracker, nominal_board_pos[:2])
        if report_only:
            return {"arm": arm_key, "T_base_board": T_base_board.tolist(), "reproj_err_px": reproj_err_px}

        T_base_board = average_pose(tracker)

        # One raw depth frame per waypoint. dwell_and_capture holds still `dwell_s` first
        # (arm already stopped), then dumps frame_NNN.npz; the host-side
        # tools/build_scan_cloud.py filters + backprojects + merges them offline.
        frames = []
        if capture_depth:
            os.makedirs(cap_dir, exist_ok=True)

        def _capture(vp_index, marker_id):
            if not capture_depth:
                rclpy.spin_once(tracker, timeout_sec=dwell_s)
                return
            rec = dwell_and_capture(
                tracker, cap_dir, len(frames), vp_index, marker_id, T_base_board,
                dwell_s=dwell_s, n_frames=depth_frames_per_viewpoint, save_color=save_color)
            if rec is not None:
                frames.append(rec)

        if motion is not None and program is not None:
            for vp in program.viewpoints[1:]:
                motion.move_arm_to_joints(
                    arm_key, vp.trajectory,
                    description=f"{arm_key} scan_program viewpoint {vp.index} "
                               f"(marker {vp.marker_id}, {vp.traj_tier})")
                _capture(vp.index, vp.marker_id)

        out_dir = out_dir or DEFAULT_OUT_DIR
        os.makedirs(out_dir, exist_ok=True)
        cloud_path = os.path.join(out_dir, f"{arm_key}_pointcloud.ply")  # produced offline
        if capture_depth:
            manifest = {
                "arm": arm_key,
                "cam_id": cam_id,
                "nominal_pose_path": os.path.abspath(nominal_pose_path),
                "extrinsics_path": os.path.abspath(extrinsics_yaml_path),
                "scan_program_path": os.path.abspath(scan_program_path) if scan_program_path else None,
                "dwell_s": dwell_s,
                "depth_frames_per_viewpoint": depth_frames_per_viewpoint,
                "board_pose_used": {"T_base_board": T_base_board.tolist(),
                                    "reproj_err_px": reproj_err_px},
                "expected_cloud_path": cloud_path,
                "n_frames": len(frames),
                "frames": frames,
            }
            with open(os.path.join(cap_dir, "manifest.json"), "w") as fp:
                json.dump(manifest, fp, indent=2)
            print(f"[{arm_key}] captured {len(frames)} depth frame(s) -> {cap_dir}")
        pose_path = os.path.join(out_dir, f"{arm_key}_board_pose.json")
        with open(pose_path, "w") as fp:
            json.dump({"T_base_board": T_base_board.tolist(), "reproj_err_px": reproj_err_px}, fp, indent=2)
        return {"arm": arm_key, "T_base_board": T_base_board, "cloud_path": cloud_path,
                "pose_path": pose_path, "capture_dir": cap_dir if capture_depth else None}
    finally:
        tracker.destroy_node()
        if motion is None and rclpy.ok():
            rclpy.shutdown()


def combine_into_correction(hold_result, move_result, nominal_pose_path, out_dir):
    """SE(2) (dx, dy, dyaw) world-frame delta between the fixture's real and nominal pose,
    averaged from both arms' independent board-pose estimates."""
    with open(nominal_pose_path, "r") as fp:
        nominal = json.load(fp)
    nominal_world_pos = np.array(nominal["board_origin"]["world"]["position_m"])
    nominal_world_quat_wxyz = nominal["board_origin"]["world"]["quaternion_wxyz"]
    nominal_yaw = Rotation.from_quat(
        [nominal_world_quat_wxyz[1], nominal_world_quat_wxyz[2], nominal_world_quat_wxyz[3], nominal_world_quat_wxyz[0]]
    ).as_euler("xyz")[2]

    deltas = []
    for result, arm_key in ((hold_result, "hold"), (move_result, "move")):
        T = result["T_base_board"]
        base_frame_pos_in_world = np.array(
            nominal["board_origin"]["lbr_one_link_0" if arm_key == "hold" else "lbr_two_link_0"]["position_m"]
        )
        # arm base frames share world's rotation (pure translation offset, per
        # fixture_world_frame's board_to_arm_base_transform) -- board position in world is the
        # arm-base-frame position plus that fixed offset.
        world_pos = T[:3, 3] + (nominal_world_pos - base_frame_pos_in_world)
        world_yaw = Rotation.from_matrix(T[:3, :3]).as_euler("xyz")[2]
        deltas.append((world_pos[:2] - nominal_world_pos[:2], world_yaw - nominal_yaw))

    dxy = np.mean([d[0] for d in deltas], axis=0)
    dyaw = float(np.mean([d[1] for d in deltas]))
    correction = {
        "dx_m": float(dxy[0]), "dy_m": float(dxy[1]), "dyaw_rad": dyaw,
        "hold_pose_path": hold_result["pose_path"], "move_pose_path": move_result["pose_path"],
        "hold_cloud_path": hold_result["cloud_path"], "move_cloud_path": move_result["cloud_path"],
    }
    out_path = os.path.join(out_dir or DEFAULT_OUT_DIR, "fixture_pose_correction.json")
    with open(out_path, "w") as fp:
        json.dump(correction, fp, indent=2)
    return out_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", choices=["hold", "move"])
    parser.add_argument("--both", action="store_true")
    parser.add_argument("--report-only", action="store_true")
    parser.add_argument("--nominal-pose", default=os.path.join(DEFAULT_OUT_DIR, "nominal_world_pose.json"))
    parser.add_argument("--motion-pkl", default=os.path.expanduser(
        "~/Fabrica-pdz/logs/kuka_pdz8_cm_aruco/plumbers_block_new_3/motion.pkl"))
    parser.add_argument("--extrinsics-yaml", default=DEFAULT_EXTRINSICS_YAML)
    parser.add_argument("--out-dir", default=None)
    viewpoints = parser.add_mutually_exclusive_group()
    viewpoints.add_argument("--scan-program", default=None,
                            help="pre-staged fixture_scan viewpoint-planner output "
                                 "(scan_program.json), from the host `run_viewpoint_planner` "
                                 "two-step. For --both, points at hold's program; move's is "
                                 "expected at the same path with _move before .json, or pass "
                                 "--scan-program per single-arm run.")
    viewpoints.add_argument("--plan-viewpoints", action="store_true",
                            help="run the fixture_scan viewpoint planner IN-PROCESS here "
                                 "(after the idle-arm park, from the measured scanning-arm "
                                 "state) instead of staging a scan_program.json -- same "
                                 "planning pipeline, one container command.")
    parser.add_argument("--intrinsics-yaml", default=None,
                        help="camera intrinsics YAML for --plan-viewpoints (default: "
                             "fixture_scan.config.DEFAULT_INTRINSICS_YAML); only a fallback "
                             "when the wrist camera's live camera_info is unavailable")
    parser.add_argument("--intrinsics-source", choices=["auto", "camera_info", "yaml"],
                        default="auto",
                        help="--plan-viewpoints intrinsics: auto (live camera_info else "
                             "YAML), camera_info (require live), yaml (always the file)")
    parser.add_argument("--plan", default=None,
                        help="plan label recorded in the generated scan_program meta "
                             "(--plan-viewpoints only)")
    parser.add_argument("--no-motion", action="store_true",
                        help="lock-on/report only, never move the robot (no arm-motion "
                             "backend is constructed)")
    parser.add_argument("--capture-depth", dest="capture_depth", action="store_true",
                        default=None,
                        help="dwell at each waypoint and dump one raw depth frame into "
                             "<out-dir>/<arm>_depth_capture/ for offline reconstruction "
                             "by tools/build_scan_cloud.py (default: on when moving)")
    parser.add_argument("--no-capture-depth", dest="capture_depth", action="store_false",
                        help="disable per-waypoint depth capture")
    parser.add_argument("--dwell-s", type=float, default=0.5,
                        help="seconds to hold still at each waypoint before grabbing depth "
                             "(default %(default)s; 0.75-1.0 recommended on the real rig -- "
                             "FRI cartesian impedance may not fully settle in 0.5 s)")
    parser.add_argument("--depth-frames-per-viewpoint", type=int, default=1,
                        help="median-stack this many depth frames per waypoint to cut "
                             "speckle (default %(default)s)")
    parser.add_argument("--no-save-color", dest="save_color", action="store_false",
                        help="skip the color_NNN.png alongside each depth frame")
    parser.add_argument("--capture-only-current", action="store_true",
                        help="no motion: grab a single depth frame at the current pose "
                             "(bus / frame-chain sanity check) and exit")
    parser.add_argument("--robot-name", default="lbr_dual_arm",
                        help="controller_manager / joint_states / move_group namespace "
                             "(default: %(default)s)")
    parser.add_argument("--jtc-time-scale", type=float, default=1.0,
                        help="global multiplier (>=1) on every JTC segment duration after the "
                             "velocity/accel bounds -- slows the whole scan. Mainly a safety "
                             "margin for the FIRST viewpoint seam, which is measured-anchored "
                             "(no prior commanded config to stay continuous with); later seams "
                             "are anchored on the last commanded config. Default %(default)s.")
    args = parser.parse_args()
    if not args.arm and not args.both:
        parser.error("pass --arm {hold,move} or --both")
    if args.plan_viewpoints and (args.no_motion or args.report_only
                                 or args.capture_only_current):
        parser.error("--plan-viewpoints plans + moves; it is incompatible with "
                     "--no-motion / --report-only / --capture-only-current")

    intrinsics_yaml = args.intrinsics_yaml
    if args.plan_viewpoints and intrinsics_yaml is None:
        from fixture_scan.config import DEFAULT_INTRINSICS_YAML
        intrinsics_yaml = DEFAULT_INTRINSICS_YAML

    motion = planner = None
    client_node = None
    if not args.no_motion and not args.report_only and not args.capture_only_current:
        from rclpy.node import Node as _Node
        if not rclpy.ok():
            rclpy.init(args=None)
        client_node = _Node("fixture_scan_client")
        # planner: move_group plans a collision-free joint path to each viewpoint (pose goal,
        # RRTConnect). motion: streams that path as joint-position waypoints to the combined
        # joint_trajectory_controller -- the KUKA cabinets run FRI CARTESIAN_IMPEDANCE_CONTROL
        # underneath. `motion` is its OWN node (a thin subclass of lbr_dual_arm_pdz_bringup's
        # PlanExecutor -- it reuses that node's trajectory build + send verbatim).
        motion = JtcArmMotion(robot_name=args.robot_name, time_scale=args.jtc_time_scale)
        planner = ArmPlanner(client_node, robot_name=args.robot_name)

    # depth capture defaults on whenever the arm is actually moving
    capture_depth = (motion is not None) if args.capture_depth is None else args.capture_depth

    arms = ["hold", "move"] if args.both else [args.arm]
    results = {}
    for arm_key in arms:
        program_path = args.scan_program
        if program_path and args.both and arm_key == "move":
            # --both convenience: derive move's program path from hold's
            root, ext = os.path.splitext(args.scan_program)
            cand = f"{root}_move{ext}"
            program_path = cand if os.path.exists(cand) else args.scan_program
        results[arm_key] = run_single_arm_scan(
            arm_key, args.nominal_pose, args.motion_pkl, args.extrinsics_yaml, args.out_dir,
            report_only=args.report_only, motion=motion, planner=planner,
            scan_program_path=program_path, plan_viewpoints=args.plan_viewpoints,
            client_node=client_node, intrinsics_yaml=intrinsics_yaml,
            intrinsics_source=args.intrinsics_source, plan=args.plan,
            robot_name=args.robot_name,
            capture_depth=capture_depth, dwell_s=args.dwell_s,
            depth_frames_per_viewpoint=args.depth_frames_per_viewpoint,
            save_color=args.save_color, capture_only_current=args.capture_only_current,
        )

    if args.report_only or args.capture_only_current:
        print(json.dumps(results, indent=2, default=str))
        return
    if args.both:
        out_path = combine_into_correction(results["hold"], results["move"], args.nominal_pose, args.out_dir)
        print(out_path)


if __name__ == "__main__":
    main()
