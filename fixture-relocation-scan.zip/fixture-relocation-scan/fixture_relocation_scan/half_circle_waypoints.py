"""Orbit waypoint generator for the fixture scan.

docs/live_fixture_relocation_implementation_plan.md (Fabrica-pdz), Deliverable 3. Pure math, no
ROS. Generates camera viewpoints on a half-circle around the (live-corrected) board pose, near
and far radii driven by the fingertip standoff, swept only across the scanning arm's own side
of the table (hold = -Y side / lbr_one, move = +Y side / lbr_two -- matches
Masterthesis-vision/config/robot_bases.yaml's robot_a/robot_b layout) so the arm never reaches
over the fixture toward the other arm's half.
"""

import numpy as np

# hold (lbr_one) sits on the -Y side of the fixture, move (lbr_two) on +Y -- the half-circle is
# centered on the arm's own bearing toward the board, i.e. the direction from the board back
# toward that arm's base.
_ARM_SIDE_BEARING_DEG = {"hold": -90.0, "move": 90.0}


def half_circle_waypoints(board_center_pos, arm_key, radii_m, height_m, n_per_radius,
                          half_span_deg=150.0):
    """Camera positions (each meant to look back at `board_center_pos`) on one or more
    concentric half-circles in the horizontal (world-XY) plane at `height_m` above
    `board_center_pos`, centered on `arm_key`'s own side and spanning +/- half_span_deg/2.

    `board_center_pos`: 3-vector, any frame consistent with the caller (world or an arm base
    frame -- this function is frame-agnostic, it just does planar trig around the given point).
    `radii_m`: iterable of orbit radii (e.g. [near_m, far_m]).
    Returns a list of 3-vectors, radius-major (all of radii_m[0]'s waypoints, then radii_m[1]'s...).
    """
    if arm_key not in _ARM_SIDE_BEARING_DEG:
        raise ValueError(f"arm_key must be one of {sorted(_ARM_SIDE_BEARING_DEG)}, got {arm_key!r}")
    if n_per_radius < 1:
        raise ValueError("n_per_radius must be >= 1")

    board_center_pos = np.asarray(board_center_pos, dtype=float)
    bearing_rad = np.radians(_ARM_SIDE_BEARING_DEG[arm_key])
    half_span_rad = np.radians(half_span_deg)
    angles = np.linspace(bearing_rad - half_span_rad / 2, bearing_rad + half_span_rad / 2, n_per_radius)

    waypoints = []
    for radius_m in radii_m:
        for angle in angles:
            offset = radius_m * np.array([np.cos(angle), np.sin(angle), 0.0]) + np.array([0.0, 0.0, height_m])
            waypoints.append(board_center_pos + offset)
    return waypoints
