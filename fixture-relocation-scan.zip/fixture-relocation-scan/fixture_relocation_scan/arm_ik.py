"""flange pose -> joint config via MoveIt's ``compute_ik`` service.

Uses the namespaced ``move_group`` brought up by
``lbr_dual_arm_pdz_bringup/launch/move_group_ns.launch.py`` -- service
``/<robot>/compute_ik``, planning groups ``arm_one_flange`` / ``arm_two_flange``
(chains ``lbr_{one,two}_link_0`` -> ``lbr_{one,two}_link_ee``), matching
``look_at_pose._ARM_KEY_TO_GROUP``. Seeded from the arm's live joint state so the solution
stays near the current configuration (no elbow flips between orbit waypoints).
"""

import numpy as np
import rclpy
from moveit_msgs.srv import GetPositionIK
from scipy.spatial.transform import Rotation

# scan arm key -> (planning group, base frame, ordered joint names)
_ARM = {
    "hold": ("arm_one_flange", "lbr_one_link_0", [f"lbr_one_A{i}" for i in range(1, 8)]),
    "move": ("arm_two_flange", "lbr_two_link_0", [f"lbr_two_A{i}" for i in range(1, 8)]),
}

_MOVEIT_SUCCESS = 1  # moveit_msgs/MoveItErrorCodes.SUCCESS


class ArmIk:
    def __init__(self, node, robot_name="lbr_dual_arm", *, timeout_s=2.0):
        self._node = node
        self._timeout_s = float(timeout_s)
        self._cli = node.create_client(GetPositionIK, f"/{robot_name}/compute_ik")
        if not self._cli.wait_for_service(timeout_sec=10.0):
            raise RuntimeError(
                f"/{robot_name}/compute_ik not available after 10s -- is the namespaced "
                "move_group up? (ros2 launch lbr_dual_arm_pdz_bringup move_group_ns.launch.py "
                "mode:=hardware use_cartesian_impedance:=true)")

    def solve(self, role: str, T_base_flange: np.ndarray, seed_q) -> np.ndarray:
        """IK for `role`'s flange at the 4x4 `T_base_flange` (in that arm's base frame),
        seeded from `seed_q` (7,). Returns the 7-vector solution; raises on no solution."""
        group, base_frame, joint_names = _ARM[role]

        req = GetPositionIK.Request()
        ik = req.ik_request
        ik.group_name = group
        ik.robot_state.joint_state.name = list(joint_names)
        ik.robot_state.joint_state.position = [float(x) for x in seed_q]
        ik.pose_stamped.header.frame_id = base_frame
        ik.pose_stamped.pose.position.x = float(T_base_flange[0, 3])
        ik.pose_stamped.pose.position.y = float(T_base_flange[1, 3])
        ik.pose_stamped.pose.position.z = float(T_base_flange[2, 3])
        qx, qy, qz, qw = Rotation.from_matrix(T_base_flange[:3, :3]).as_quat()
        ik.pose_stamped.pose.orientation.x = float(qx)
        ik.pose_stamped.pose.orientation.y = float(qy)
        ik.pose_stamped.pose.orientation.z = float(qz)
        ik.pose_stamped.pose.orientation.w = float(qw)
        ik.timeout.sec = int(self._timeout_s)
        ik.timeout.nanosec = int((self._timeout_s % 1.0) * 1e9)
        ik.avoid_collisions = True

        future = self._cli.call_async(req)
        rclpy.spin_until_future_complete(
            self._node, future, timeout_sec=self._timeout_s + 3.0)
        res = future.result()
        if res is None:
            raise RuntimeError(f"[{role}] compute_ik call timed out")
        if res.error_code.val != _MOVEIT_SUCCESS:
            raise RuntimeError(
                f"[{role}] IK failed (MoveItErrorCode {res.error_code.val}) for flange pose "
                f"pos={np.round(T_base_flange[:3, 3], 3).tolist()} in {base_frame}")

        sol = dict(zip(res.solution.joint_state.name, res.solution.joint_state.position))
        try:
            return np.array([sol[j] for j in joint_names])
        except KeyError as exc:
            raise RuntimeError(
                f"[{role}] IK solution missing joint {exc} -- got {sorted(sol)}") from exc
