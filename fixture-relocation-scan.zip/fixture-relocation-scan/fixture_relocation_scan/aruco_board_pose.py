"""ArUco pickup-fixture board pose solver.

docs/live_fixture_relocation_implementation_plan.md (Fabrica-pdz), Deliverable 3. Mirrors
Masterthesis-vision's src/calibration/handeye_flange_cam_realsense.py::_solve_board_pose shape
and raise-on-failure convention (no silent None), but for an ArUco board instead of a
chessboard -- Masterthesis-vision has no existing ArUco code (confirmed).

Deliberately pure numpy/cv2, no rclpy and no Masterthesis-vision imports: ROS message decoding
(CameraInfo/Image -> K/img_bgr) lives in fixture_tracker.py, which already needs rclpy message
types. That keeps this module testable standalone (see ../tests/test_aruco_board_pose_synthetic.py)
in any environment with an ArUco-capable OpenCV (cv2.aruco.ArucoDetector, opencv-python>=4.7),
no ROS2 install required.
"""

import json

import cv2
import numpy as np

# same zero-distortion assumption as _solve_board_pose: correct once the image is already
# rectified upstream (this package only ever reads /.../camera/color/image_rect topics).
_ZERO_DIST = np.zeros((8, 1), dtype=np.float64)


def load_board_from_nominal_pose(nominal_pose_path):
    """Build a cv2.aruco.Board from Fabrica-pdz's fixture/nominal_world_pose.json
    (planning/tools/export_fixture_nominal_pose.py's output) -- the one sanctioned read across
    the Fabrica-pdz / fixture-relocation-scan boundary.

    Returns (board, dictionary, marker_length_m).
    """
    with open(nominal_pose_path, "r") as fp:
        nominal_pose = json.load(fp)
    opencv_meta = nominal_pose["opencv"]

    dictionary = cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, opencv_meta["dictionary"]))
    ids = np.array(opencv_meta["board_ids"], dtype=np.int32)
    obj_points = np.array(opencv_meta["board_obj_points_m"], dtype=np.float32)  # (N, 4, 3)
    board = cv2.aruco.Board(obj_points, dictionary, ids)
    return board, dictionary, float(opencv_meta["marker_length_m"])


def _reproj_err_px(obj_points, img_points, K, rvec, tvec):
    proj, _ = cv2.projectPoints(obj_points, rvec, tvec, K, _ZERO_DIST)
    return float(np.linalg.norm(proj.reshape(-1, 2) - img_points.reshape(-1, 2), axis=1).mean())


def solve_board_pose(img_bgr, K, board, dictionary):
    """(img_bgr, K) -> (T_cam_board, corners_px, reproj_err_px), mirroring
    handeye_flange_cam_realsense.py::_solve_board_pose's shape:
      - T_cam_board: 4x4 np.ndarray, board pose in the camera optical frame
      - corners_px: np.ndarray (N, 2), the matched detected corner pixels used for the solve
      - reproj_err_px: float, mean reprojection error in pixels
    Raises RuntimeError("ArUco board NOT found") / RuntimeError("solvePnP failed") on failure --
    no fallback/None return, caller must catch.
    """
    detector = cv2.aruco.ArucoDetector(dictionary, cv2.aruco.DetectorParameters())
    corners, ids, _rejected = detector.detectMarkers(img_bgr)
    if ids is None or len(ids) == 0:
        raise RuntimeError("ArUco board NOT found")

    obj_points, img_points = board.matchImagePoints(corners, ids)
    if obj_points is None or len(obj_points) < 4:
        raise RuntimeError("ArUco board NOT found")

    ok, rvec, tvec = cv2.solvePnP(obj_points, img_points, K, _ZERO_DIST, flags=cv2.SOLVEPNP_ITERATIVE)
    if not ok:
        raise RuntimeError("solvePnP failed")

    reproj_err_px = _reproj_err_px(obj_points, img_points, K, rvec, tvec)
    R, _ = cv2.Rodrigues(rvec)
    T_cam_board = np.eye(4)
    T_cam_board[:3, :3] = R
    T_cam_board[:3, 3] = tvec.reshape(3)
    return T_cam_board, img_points.reshape(-1, 2), reproj_err_px
